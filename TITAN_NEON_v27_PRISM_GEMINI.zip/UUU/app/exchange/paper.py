"""Paper futures exchange v2.
Fixes vs v1: risk-correct sizing (leverage no longer multiplies risk), liquidation model,
partial TPs (TP1/TP2/TP3) + breakeven/trailing stop, wick-aware SL/TP detection,
atomic state writes with backup (a corrupt file can no longer silently reset the account),
manual close at live price, daily reset by UTC day, richer statistics."""
from __future__ import annotations
import json
import os
import shutil
import threading
import time
from dataclasses import dataclass, asdict, field
from typing import Callable

from app.config import (
    DATA_DIR, STARTING_CAPITAL, DEFAULT_LEVERAGE, MAX_LEVERAGE, FEE_TAKER, FEE_MAKER, SLIPPAGE,
    MAX_OPEN_POSITIONS, RISK_PER_TRADE_PCT, DAILY_LOSS_LIMIT_PCT, MAX_MARGIN_PCT_PER_POS,
    MAX_TOTAL_MARGIN_PCT, PARTIALS, AUTO_MIN_CONF, AUTO_MIN_RR, AUTO_COOLDOWN_SEC,
)

_FILE = DATA_DIR / "paper_state.json"
_BAK = DATA_DIR / "paper_state.bak"
_LOCK = threading.RLock()


@dataclass
class Position:
    id: str
    symbol: str
    side: str
    qty: float
    entry: float
    leverage: int
    stop: float
    tp1: float
    tp2: float
    tp3: float
    margin: float
    opened_at: float
    qty_left: float = 0.0
    margin_left: float = 0.0
    stop0: float = 0.0
    liq: float = 0.0
    realized: float = 0.0
    stage: int = 0
    risk_usd: float = 0.0
    mfe: float = 0.0
    mae: float = 0.0
    last_check: float = 0.0
    unrealized: float = 0.0
    status: str = "open"
    source: str = "manual"
    score: float = 0.0
    regime: str = ""
    deadline: float = 0.0
    grade: str = ""
    plan: str = ""

    def __post_init__(self):
        if self.qty_left <= 0 < self.qty:
            self.qty_left = self.qty
        if self.margin_left <= 0 < self.margin:
            self.margin_left = self.margin
        self.stop0 = self.stop0 or self.stop
        self.last_check = self.last_check or self.opened_at
        if not self.risk_usd:
            self.risk_usd = abs(self.entry - self.stop0) * self.qty

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Account:
    wallet: float = STARTING_CAPITAL
    starting: float = STARTING_CAPITAL
    realized_pnl: float = 0.0
    total_fees: float = 0.0
    trades: int = 0
    wins: int = 0
    losses: int = 0
    peak_equity: float = STARTING_CAPITAL
    max_drawdown_pct: float = 0.0
    day_start_equity: float = STARTING_CAPITAL
    day_id: int = field(default_factory=lambda: int(time.time() // 86400))
    auto_trade: bool = False
    positions: list = field(default_factory=list)
    history: list = field(default_factory=list)
    equity_log: list = field(default_factory=list)
    recovered: str = ""
    orders: list = field(default_factory=list)
    auto_log: list = field(default_factory=list)
    paused_until: float = 0.0
    pause_reason: str = ""
    consec_losses: int = 0

    def equity(self, prices: dict[str, float] | None = None) -> float:
        prices = prices or {}
        eq = self.wallet
        for p in self.positions:
            if p.status != "open":
                continue
            px = prices.get(p.symbol, p.entry)
            d = 1 if p.side == "LONG" else -1
            p.unrealized = (px - p.entry) * p.qty_left * d
            eq += p.margin_left + p.unrealized
        return eq


_ACC: Account | None = None


def _from_raw(raw: dict) -> Account:
    pf = Position.__dataclass_fields__
    pos = [Position(**{k: v for k, v in p.items() if k in pf}) for p in raw.get("positions", [])]
    af = Account.__dataclass_fields__
    kw = {k: v for k, v in raw.items() if k in af and k not in ("positions",)}
    acc = Account(**kw)
    acc.positions = pos
    return acc


def _load() -> Account:
    global _ACC
    if _ACC is not None:
        return _ACC
    acc = None
    if _FILE.exists() or _BAK.exists():
        for path in (_FILE, _BAK):
            try:
                acc = _from_raw(json.loads(path.read_text(encoding="utf-8")))
                if path is _BAK:
                    acc.recovered = "restored from backup"
                break
            except Exception:                                # noqa: BLE001
                if path.exists():
                    shutil.copy(path, DATA_DIR / f"paper_state.corrupt-{int(time.time())}.json")
        if acc is None:
            acc = Account()
            acc.recovered = "state corrupt — new account (old file kept as .corrupt-*)"
    _ACC = acc or Account()
    return _ACC


def _save(acc: Account) -> None:
    data = {k: getattr(acc, k) for k in Account.__dataclass_fields__ if k != "positions"}
    data["positions"] = [p.to_dict() for p in acc.positions if p.status == "open"]
    data["history"] = acc.history[-300:]
    data["equity_log"] = acc.equity_log[-500:]
    tmp = _FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=1), encoding="utf-8")
    os.replace(tmp, _FILE)
    shutil.copy(_FILE, _BAK)                      # backup always mirrors the last good state


def _reset_cache_for_tests() -> None:
    global _ACC
    _ACC = None


def _roll_day(acc: Account, eq: float) -> None:
    d = int(time.time() // 86400)
    if d != acc.day_id:
        acc.day_id, acc.day_start_equity = d, eq


def _stats(acc: Account) -> dict:
    h = acc.history
    wins = [x["pnl"] for x in h if x["pnl"] > 0]
    loss = [x["pnl"] for x in h if x["pnl"] <= 0]
    gp, gl = sum(wins), -sum(loss)
    rs = [x.get("r", 0) for x in h if "r" in x]
    streak = 0
    for x in reversed(h):
        s = 1 if x["pnl"] > 0 else -1
        if streak == 0 or (streak > 0) == (s > 0):
            streak += s
        else:
            break
    return {"profit_factor": round(gp / gl, 2) if gl > 0 else (round(gp, 2) if gp else 0),
            "avg_win": round(gp / len(wins), 2) if wins else 0, "avg_loss": round(-gl / len(loss), 2) if loss else 0,
            "expectancy": round(sum(x["pnl"] for x in h) / len(h), 2) if h else 0,
            "avg_r": round(sum(rs) / len(rs), 2) if rs else 0,
            "best": round(max((x["pnl"] for x in h), default=0), 2),
            "worst": round(min((x["pnl"] for x in h), default=0), 2), "streak": streak}


def get_account(prices: dict[str, float] | None = None) -> dict:
    with _LOCK:
        acc = _load()
        prices = prices or {}
        eq = acc.equity(prices)
        peak = max(acc.peak_equity, eq)
        dd = max(acc.max_drawdown_pct, (peak - eq) / peak * 100 if peak else 0)
        return {"wallet": round(acc.wallet, 2), "equity": round(eq, 2), "starting": acc.starting,
                "realized_pnl": round(acc.realized_pnl, 2),
                "unrealized_pnl": round(sum(p.unrealized for p in acc.positions if p.status == "open"), 2),
                "day_pnl": round(eq - acc.day_start_equity, 2), "total_fees": round(acc.total_fees, 4),
                "trades": acc.trades, "wins": acc.wins, "losses": acc.losses,
                "win_rate": round(acc.wins / acc.trades * 100, 1) if acc.trades else 0.0,
                "peak_equity": round(peak, 2), "max_drawdown_pct": round(dd, 2), "auto_trade": acc.auto_trade,
                "open_positions": [p.to_dict() for p in acc.positions if p.status == "open"], "orders": acc.orders, "auto_log": acc.auto_log[-25:],
                "paused": time.time() < acc.paused_until, "pause_reason": acc.pause_reason, "consec_losses": acc.consec_losses,
                "history": acc.history[-40:], "equity_log": acc.equity_log[-120:], "stats": _stats(acc),
                "notice": acc.recovered,
                "limits": {"risk_pct": RISK_PER_TRADE_PCT, "max_leverage": MAX_LEVERAGE,
                           "max_positions": MAX_OPEN_POSITIONS, "daily_loss_pct": DAILY_LOSS_LIMIT_PCT}}


def is_auto() -> bool:
    with _LOCK:
        return _load().auto_trade


def set_auto_trade(enabled: bool) -> dict:
    with _LOCK:
        acc = _load()
        acc.auto_trade = bool(enabled)
        _save(acc)
        return {"ok": True, "auto_trade": acc.auto_trade}


def open_position(symbol, side, entry, stop, tp1, tp2, tp3=0.0, leverage=None, risk_pct=None,
                  source="manual", prices=None, score=0.0, regime="", kind="market", deadline_sec=0, grade="", plan="") -> dict:
    side = str(side).upper()
    if side not in ("LONG", "SHORT"):
        return {"ok": False, "error": "side must be LONG or SHORT"}
    if min(entry, stop, tp1, tp2) <= 0:
        return {"ok": False, "error": "قیمت‌ها نامعتبر"}
    tp3 = tp3 or tp2
    d = 1 if side == "LONG" else -1
    if (entry - stop) * d <= 0:
        return {"ok": False, "error": "حدضرر در سمت اشتباه است"}
    if not ((tp1 - entry) * d > 0 and (tp2 - tp1) * d > 0 and (tp3 - tp2) * d >= 0):
        return {"ok": False, "error": "ترتیب اهداف نامعتبر است"}
    fill = entry if kind == "limit" else entry * (1 + SLIPPAGE * d)           # a resting limit order fills at its price (maker)
    stop_dist = abs(fill - stop)
    lev = max(1, min(MAX_LEVERAGE, int(leverage or DEFAULT_LEVERAGE)))
    lev = max(1, min(lev, int(fill / (1.6 * stop_dist))))          # liquidation must sit well beyond the stop
    risk_pct = risk_pct or RISK_PER_TRADE_PCT

    with _LOCK:
        acc = _load()
        if any(p.symbol == symbol and p.status == "open" for p in acc.positions):
            return {"ok": False, "error": f"پوزیشن باز روی {symbol} وجود دارد"}
        opens = [p for p in acc.positions if p.status == "open"]
        if len(opens) >= MAX_OPEN_POSITIONS:
            return {"ok": False, "error": "سقف پوزیشن باز"}
        eq = acc.equity(prices)
        _roll_day(acc, eq)
        if acc.day_start_equity and (eq - acc.day_start_equity) / acc.day_start_equity * 100 <= -DAILY_LOSS_LIMIT_PCT:
            return {"ok": False, "error": "حد ضرر روزانه فعال شد"}
        if source == "auto":
            for h in reversed(acc.history[-30:]):
                if h["symbol"] == symbol and h["pnl"] < 0 and time.time() - h["closed_at"] < AUTO_COOLDOWN_SEC:
                    return {"ok": False, "error": "کولدان بعد از ضرر"}
        qty = (eq * risk_pct / 100) / stop_dist                      # risk-correct: loss at stop == risk_pct
        margin = qty * fill / lev
        cap = min(eq * MAX_MARGIN_PCT_PER_POS / 100,
                  eq * MAX_TOTAL_MARGIN_PCT / 100 - sum(p.margin_left for p in opens), acc.wallet * 0.98)
        if cap <= 0:
            return {"ok": False, "error": "سقف مارجین کل"}
        if margin > cap:
            qty *= cap / margin
            margin = cap
        notional = qty * fill
        fee = notional * (FEE_MAKER if kind == "limit" else FEE_TAKER)
        if margin + fee > acc.wallet:
            return {"ok": False, "error": "مارجین کافی نیست"}
        acc.wallet -= margin + fee
        acc.total_fees += fee
        acc.realized_pnl -= fee
        liq = fill * (1 - d * (1 / lev - 0.005))
        pos = Position(id=f"{symbol}-{int(time.time() * 1000)}", symbol=symbol, side=side, qty=round(qty, 8),
                       entry=fill, leverage=lev, stop=stop, tp1=tp1, tp2=tp2, tp3=tp3, margin=round(margin, 6),
                       opened_at=time.time(), liq=liq, source=source, score=score, regime=regime,
                       deadline=(time.time() + deadline_sec) if deadline_sec else 0.0, grade=grade, plan=plan)
        pos.realized = -fee
        acc.positions.append(pos)
        _save(acc)
        return {"ok": True, "position": pos.to_dict(), "leverage_used": lev}


def _exit(acc: Account, pos: Position, qty: float, price: float, reason: str, maker=False, final=False) -> None:
    d = 1 if pos.side == "LONG" else -1
    qty = min(qty, pos.qty_left)
    if qty <= 0:
        return
    fee = qty * price * (FEE_MAKER if maker else FEE_TAKER)
    pnl = (price - pos.entry) * qty * d - fee
    m_rel = pos.margin_left * qty / pos.qty_left
    acc.wallet += m_rel + pnl
    acc.total_fees += fee
    acc.realized_pnl += pnl
    pos.realized += pnl
    pos.qty_left -= qty
    pos.margin_left -= m_rel
    if final or pos.qty_left <= pos.qty * 1e-9:
        total = pos.realized
        acc.trades += 1
        acc.wins += 1 if total > 0 else 0
        acc.losses += 0 if total > 0 else 1
        acc.history.append({"id": pos.id, "symbol": pos.symbol, "side": pos.side, "entry": pos.entry, "exit": price,
                            "pnl": round(total, 4), "r": round(total / pos.risk_usd, 2) if pos.risk_usd else 0,
                            "leverage": pos.leverage, "opened_at": pos.opened_at, "closed_at": time.time(),
                            "reason": reason, "stage": pos.stage, "source": pos.source,
                            "mfe": round(pos.mfe, 2), "mae": round(pos.mae, 2)})
        acc.consec_losses = 0 if total > 0 else acc.consec_losses + 1
        if pos.source == "auto" and acc.consec_losses >= 3:
            acc.paused_until, acc.pause_reason = time.time() + 4 * 3600, "۳ ضرر پیاپی؛ ترید خودکار ۴ ساعت متوقف شد"
        pos.status = "closed"
        pos.qty_left = pos.margin_left = 0.0


def close_position(pid: str, price: float, reason: str = "manual") -> dict:
    with _LOCK:
        acc = _load()
        pos = next((p for p in acc.positions if p.id == pid and p.status == "open"), None)
        if not pos:
            return {"ok": False, "error": "یافت نشد"}
        if price <= 0:
            return {"ok": False, "error": "قیمت نامعتبر"}
        d = 1 if pos.side == "LONG" else -1
        _exit(acc, pos, pos.qty_left, price * (1 - SLIPPAGE * d), reason, final=True)
        acc.positions = [p for p in acc.positions if p.status == "open"]
        acc.equity_log.append({"t": time.time(), "eq": round(acc.equity({}), 2)})
        _save(acc)
        return {"ok": True, "pnl": round(acc.history[-1]["pnl"], 4)}


def reset_account() -> dict:
    global _ACC
    with _LOCK:
        _ACC = Account()
        _save(_ACC)
        return {"ok": True, "wallet": _ACC.wallet}


def mark_to_market(prices: dict[str, float],
                   range_fn: Callable[[str, float, float], tuple[float, float] | None] | None = None) -> list[dict]:
    """range_fn(symbol, since_ts, opened_at) -> (low, high) of candles since last check (wick detection)."""
    closed, now = [], time.time()
    with _LOCK:
        acc = _load()
        _process_orders(acc, prices, range_fn, now)
        for pos in list(acc.positions):
            if pos.status != "open":
                continue
            px = prices.get(pos.symbol)
            if px is None:
                continue
            lo = hi = px
            rg = range_fn(pos.symbol, pos.last_check, pos.opened_at) if range_fn else None
            if rg:
                lo, hi = min(lo, rg[0]), max(hi, rg[1])
            pos.last_check = now
            long_ = pos.side == "LONG"
            d = 1 if long_ else -1
            pos.mfe = max(pos.mfe, ((hi if long_ else -lo) - (pos.entry if long_ else -pos.entry)) / pos.entry * 100)
            pos.mae = min(pos.mae, ((lo if long_ else -hi) - (pos.entry if long_ else -pos.entry)) / pos.entry * 100)
            tps = [pos.tp1, pos.tp2, pos.tp3]
            adverse, favour = (lo, hi) if long_ else (hi, lo)
            if pos.deadline and now > pos.deadline and pos.stage == 0 and (adverse - pos.stop) * d > 0:      # dead trade: no progress before the deadline
                r_now = (px - pos.entry) * d / (abs(pos.entry - pos.stop0) or 1e-9)
                if r_now < 0.5:
                    _exit(acc, pos, pos.qty_left, px * (1 - SLIPPAGE * d), "time", final=True)
                    closed.append({"id": pos.id, "symbol": pos.symbol, "pnl": acc.history[-1]["pnl"], "reason": "time"})
                    continue
            for _ in range(5):
                if pos.status != "open":
                    break
                if (adverse - pos.liq) * d <= 0:                              # liquidation
                    _exit(acc, pos, pos.qty_left, pos.liq, "liquidation", final=True)
                    break
                if (adverse - pos.stop) * d <= 0:                             # stop / trailing / breakeven
                    why = "stop" if pos.stage == 0 else ("breakeven" if pos.stage == 1 else "trail")
                    _exit(acc, pos, pos.qty_left, pos.stop * (1 - SLIPPAGE * d), why, final=True)
                    break
                if pos.stage >= 3 or (favour - tps[pos.stage]) * d < 0:
                    break
                tp = tps[pos.stage]
                last_leg = pos.stage == 2
                frac = PARTIALS[pos.stage]
                q = pos.qty_left if last_leg else min(pos.qty_left, pos.qty * frac)
                _exit(acc, pos, q, tp, f"tp{pos.stage + 1}", maker=True, final=last_leg)
                pos.stage += 1
                if pos.status != "open":
                    break
                pos.stop = pos.entry * (1 + 0.0006 * d) if pos.stage == 1 else pos.tp1
                adverse = px                                                   # order inside candle unknown → be conservative
            if pos.status == "closed":
                h = acc.history[-1]
                closed.append({"id": pos.id, "symbol": pos.symbol, "pnl": h["pnl"], "reason": h["reason"]})
        acc.positions = [p for p in acc.positions if p.status == "open"]
        eq = acc.equity(prices)
        _roll_day(acc, eq)
        acc.peak_equity = max(acc.peak_equity, eq)
        if acc.peak_equity:
            acc.max_drawdown_pct = max(acc.max_drawdown_pct, (acc.peak_equity - eq) / acc.peak_equity * 100)
        acc.equity_log.append({"t": now, "eq": round(eq, 2)})
        _save(acc)
    return closed


def place_order(o: dict) -> dict:
    """Resting order. mode: 'limit' (pull-back) or 'stop' (breakout trigger). Valid for valid_h hours."""
    side = str(o.get("side", "")).upper(); mode = o.get("mode", "limit")
    try:
        price, stop, tp1, tp2 = float(o["price"]), float(o["stop"]), float(o["tp1"]), float(o["tp2"]); tp3 = float(o.get("tp3") or tp2)
    except (KeyError, TypeError, ValueError):
        return {"ok": False, "error": "پارامترهای سفارش ناقص است"}
    d = 1 if side == "LONG" else -1
    if side not in ("LONG", "SHORT") or mode not in ("limit", "stop") or min(price, stop, tp1, tp2) <= 0:
        return {"ok": False, "error": "سفارش نامعتبر"}
    if (price - stop) * d <= 0 or not ((tp1 - price) * d > 0 and (tp2 - tp1) * d > 0 and (tp3 - tp2) * d >= 0):
        return {"ok": False, "error": "حدضرر/اهداف نسبت به قیمت ورود نامعتبرند"}
    with _LOCK:
        acc = _load()
        if any(x["symbol"] == o["symbol"] for x in acc.orders) or any(p.symbol == o["symbol"] and p.status == "open" for p in acc.positions):
            return {"ok": False, "error": "برای این ارز سفارش یا پوزیشن فعال وجود دارد"}
        if len(acc.orders) >= 12:
            return {"ok": False, "error": "سقف سفارش‌های معلق"}
        od = {"id": f"O-{o['symbol']}-{int(time.time() * 1000)}", "symbol": o["symbol"], "side": side, "mode": mode, "price": price, "stop": stop,
              "tp1": tp1, "tp2": tp2, "tp3": tp3, "risk_pct": float(o.get("risk_pct") or RISK_PER_TRADE_PCT), "created": time.time(), "last_check": time.time(),
              "expires": time.time() + max(0.25, min(72.0, float(o.get("valid_h", 6)))) * 3600, "source": o.get("source", "manual"), "grade": o.get("grade", ""),
              "plan": o.get("plan", ""), "score": float(o.get("score", 0)), "regime": o.get("regime", ""), "deadline_h": float(o.get("deadline_h", 0)), "leverage": o.get("leverage")}
        acc.orders.append(od)
        _save(acc)
        return {"ok": True, "order": od}


def cancel_order(oid: str, reason: str = "cancel") -> dict:
    with _LOCK:
        acc = _load()
        n = len(acc.orders)
        acc.orders = [x for x in acc.orders if x["id"] != oid]
        if len(acc.orders) != n:
            _save(acc)
        return {"ok": len(acc.orders) != n}


def _process_orders(acc: Account, prices: dict, range_fn, now: float) -> None:
    keep = []
    for od in acc.orders:
        px = prices.get(od["symbol"])
        if px is None:
            keep.append(od); continue
        d = 1 if od["side"] == "LONG" else -1
        lo = hi = px
        rg = range_fn(od["symbol"], od["last_check"], od["created"]) if range_fn else None
        if rg:
            lo, hi = min(lo, rg[0]), max(hi, rg[1])
        od["last_check"] = now
        adverse = lo if d > 0 else hi
        hit = (lo <= od["price"]) if (od["mode"] == "limit") == (d > 0) else (hi >= od["price"])
        if (adverse - od["stop"]) * d <= 0 and not hit:
            acc.auto_log.append({"t": now, "symbol": od["symbol"], "ok": False, "text": "سفارش لغو شد: قیمت قبل از پر شدن به حدضرر رسید"}); continue
        if now > od["expires"]:
            acc.auto_log.append({"t": now, "symbol": od["symbol"], "ok": False, "text": "سفارش منقضی شد (پر نشد)"}); continue
        if hit:
            # Same-candle SL protection: if the fill candle also tags the stop,
            # refuse the fill (conservative — unknown path inside the bar).
            stop_hit_same = (lo <= od["stop"]) if d > 0 else (hi >= od["stop"])
            if stop_hit_same:
                acc.auto_log.append({"t": now, "symbol": od["symbol"], "ok": False,
                                     "text": "سفارش لغو: در همان کندل ورود، حدضرر هم لمس شد (مسیر نامشخص)"})
                continue
            r = open_position(od["symbol"], od["side"], od["price"], od["stop"], od["tp1"], od["tp2"], od["tp3"], leverage=od.get("leverage") or DEFAULT_LEVERAGE,
                              risk_pct=od["risk_pct"], source=od["source"], prices=prices, score=od["score"], regime=od["regime"],
                              kind="limit" if od["mode"] == "limit" else "market", deadline_sec=od["deadline_h"] * 3600, grade=od["grade"], plan=od["plan"])
            acc.auto_log.append({"t": now, "symbol": od["symbol"], "ok": bool(r.get("ok")), "text": "سفارش پر شد: " + od["plan"] if r.get("ok") else "پر شدن ناموفق: " + str(r.get("error"))})
            if not r.get("ok") and r.get("error") in ("مارجین کافی نیست",):
                keep.append(od)
            continue
        keep.append(od)
    acc.orders = keep
    acc.auto_log = acc.auto_log[-80:]


def log_auto(entry: dict) -> None:
    with _LOCK:
        acc = _load()
        acc.auto_log.append({**entry, "t": time.time()})
        acc.auto_log = acc.auto_log[-80:]
        _save(acc)


def pause_state(prices: dict[str, float] | None = None) -> dict:
    """Circuit-breaker based on live equity when prices are supplied.
    Passing {} marks open positions at entry and understates drawdown — avoid that."""
    with _LOCK:
        acc = _load()
        px = prices if prices is not None else {}
        # Prefer last known marks from positions themselves when no live book is given
        if not px:
            px = {p.symbol: p.entry for p in acc.positions if p.status == "open"}
        eq = acc.equity(px)
        peak = max(acc.peak_equity, eq)
        dd = (peak - eq) / peak * 100 if peak else 0.0
        if time.time() < acc.paused_until:
            return {"paused": True, "reason": acc.pause_reason, "until": acc.paused_until, "dd": round(dd, 2)}
        if dd >= 12 and acc.trades >= 5:
            return {"paused": True, "reason": f"افت سرمایه {dd:.1f}٪ از اوج؛ ترید خودکار تا بازنشانی/بهبود متوقف است", "until": 0, "dd": round(dd, 2)}
        return {"paused": False, "dd": round(dd, 2)}


def clear_pause(prices: dict[str, float] | None = None) -> dict:
    with _LOCK:
        acc = _load()
        acc.paused_until, acc.pause_reason, acc.consec_losses = 0.0, "", 0
        eq = acc.equity(prices or {})
        if eq < acc.peak_equity:
            # Keep true peak; do not silently raise floor on a depressed equity
            pass
        else:
            acc.peak_equity = max(acc.peak_equity, eq, 1.0)
        _save(acc)
        return {"ok": True}


def try_auto_open(plan: dict, conviction: float, prices: dict[str, float]) -> dict | None:
    if not is_auto():
        return None
    side = plan.get("side")
    if side not in ("LONG", "SHORT") or conviction < AUTO_MIN_CONF or float(plan.get("risk_reward", 0)) < AUTO_MIN_RR:
        return None
    px = prices.get(plan["symbol"]) or float(plan["entry"])
    return open_position(plan["symbol"], side, px, float(plan["stop"]), float(plan["tp1"]), float(plan["tp2"]),
                         float(plan.get("tp3") or plan["tp2"]), leverage=DEFAULT_LEVERAGE, source="auto",
                         prices=prices, score=float(plan.get("score", 0)), regime=plan.get("regime", ""))

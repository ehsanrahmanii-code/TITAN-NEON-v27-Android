"""Background multi-TF scanner. Non-blocking (thread), bulk tickers, shared closed-candle
frame cache (deep analysis never refetches), wick-aware paper-exchange marking."""
from __future__ import annotations
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from app import settings
from app.config import (TIMEFRAMES, TF_PRIORITY, KLINE_LIMIT, CHART_KLINES, CPU_WORKERS, FORECAST_CANDLES, to_base, to_symbol)
from app.data.market import fetch_klines, fetch_tickers, closed_only, source_status, fetch_depth, fetch_derivs
from app.analysis.technicals import analyze
from app.analysis.forecast import forecast_summary
from app.analysis.deep import deep_analyze
from app.analysis.grade import fuse, grade_from
from app.analysis import patterns as pat
from app.engine import alerts, evidence, siglog
from app.analysis import forecast as fc_mod, planner
from app.exchange import policy
import numpy as np
from app.exchange import paper as exchange

_CACHE: dict[str, dict] = {}
_FRAMES: dict[str, object] = {}
_TICKERS: dict[str, dict] = {}
_LOCK = threading.RLock()
_S = {"scanning": False, "last_scan": 0.0, "duration": 0.0, "errors": [], "progress": {"done": 0, "total": 0, "ok": 0, "err": 0}}
_IV_MS = {"15m": 900_000, "1h": 3_600_000, "4h": 14_400_000, "1d": 86_400_000}


def _key(sym: str, tf: str) -> str:
    return f"{sym.upper()}:{tf}"


def _round6(v):
    return float(f"{v:.6g}")


def _scan_one(sym: str, tf: str, ticker: dict | None) -> dict:
    try:
        full = fetch_klines(sym, tf, KLINE_LIMIT)
        df = closed_only(full, tf)
        live = (ticker or {}).get("price") or float(full["close"].iloc[-1])
        sig = analyze(df, sym, tf, price=live)
        lv = {"entry": sig.entry, "stop": sig.stop, "tp1": sig.tp1, "tp2": sig.tp2, "tp3": sig.tp3} if sig.side != "WAIT" else None
        fc = forecast_summary(df, sig.side, n_ahead=FORECAST_CANDLES, seed_key=f"{sym}{tf}", levels=lv)
        kl = [{"t": int(t.timestamp() * 1000), "o": float(o), "h": float(h), "l": float(l), "c": float(c), "v": float(v)}
              for t, o, h, l, c, v in full.tail(CHART_KLINES)[["open_time", "open", "high", "low", "close", "volume"]].itertuples(index=False)]
        tk = ticker or {"symbol": sym, "price": live, "change_pct": 0.0, "high": 0, "low": 0, "volume": 0, "quote_volume": 0}
        with _LOCK:
            _FRAMES[_key(sym, tf)] = df
        return {"signal": sig.to_dict(), "forecast": fc, "ticker": tk, "klines": kl, "updated": time.time(),
                "stale": bool(full.attrs.get("stale"))}
    except Exception as e:                                   # noqa: BLE001
        return {"error": str(e)[:160], "symbol": sym, "timeframe": tf}


def _range_fn(sym: str, since: float, opened_at: float):
    for tf in ("15m", "1h"):
        item = _CACHE.get(_key(sym, tf))
        if not item or "klines" not in item:
            continue
        ms, o_ms = _IV_MS[tf], opened_at * 1000
        sel = [k for k in item["klines"] if k["t"] >= o_ms and k["t"] + ms > since * 1000]
        if sel:
            return min(k["l"] for k in sel), max(k["h"] for k in sel)
    return None


def get_frames(sym: str) -> dict:
    with _LOCK:
        return {tf: _FRAMES.get(_key(sym, tf)) for tf in TIMEFRAMES if _FRAMES.get(_key(sym, tf)) is not None}


def build_deep(sym: str, primary_tf: str = "1h", fetch_missing: bool = True) -> dict:
    sym = to_symbol(sym)
    frames = get_frames(sym)
    if fetch_missing:
        for tf in TIMEFRAMES:
            if tf not in frames:
                try:
                    frames[tf] = closed_only(fetch_klines(sym, tf, KLINE_LIMIT), tf)
                except Exception:                            # noqa: BLE001
                    pass
    prices = {tf: (_CACHE.get(_key(sym, tf)) or {}).get("ticker", {}).get("price") for tf in TIMEFRAMES}
    live = next((p for p in prices.values() if p), None)
    # Microstructure (public endpoints) — best-effort, never blocks deep analysis
    derivs, depth = None, None
    try:
        derivs = fetch_derivs(sym)
    except Exception:                                        # noqa: BLE001
        pass
    try:
        depth = fetch_depth(sym)
    except Exception:                                        # noqa: BLE001
        pass
    btc_frame = _FRAMES.get(_key("BTCUSDT", primary_tf if primary_tf in TIMEFRAMES else "1h"))
    if btc_frame is None:
        btc_frame = _FRAMES.get(_key("BTCUSDT", "1h"))
    hrs = hour_stats()
    return deep_analyze(
        frames, sym, primary_tf,
        {tf: live for tf in frames} if live else None,
        derivs=derivs, depth=depth, btc_frame=btc_frame, hour_stats=hrs,
    )


def _run(symbols: list[str], tfs: list[str]) -> None:
    t0 = time.time()
    try:
        tickers = fetch_tickers(symbols, max_age=5)
        with _LOCK:
            _TICKERS.update(tickers)
        order = sorted(tfs, key=lambda t: TF_PRIORITY.index(t) if t in TF_PRIORITY else 9)
        tasks = [(s, tf) for tf in order for s in symbols]
        with ThreadPoolExecutor(max_workers=CPU_WORKERS) as ex:
            futs = {ex.submit(_scan_one, s, tf, tickers.get(s)): (s, tf) for s, tf in tasks}
            for fut in as_completed(futs):
                s, tf = futs[fut]
                res = fut.result()
                with _LOCK:
                    p = _S["progress"]
                    p["done"] += 1
                    if "error" in res:
                        p["err"] += 1
                        _S["errors"] = ([f"{s} {tf}: {res['error']}"] + _S["errors"])[:12]
                    else:
                        p["ok"] += 1
                        _CACHE[_key(s, tf)] = res
        prices = {s: t["price"] for s, t in tickers.items()}
        for s in symbols:                                    # fall back to last candle for missing tickers
            if s not in prices:
                it = _CACHE.get(_key(s, "1h"))
                if it:
                    prices[s] = it["ticker"]["price"]
        try:
            exchange.mark_to_market(prices, _range_fn)
            evidence.refresh_async(symbols)
            if exchange.is_auto():
                _auto_pass(symbols, prices)
        except Exception as e:                               # noqa: BLE001
            with _LOCK:
                _S["errors"] = [f"exchange: {e}"] + _S["errors"][:11]
        try:
            _refresh_pattern_stats(symbols)
            alerts_tick()
            siglog.tick({sy: _row_fusion(sy) for sy in symbols}, {sy: (_CACHE.get(_key(sy, '1h')) or {}).get('ticker', {}).get('price') for sy in symbols})
        except Exception as e:                               # noqa: BLE001
            with _LOCK:
                _S["errors"] = [f"patterns: {e}"] + _S["errors"][:11]
    finally:
        with _LOCK:
            _S.update(scanning=False, last_scan=time.time(), duration=round(time.time() - t0, 1))


def start_scan(symbols=None, timeframes=None) -> dict:
    wl = settings.get_watchlist()
    symbols = [to_symbol(s) for s in (symbols or wl)]
    tfs = [t for t in (timeframes or TIMEFRAMES) if t in TIMEFRAMES]
    with _LOCK:
        if _S["scanning"]:
            return {"status": "busy", "progress": dict(_S["progress"])}
        _S["scanning"] = True
        _S["progress"] = {"done": 0, "total": len(symbols) * len(tfs), "ok": 0, "err": 0}
    threading.Thread(target=_run, args=(symbols, tfs), daemon=True, name="titan-scan").start()
    return {"status": "started", "progress": dict(_S["progress"])}


def wait_idle(timeout: float = 120) -> None:
    t0 = time.time()
    while _S["scanning"] and time.time() - t0 < timeout:
        time.sleep(0.05)


def get_cache_item(sym: str, tf: str) -> dict | None:
    with _LOCK:
        return _CACHE.get(_key(sym, tf))


def put_cache_item(sym: str, tf: str, item: dict) -> None:
    with _LOCK:
        _CACHE[_key(sym, tf)] = item


_PAT: dict = {}
_HOURS: dict = {}


def _refresh_pattern_stats(symbols) -> None:
    """Pool every past occurrence of each pattern over all watched coins, per timeframe (cheap: vectorised)."""
    new = {}
    for tf in TIMEFRAMES:
        frames = [_FRAMES[_key(s, tf)] for s in symbols if _key(s, tf) in _FRAMES]
        if frames:
            new[tf] = pat.pooled_stats(frames)
    hrs = {}
    fr = [_FRAMES[_key(s, "1h")] for s in symbols if _key(s, "1h") in _FRAMES]
    if fr:
        rng, vol, cnt = np.zeros(24), np.zeros(24), np.zeros(24)
        for df in fr:
            h = df["open_time"].dt.hour.values
            r = ((df["high"] - df["low"]) / df["close"]).values * 100
            v = df["volume"].values / (pd_mean(df["volume"]) or 1)
            for hh in range(24):
                m = h == hh
                rng[hh] += r[m].sum(); vol[hh] += v[m].sum(); cnt[hh] += m.sum()
        cnt = np.where(cnt == 0, 1, cnt)
        hrs = {"range": [round(float(x), 3) for x in rng / cnt], "vol": [round(float(x), 2) for x in vol / cnt], "n": int(cnt.sum())}
    with _LOCK:
        _PAT.clear(); _PAT.update(new); _HOURS.clear(); _HOURS.update(hrs)


def pd_mean(s):
    return float(s.tail(200).mean())


def pattern_stats(tf: str) -> dict:
    with _LOCK:
        return _PAT.get(tf, {})


def hour_stats() -> dict:
    with _LOCK:
        return dict(_HOURS)


def alerts_tick() -> list:
    syms = settings.get_watchlist()

    def price_of(sym):
        t = _TICKERS.get(sym)
        if t and t.get("price"):
            return t["price"]
        it = _CACHE.get(_key(sym, "1h"))
        return it["ticker"]["price"] if it and it.get("ticker") else None
    with _LOCK:
        pass
    return alerts.check(price_of, lambda s: _row_fusion(s), syms)


def _ohlc(item: dict, n=40):
    return [[_round6(k["o"]), _round6(k["h"]), _round6(k["l"]), _round6(k["c"])] for k in item.get("klines", [])[-n:]]


def _fcc(item: dict):
    return [[_round6(c["open"]), _round6(c["high"]), _round6(c["low"]), _round6(c["close"])] for c in ((item.get("forecast") or {}).get("candles") or [])]


def _spark(item: dict, n=36):
    cl = [k["c"] for k in item.get("klines", [])][-n:]
    return [_round6(c) for c in cl]


def _btc_stats(sym: str) -> dict:
    """Correlation / beta / 24-candle relative strength vs BTC on the 1h frame (None when unavailable)."""
    a, b = _FRAMES.get(_key(sym, "1h")), _FRAMES.get(_key("BTCUSDT", "1h"))
    if a is None or b is None or len(a) < 60 or len(b) < 60:
        return {}
    n = min(len(a), len(b), 120)
    ra = np.diff(np.log(a["close"].values[-n - 1:].astype(float)))
    rb = np.diff(np.log(b["close"].values[-n - 1:].astype(float)))
    if ra.std() == 0 or rb.std() == 0:
        return {}
    corr = float(np.corrcoef(ra, rb)[0, 1])
    beta = float(np.cov(ra, rb)[0, 1] / rb.var())
    return {"corr": round(corr, 2), "beta": round(beta, 2), "rs24": round(float((ra[-24:].sum() - rb[-24:].sum()) * 100), 2)}


def _row_fusion(sym: str, ptf: str = "1h") -> dict:
    sigs = {tf: _CACHE[_key(sym, tf)]["signal"] for tf in TIMEFRAMES if _key(sym, tf) in _CACHE and "signal" in _CACHE[_key(sym, tf)]}
    if not sigs:
        return {}
    fcs = {tf: _CACHE[_key(sym, tf)].get("forecast") or {} for tf in sigs}
    cons, side, note = fuse({tf: x["score"] for tf, x in sigs.items()})
    g = grade_from(sigs, fcs, side, cons, ptf if ptf in sigs else next(iter(sigs)))
    return {"cons": round(cons, 1), "verdict": side, "veto": bool(note), "grade": g["grade"], "points": g["points"], "aligned": g["aligned"]}


def get_matrix() -> dict:
    now = time.time()
    with _LOCK:
        m = {}
        for sym in settings.get_watchlist():
            row = {"symbol": sym, "base": to_base(sym), "tfs": {}, "ticker": None, "spark": [], "fc": None, "age": None}
            for tf in TIMEFRAMES:
                d = _CACHE.get(_key(sym, tf))
                if not d:
                    continue
                s, f = d["signal"], d.get("forecast") or {}
                ind, e = s.get("indicators") or {}, f.get("edge") or {}
                row["tfs"][tf] = {"side": s["side"], "score": s["score"], "confidence": s["confidence"], "entry": s["entry"],
                                  "stop": s["stop"], "tp1": s["tp1"], "tp2": s["tp2"], "tp3": s["tp3"], "rr": s["risk_reward"],
                                  "regime": s.get("regime"), "bias": s.get("bias"), "forecast": f.get("direction"),
                                  "move": f.get("expected_move_pct"), "prob_up": f.get("prob_up"), "rsi": ind.get("rsi"),
                                  "adx": ind.get("adx"), "atr_pct": ind.get("atr_pct"), "vol_ratio": ind.get("vol_ratio"),
                                  "squeeze": ind.get("squeeze"), "agree": s.get("agree"), "ev_r": e.get("ev_r"),
                                  "p_tp1": e.get("p_tp1"), "warns": len(s.get("warnings") or [])}
                if tf == "1h":
                    row["spark"] = _spark(d)
                    row["ohlc"], row["fcc"] = _ohlc(d), _fcc(d)
                    b = f.get("bands") or {}
                    if b:
                        row["fc"] = {k: [_round6(x) for x in b[k]] for k in ("p10", "p50", "p90")}
                    row["age"] = int(now - d["updated"])
                    row["stale"] = d.get("stale", False)
                if d.get("ticker") and (not row["ticker"] or tf == "1h"):
                    row["ticker"] = d["ticker"]
            row.update(_row_fusion(sym))
            row.update(_btc_stats(sym))
            m[sym] = row
        return {"matrix": m, "timeframes": TIMEFRAMES, "at": _S["last_scan"], "scanning": _S["scanning"],
                "progress": dict(_S["progress"])}


def market_overview() -> dict:
    """Breadth, movers, volatility and correlation computed purely from the scan cache."""
    with _LOCK:
        syms = settings.get_watchlist()
        per_tf = {}
        for tf in TIMEFRAMES:
            n = a50 = a200 = lg = sh = 0
            rs, ad, sc = [], [], []
            for sym in syms:
                d = _CACHE.get(_key(sym, tf))
                if not d:
                    continue
                sg = d["signal"]; ind = sg.get("indicators") or {}
                px = (d.get("ticker") or {}).get("price") or sg["entry"]
                n += 1; a50 += px > ind.get("ema50", 1e99); a200 += px > ind.get("ema200", 1e99)
                lg += sg["side"] == "LONG"; sh += sg["side"] == "SHORT"
                rs.append(ind.get("rsi", 50)); ad.append(ind.get("adx", 0)); sc.append(sg["score"])
            if n:
                per_tf[tf] = {"n": n, "above50": round(a50 / n * 100), "above200": round(a200 / n * 100), "long": lg, "short": sh,
                              "rsi": round(float(np.mean(rs)), 1), "adx": round(float(np.mean(ad)), 1), "score": round(float(np.mean(sc)), 1)}
        rows = []
        for sym in syms:
            d = _CACHE.get(_key(sym, "1h"))
            if not d:
                continue
            tk, sg = d.get("ticker") or {}, d["signal"]
            fu = _row_fusion(sym)
            rows.append({"symbol": sym, "base": to_base(sym), "chg": tk.get("change_pct", 0), "qv": tk.get("quote_volume", 0),
                         "atr": (sg.get("indicators") or {}).get("atr_pct", 0), "cons": fu.get("cons", 0), "grade": fu.get("grade", "—"),
                         "verdict": fu.get("verdict", "WAIT"), "squeeze": (sg.get("indicators") or {}).get("squeeze", False),
                         "vol_pct": ((sg.get("extras") or {}).get("stats") or {}).get("vol_pct")})
        top_vol = sorted(rows, key=lambda r: -r["qv"])[:10]
        corr = {}
        names = [r["symbol"] for r in top_vol if _FRAMES.get(_key(r["symbol"], "1h")) is not None and len(_FRAMES[_key(r["symbol"], "1h")]) >= 100]
        if len(names) >= 3:
            mat = np.array([np.diff(np.log(_FRAMES[_key(x, "1h")]["close"].values[-101:].astype(float))) for x in names])
            c = np.corrcoef(mat)
            corr = {"names": [to_base(x) for x in names], "m": [[round(float(v), 2) for v in row] for row in c]}
        avg_cons = float(np.mean([r["cons"] for r in rows])) if rows else 0.0
        return {"per_tf": per_tf, "gainers": sorted(rows, key=lambda r: -r["chg"])[:5], "losers": sorted(rows, key=lambda r: r["chg"])[:5],
                "volume": top_vol[:6], "volatile": sorted(rows, key=lambda r: -r["atr"])[:5], "squeeze": [r for r in rows if r["squeeze"]][:8],
                "best": sorted([r for r in rows if r["verdict"] != "WAIT"], key=lambda r: (-"DCBA".find(r["grade"]) if r["grade"] in "ABCD" else 9, -abs(r["cons"])))[:8],
                "corr": corr, "mood": int(max(0, min(100, 50 + avg_cons / 2))), "avg_cons": round(avg_cons, 1), "n": len(rows)}


def get_status() -> dict:
    with _LOCK:
        return {"cached": len(_CACHE), "last_scan": _S["last_scan"], "scanning": _S["scanning"], "duration": _S["duration"],
                "progress": dict(_S["progress"]), "errors": list(_S["errors"]), "sources": source_status()}


def start_background() -> None:
    def loop():
        time.sleep(1.0)
        start_scan(None, ["1h"])
        wait_idle()
        start_scan()
        while True:
            time.sleep(settings.get_scan_sec())
            try:
                start_scan()
            except Exception:                                # noqa: BLE001
                pass
    threading.Thread(target=loop, daemon=True, name="titan-bg").start()


def _pair_corr(a: str, b: str) -> float:
    fa, fb = _FRAMES.get(_key(a, "1h")), _FRAMES.get(_key(b, "1h"))
    if fa is None or fb is None or len(fa) < 60 or len(fb) < 60:
        return 0.0
    n = min(len(fa), len(fb), 100)
    ra, rb = np.diff(np.log(fa["close"].values[-n - 1:].astype(float))), np.diff(np.log(fb["close"].values[-n - 1:].astype(float)))
    if ra.std() == 0 or rb.std() == 0:
        return 0.0
    return float(np.corrcoef(ra, rb)[0, 1])


_LAST_LOG: dict = {}


def plan_lab(sym: str, tf: str, df, sig: dict, px: float) -> dict:
    """Entry/stop/target laboratory for both sides on one shared simulation (also used by /api/plan)."""
    ind, ex, zones = sig["indicators"], sig.get("extras") or {}, (sig.get("levels") or {}).get("zones", [])
    sim = fc_mod.simulate(df, 32, 600, f"{sym}{tf}")
    if not sim:
        return {}
    atr = float(ind["atr"]) or px * 0.01
    return {"long": planner.run(sim, "LONG", px, atr, ind, ex, zones), "short": planner.run(sim, "SHORT", px, atr, ind, ex, zones), "atr": atr, "price": px}


def _auto_pass(symbols, prices) -> None:
    cfg = policy.effective()
    ps = exchange.pause_state(prices)
    if ps["paused"]:
        if _LAST_LOG.get("*") != ps["reason"]:
            _LAST_LOG["*"] = ps["reason"]; exchange.log_auto({"symbol": "*", "ok": False, "text": ps["reason"]})
        return
    acc = exchange.get_account(prices)
    open_pos, orders, eq = acc["open_positions"], acc["orders"], max(acc["equity"], 1.0)
    # Include pending-order risk so simultaneous fills cannot breach heat limits
    risk_open = sum(p["risk_usd"] for p in open_pos if p["stage"] == 0) / eq * 100
    for od in orders:
        risk_open += float(od.get("risk_pct") or 0)
    btc = _row_fusion("BTCUSDT").get("cons") if "BTCUSDT" in symbols else None
    for o in orders:                                     # drop resting orders whose idea has been reversed
        if o["source"] == "auto":
            d = build_deep(o["symbol"], "1h", fetch_missing=False)
            if d.get("verdict") in ("LONG", "SHORT") and d["verdict"] != o["side"]:
                exchange.cancel_order(o["id"]); exchange.log_auto({"symbol": o["symbol"], "ok": False, "text": "سفارش لغو شد: جهت سیگنال برعکس شد"})
    for s in symbols:
        d = build_deep(s, "1h", fetch_missing=False)
        v = d.get("verdict")
        for p in open_pos:                               # early exit when the multi-timeframe view flipped against an unproven trade
            if p["symbol"] == s and p["source"] == "auto" and v in ("LONG", "SHORT") and v != p["side"] and p["stage"] == 0 and (d.get("conviction") or 0) >= 0.4:
                r_now = (prices.get(s, p["entry"]) - p["entry"]) * (1 if p["side"] == "LONG" else -1) / (abs(p["entry"] - p["stop0"]) or 1e-9)
                if r_now < 0.3:
                    exchange.close_position(p["id"], prices.get(s, p["entry"]), "signal_flip")
        if v not in ("LONG", "SHORT") or not d.get("signal"):
            continue
        if any(o["symbol"] == s for o in orders) or any(p["symbol"] == s for p in open_pos):
            continue
        it, df, px = _CACHE.get(_key(s, "1h")), _FRAMES.get(_key(s, "1h")), prices.get(s)
        if not it or df is None or not px:
            continue
        sig = d["signal"]; ind = sig["indicators"]; atr = float(ind["atr"]) or px * 0.01
        lab = plan_lab(s, "1h", df, sig, px)
        plan = (lab.get(v.lower()) or {}).get("best")
        dirn = 1 if v == "LONG" else -1
        x = {"symbol": s, "side": v, "verdict": v, "grade": (d.get("grade") or {}).get("grade", "—"), "cons": d.get("consensus_score", 0), "agree": sig.get("agree", 0),
             "plan": plan, "ext_atr": (px - ind["ema21"]) * dirn / atr, "rsi_extreme": (v == "LONG" and ind["rsi"] > 74) or (v == "SHORT" and ind["rsi"] < 26),
             "qv": (it.get("ticker") or {}).get("quote_volume", 0), "evidence": evidence.get(s), "open": open_pos, "n_orders": len(orders), "risk_open_pct": risk_open,
             "corr": lambda o, s=s: _pair_corr(s, o), "btc_cons": btc, "vol_hot": ((sig.get("extras") or {}).get("stats") or {}).get("vol_pct", 0) > 90}
        dec = policy.evaluate(cfg, x)
        txt = ("ثبت: " + plan["name"]) if dec["ok"] and plan else " · ".join(dec["fails"][:3])
        if dec["ok"] or _LAST_LOG.get(s) != txt:
            _LAST_LOG[s] = txt
            exchange.log_auto({"symbol": s, "verdict": v, "grade": x["grade"], "ok": dec["ok"], "text": txt})
        if not (dec["ok"] and plan):
            continue
        common = dict(leverage=10, risk_pct=dec["risk_pct"], source="auto", prices=prices, score=float(sig.get("score", 0)), regime=sig.get("regime", ""), grade=x["grade"], plan=plan["name"])
        if plan["mode"] == "market":
            r = exchange.open_position(s, v, px, plan["stop"], plan["tp1"], plan["tp2"], plan["tp3"], deadline_sec=cfg["time_stop_h"] * 3600, **common)
        else:
            r = exchange.place_order({"symbol": s, "side": v, "mode": plan["mode"], "price": plan["p"], "stop": plan["stop"], "tp1": plan["tp1"], "tp2": plan["tp2"], "tp3": plan["tp3"],
                                      "valid_h": cfg["valid_h"], "deadline_h": cfg["time_stop_h"], "leverage": 10, "risk_pct": dec["risk_pct"], "source": "auto", "grade": x["grade"],
                                      "plan": plan["name"], "score": float(sig.get("score", 0)), "regime": sig.get("regime", "")})
        if not r.get("ok"):
            exchange.log_auto({"symbol": s, "ok": False, "text": "ثبت ناموفق: " + str(r.get("error"))})
        else:
            open_pos = exchange.get_account(prices)["open_positions"]; orders = exchange.get_account(prices)["orders"]; risk_open += dec["risk_pct"]


def get_item(sym: str, tf: str) -> dict | None:
    with _LOCK:
        return _CACHE.get(_key(sym, tf))

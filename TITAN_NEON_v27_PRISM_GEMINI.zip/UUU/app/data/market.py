"""Resilient multi-source market data: TTL cache, per-source circuit breaker,
bulk tickers, closed-candle helper. No API keys needed."""
from __future__ import annotations
import threading
import time
from collections import defaultdict
from typing import Any

import pandas as pd
import requests

_SESSION = requests.Session()
_SESSION.headers.update({"User-Agent": "Mozilla/5.0 (compatible; TitanPro/2.0)", "Accept": "application/json"})
_ADAPTER = requests.adapters.HTTPAdapter(pool_connections=16, pool_maxsize=32)
_SESSION.mount("https://", _ADAPTER)

_ALIASES = {"XAUTUSDT": ["XAUTUSDT", "PAXGUSDT"], "MATICUSDT": ["POLUSDT", "MATICUSDT"]}
_IV_SEC = {"1m": 60, "5m": 300, "15m": 900, "30m": 1800, "1h": 3600, "4h": 14400, "1d": 86400}
_MEXC_IV = {"1h": "60m"}                      # MEXC spot does NOT accept "1h"
_BYBIT_IV = {"1m": "1", "5m": "5", "15m": "15", "30m": "30", "1h": "60", "4h": "240", "1d": "D"}
_TTL = {"15m": 40, "1h": 90, "4h": 240, "1d": 600}
_STALE_MAX = 900.0

SOURCES = ["mexc", "binance", "bybit", "gate"]


class NoSymbol(Exception):
    """Symbol unknown on this exchange — must not penalise the source."""


# ───────────────────────── source health / circuit breaker ─────────────────────────
_H_LOCK = threading.Lock()
_HEALTH: dict[str, dict] = {s: {"ok": 0, "fail": 0, "streak": 0, "cool_until": 0.0,
                                "last_ok": 0.0, "last_err": "", "lat_ms": 0} for s in SOURCES}


def _cooling(name: str) -> bool:
    return _HEALTH[name]["cool_until"] > time.time()


def _mark(name: str, ok: bool, lat: float = 0.0, err: str = "") -> None:
    with _H_LOCK:
        h = _HEALTH[name]
        if ok:
            h.update(ok=h["ok"] + 1, streak=0, cool_until=0.0, last_ok=time.time(), lat_ms=int(lat * 1000))
        else:
            h["fail"] += 1
            h["streak"] += 1
            h["last_err"] = err[:120]
            if h["streak"] >= 3:
                h["cool_until"] = time.time() + min(180, 20 * h["streak"])


def source_status() -> dict[str, dict]:
    with _H_LOCK:
        now = time.time()
        return {k: {**v, "cooling": v["cool_until"] > now} for k, v in _HEALTH.items()}


def _get(url: str, params: dict | None = None, timeout: tuple = (3.5, 7.0)) -> Any:
    r = _SESSION.get(url, params=params, timeout=timeout)
    if r.status_code in (400, 404):
        raise NoSymbol(f"HTTP {r.status_code}")
    if r.status_code != 200:
        raise RuntimeError(f"HTTP {r.status_code}")
    return r.json()


# ───────────────────────────────── parsers ─────────────────────────────────
def _finish(df: pd.DataFrame) -> pd.DataFrame:
    for c in ("open", "high", "low", "close", "volume"):
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna().drop_duplicates("open_time").sort_values("open_time").reset_index(drop=True)
    return df[(df["high"] >= df["low"]) & (df["close"] > 0)].reset_index(drop=True)


def _parse_binance(rows: list) -> pd.DataFrame:
    data = [r[:6] for r in rows if isinstance(r, (list, tuple)) and len(r) >= 6]
    df = pd.DataFrame(data, columns=["open_time", "open", "high", "low", "close", "volume"])
    df["open_time"] = pd.to_datetime(pd.to_numeric(df["open_time"], errors="coerce"), unit="ms", errors="coerce")
    return _finish(df)


def _parse_bybit(data: dict) -> pd.DataFrame:
    lst = (data.get("result") or {}).get("list") or []
    rows = [{"open_time": pd.to_datetime(int(i[0]), unit="ms"), "open": i[1], "high": i[2],
             "low": i[3], "close": i[4], "volume": i[5]} for i in lst if len(i) >= 6]
    return _finish(pd.DataFrame(rows)) if rows else pd.DataFrame()


def _parse_gate(raw: list) -> pd.DataFrame:
    # [t, quote_vol, close, high, low, open, base_vol, closed]
    rows = [{"open_time": pd.to_datetime(int(i[0]), unit="s"), "open": i[5], "high": i[3], "low": i[4],
             "close": i[2], "volume": i[6] if len(i) > 6 else i[1]} for i in raw if len(i) >= 6]
    return _finish(pd.DataFrame(rows)) if rows else pd.DataFrame()


def _cands(symbol: str) -> list[str]:
    s = symbol.upper().replace("/", "")
    return _ALIASES.get(s, [s])


# ───────────────────────────────── klines ─────────────────────────────────
_KCACHE: dict[tuple, tuple[float, pd.DataFrame]] = {}
_KLOCKS: dict[tuple, threading.Lock] = defaultdict(threading.Lock)


def _download(sym: str, interval: str, limit: int) -> pd.DataFrame | None:
    base = sym[:-4]
    sources = [
        ("mexc", "https://api.mexc.com/api/v3/klines",
         {"symbol": sym, "interval": _MEXC_IV.get(interval, interval), "limit": limit}, "binance"),
        ("binance", "https://data-api.binance.vision/api/v3/klines",
         {"symbol": sym, "interval": interval, "limit": limit}, "binance"),
        ("bybit", "https://api.bybit.com/v5/market/kline",
         {"category": "spot", "symbol": sym, "interval": _BYBIT_IV.get(interval, "60"), "limit": limit}, "bybit"),
        ("gate", "https://api.gateio.ws/api/v4/spot/candlesticks",
         {"currency_pair": f"{base}_USDT", "interval": interval, "limit": limit}, "gate"),
    ]
    live = [s for s in sources if not _cooling(s[0])] or sources
    for name, url, params, kind in live:
        t0 = time.time()
        try:
            raw = _get(url, params)
            if kind == "binance":
                df = _parse_binance(raw) if isinstance(raw, list) else pd.DataFrame()
            elif kind == "bybit":
                df = _parse_bybit(raw) if isinstance(raw, dict) else pd.DataFrame()
            else:
                df = _parse_gate(raw) if isinstance(raw, list) else pd.DataFrame()
            if len(df) >= 30:
                _mark(name, True, time.time() - t0)
                return df
        except NoSymbol:
            continue
        except Exception as e:                              # noqa: BLE001
            _mark(name, False, err=str(e))
    return None


def fetch_klines(symbol: str, interval: str = "1h", limit: int = 300, use_cache: bool = True) -> pd.DataFrame:
    sym0 = symbol.upper().replace("/", "")
    key = (sym0, interval)
    ttl = _TTL.get(interval, 90)
    now = time.time()
    hit = _KCACHE.get(key)
    if use_cache and hit and now - hit[0] < ttl and len(hit[1]) >= min(limit, 60):
        return hit[1]
    with _KLOCKS[key]:
        hit = _KCACHE.get(key)
        if use_cache and hit and time.time() - hit[0] < ttl:
            return hit[1]
        for sym in _cands(sym0):
            df = _download(sym, interval, limit)
            if df is not None:
                _KCACHE[key] = (time.time(), df)
                return df
        if hit and time.time() - hit[0] < _STALE_MAX:       # serve stale rather than nothing
            stale = hit[1].copy()
            stale.attrs["stale"] = True
            return stale
    raise RuntimeError(f"klines failed {symbol} {interval}")


def closed_only(df: pd.DataFrame, interval: str) -> pd.DataFrame:
    """Drop the still-forming last candle so indicators never repaint.
    Also flag obvious gaps / bad OHLC on the remaining frame."""
    if df is None or len(df) < 3:
        return df
    sec = _IV_SEC.get(interval, 3600)
    last_open = df["open_time"].iloc[-1].timestamp()
    out = df
    if last_open + sec > time.time() + 1:
        out = df.iloc[:-1].reset_index(drop=True)
    # Detect large time gaps (missing candles) — mark attribute, do not invent bars
    if len(out) >= 5 and "open_time" in out.columns:
        deltas = out["open_time"].diff().dt.total_seconds().dropna()
        expected = float(sec)
        gaps = int((deltas > expected * 1.6).sum()) if len(deltas) else 0
        out.attrs["gaps"] = gaps
        # Age of newest closed bar
        age = time.time() - out["open_time"].iloc[-1].timestamp() - expected
        out.attrs["data_age_sec"] = max(0.0, float(age))
        if age > expected * 2:
            out.attrs["stale"] = True
    return out


# ───────────────────────────────── tickers ─────────────────────────────────
_TCACHE: dict[str, Any] = {"ts": 0.0, "data": {}}
_T_LOCK = threading.Lock()


def _tk(sym, price, ch, hi, lo, vol, qv) -> dict:
    return {"symbol": sym, "price": float(price), "change_pct": float(ch or 0), "high": float(hi or 0),
            "low": float(lo or 0), "volume": float(vol or 0), "quote_volume": float(qv or 0)}


def _bulk_tickers() -> dict[str, dict]:
    out: dict[str, dict] = {}
    if not _cooling("mexc"):
        t0 = time.time()
        try:
            data = _get("https://api.mexc.com/api/v3/ticker/24hr", timeout=(3.5, 10))
            for d in data if isinstance(data, list) else []:
                s = d.get("symbol", "")
                if s.endswith("USDT") and float(d.get("lastPrice") or 0) > 0:
                    out[s] = _tk(s, d["lastPrice"], d.get("priceChangePercent"), d.get("highPrice"),
                                 d.get("lowPrice"), d.get("volume"), d.get("quoteVolume"))
            if out:
                _mark("mexc", True, time.time() - t0)
        except Exception as e:                              # noqa: BLE001
            _mark("mexc", False, err=str(e))
    if len(out) < 5 and not _cooling("bybit"):
        try:
            data = _get("https://api.bybit.com/v5/market/tickers", {"category": "spot"}, timeout=(3.5, 10))
            for d in (data.get("result") or {}).get("list") or []:
                s = d.get("symbol", "")
                if s.endswith("USDT") and float(d.get("lastPrice") or 0) > 0:
                    out[s] = _tk(s, d["lastPrice"], float(d.get("price24hPcnt") or 0) * 100,
                                 d.get("highPrice24h"), d.get("lowPrice24h"), d.get("volume24h"), d.get("turnover24h"))
            if out:
                _mark("bybit", True)
        except Exception as e:                              # noqa: BLE001
            _mark("bybit", False, err=str(e))
    return out


def fetch_tickers(symbols: list[str], max_age: float = 15.0) -> dict[str, dict]:
    """One bulk call instead of one request per coin/timeframe."""
    with _T_LOCK:
        if time.time() - _TCACHE["ts"] > max_age:
            fresh = _bulk_tickers()
            if fresh:
                _TCACHE.update(ts=time.time(), data=fresh)
        data = _TCACHE["data"]
    res = {}
    for s in symbols:
        key = s.upper().replace("/", "")
        for c in _cands(key):
            if c in data:
                res[key] = {**data[c], "symbol": key}
                break
    return res


def fetch_ticker(symbol: str) -> dict:
    key = symbol.upper().replace("/", "")
    got = fetch_tickers([key]).get(key)
    if got:
        return got
    df = fetch_klines(key, "1h", 60)
    px = float(df["close"].iloc[-1])
    return {"symbol": key, "price": px, "change_pct": 0.0, "high": px, "low": px, "volume": 0.0, "quote_volume": 0.0}


def fetch_prices(symbols: list[str]) -> dict[str, float]:
    tk = fetch_tickers(symbols)
    return {k: v["price"] for k, v in tk.items()}


# ───────────────────────── order book depth + derivatives (public, no keys) ─────────────────────────
_DEPTH_CACHE: dict[str, tuple[float, dict]] = {}
_DERIV_CACHE: dict[str, tuple[float, dict]] = {}


def _book(raw: dict, kind: str) -> tuple[list, list]:
    if kind == "bybit":
        res = raw.get("result") or {}
        b, a = res.get("b") or [], res.get("a") or []
    else:
        b, a = raw.get("bids") or [], raw.get("asks") or []
    bids = sorted(((float(x[0]), float(x[1])) for x in b if len(x) >= 2), key=lambda x: -x[0])
    asks = sorted(((float(x[0]), float(x[1])) for x in a if len(x) >= 2), key=lambda x: x[0])
    return bids, asks


def depth_metrics(bids: list, asks: list) -> dict:
    """Pure function (unit-testable): imbalance, spread, walls and cumulative curves."""
    if not bids or not asks:
        return {"ok": False}
    bb, ba = bids[0][0], asks[0][0]
    mid = (bb + ba) / 2

    def within(side, pct):
        return sum(p * q for p, q in side if abs(p / mid - 1) <= pct / 100)
    b1, a1 = within(bids, 1.0), within(asks, 1.0)
    b025, a025 = within(bids, 0.25), within(asks, 0.25)

    def walls(side):
        top = sorted(side, key=lambda x: -x[0] * x[1])[:3]
        return [{"p": float(f"{p:.8g}"), "usd": round(p * q), "dist_pct": round((p / mid - 1) * 100, 3)} for p, q in top]

    def curve(side):
        out, cum = [], 0.0
        for p, q in side:
            cum += p * q
            out.append([float(f"{p:.8g}"), round(cum)])
        step = max(1, len(out) // 40)
        return out[::step]
    return {"ok": True, "mid": float(f"{mid:.8g}"), "bid": bb, "ask": ba, "spread_pct": round((ba - bb) / mid * 100, 4),
            "bid_usd_1pct": round(b1), "ask_usd_1pct": round(a1), "imb_1pct": round((b1 - a1) / (b1 + a1 + 1e-9), 3),
            "imb_025pct": round((b025 - a025) / (b025 + a025 + 1e-9), 3),
            "bid_walls": walls(bids), "ask_walls": walls(asks), "bid_curve": curve(bids), "ask_curve": curve(asks)}


def fetch_depth(symbol: str, limit: int = 100) -> dict:
    sym = symbol.upper().replace("/", "")
    hit = _DEPTH_CACHE.get(sym)
    if hit and time.time() - hit[0] < 8:
        return hit[1]
    srcs = [("mexc", "https://api.mexc.com/api/v3/depth", {"symbol": sym, "limit": limit}, "binance"),
            ("binance", "https://data-api.binance.vision/api/v3/depth", {"symbol": sym, "limit": limit}, "binance"),
            ("bybit", "https://api.bybit.com/v5/market/orderbook", {"category": "spot", "symbol": sym, "limit": min(limit, 200)}, "bybit")]
    for name, url, params, kind in [s for s in srcs if not _cooling(s[0])] or srcs:
        t0 = time.time()
        try:
            raw = _get(url, params)
            bids, asks = _book(raw if isinstance(raw, dict) else {}, kind)
            m = depth_metrics(bids, asks)
            if m.get("ok"):
                _mark(name, True, time.time() - t0)
                m["source"] = name
                _DEPTH_CACHE[sym] = (time.time(), m)
                return m
        except NoSymbol:
            continue
        except Exception as e:                              # noqa: BLE001
            _mark(name, False, err=str(e))
    return hit[1] if hit else {"ok": False}


def fetch_derivs(symbol: str) -> dict:
    """Perpetual funding, open interest, basis and long/short account ratio (Bybit linear, public)."""
    sym = symbol.upper().replace("/", "")
    hit = _DERIV_CACHE.get(sym)
    if hit and time.time() - hit[0] < 45:
        return hit[1]
    out: dict = {"ok": False}
    try:
        raw = _get("https://api.bybit.com/v5/market/tickers", {"category": "linear", "symbol": sym})
        lst = ((raw or {}).get("result") or {}).get("list") or []
        if not lst:
            out = {"ok": False, "reason": "no_perp"}
        else:
            d = lst[0]
            fr = float(d.get("fundingRate") or 0)
            mark, idx = float(d.get("markPrice") or 0), float(d.get("indexPrice") or 0)
            out = {"ok": True, "funding_pct": round(fr * 100, 4), "funding_apr": round(fr * 3 * 365 * 100, 1),
                   "oi_usd": round(float(d.get("openInterestValue") or 0)), "mark": mark, "index": idx,
                   "basis_pct": round((mark / idx - 1) * 100, 4) if idx else 0.0,
                   "next_funding": int(d.get("nextFundingTime") or 0), "turnover_24h": round(float(d.get("turnover24h") or 0))}
            try:
                lr = _get("https://api.bybit.com/v5/market/account-ratio", {"category": "linear", "symbol": sym, "period": "1h", "limit": 24})
                rows = ((lr or {}).get("result") or {}).get("list") or []
                hist = [float(x["buyRatio"]) for x in reversed(rows) if "buyRatio" in x]
                if hist:
                    out["ls_buy"], out["ls_hist"] = round(hist[-1], 4), [round(x, 4) for x in hist]
            except Exception:                               # noqa: BLE001 - ratio is optional
                pass
            _mark("bybit", True)
    except NoSymbol:
        out = {"ok": False, "reason": "no_perp"}
    except Exception as e:                                  # noqa: BLE001
        _mark("bybit", False, err=str(e))
        out = hit[1] if hit else {"ok": False, "reason": "unreachable"}
    if out.get("ok") or out.get("reason") == "no_perp":
        _DERIV_CACHE[sym] = (time.time(), out)
    return out

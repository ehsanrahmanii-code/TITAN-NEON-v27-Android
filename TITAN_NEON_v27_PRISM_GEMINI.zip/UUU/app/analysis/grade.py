"""Multi-timeframe fusion helpers + an explainable setup grade (A-D).
The grade is a checklist, not a probability: every point is shown to the user with its reason."""
from __future__ import annotations
from app.config import TF_WEIGHT, SIDE_THRESHOLD as TH


def fuse(scores: dict[str, float]) -> tuple[float, str, str]:
    """Hierarchical multi-TF decision:
    1d = market direction, 4h = structure, 1h = setup, 15m = timing.
    Higher-TF opposition hard-vetoes trend entries; mean-reversion still possible
    only when HTF is flat (not strongly opposed)."""
    wsum = sum(TF_WEIGHT.get(t, .2) for t in scores)
    cons = sum(TF_WEIGHT.get(t, .2) * s for t, s in scores.items()) / wsum if wsum else 0.0
    side = "LONG" if cons >= TH else "SHORT" if cons <= -TH else "WAIT"
    note = ""
    htf = {t: scores[t] for t in ("4h", "1d") if t in scores}
    if side != "WAIT" and htf:
        opp_hard = [t for t, b in htf.items() if (b <= -TH and side == "LONG") or (b >= TH and side == "SHORT")]
        if len(opp_hard) == len(htf):
            note, side = "تایم‌فریم‌های بزرگ‌تر خلاف جهت‌اند → وتو", "WAIT"
        elif opp_hard and abs(cons) < TH + 12:
            # Soft conflict with only moderate consensus → wait
            note, side = f"تعارض با {','.join(opp_hard)} و اجماع ضعیف → انتظار", "WAIT"
        elif "1d" in htf:
            d1 = htf["1d"]
            if (side == "LONG" and d1 < -TH * 0.7) or (side == "SHORT" and d1 > TH * 0.7):
                note, side = "جهت روزانه مخالف است → وتو", "WAIT"
    # 15m alone must not drive a trade against 1h
    if side != "WAIT" and "1h" in scores and "15m" in scores:
        if abs(scores.get("15m", 0)) > abs(scores.get("1h", 0)) + 15:
            if (scores["1h"] > 8 and side == "SHORT") or (scores["1h"] < -8 and side == "LONG"):
                note, side = "۱۵م برخلاف ساختار ۱ساعته است → انتظار", "WAIT"
    return cons, side, note


def grade_from(sigs: dict[str, dict], fcs: dict[str, dict], side: str, cons: float, ptf: str = "1h") -> dict:
    """sigs/fcs are the dict forms (Signal.to_dict(), forecast_summary())."""
    if side == "WAIT" or ptf not in sigs:
        return {"grade": "—", "points": 0, "why": [], "aligned": 0}
    pts, why = 0, []

    def add(n, text):
        nonlocal pts
        pts += n
        why.append({"p": n, "t": text})

    a = abs(cons)
    if a >= 55: add(2, f"اجماع قوی ({cons:+.0f})")
    elif a >= 42: add(1, f"اجماع متوسط ({cons:+.0f})")
    else: add(0, f"اجماع ضعیف ({cons:+.0f})")
    same = [t for t, s in sigs.items() if s["side"] == side]
    opp = [t for t, s in sigs.items() if s["side"] not in (side, "WAIT")]
    big_opp = [t for t in opp if t in ("4h", "1d")]
    if len(same) >= 3: add(2, f"{len(same)} تایم‌فریم هم‌جهت")
    elif len(same) == 2: add(1, "۲ تایم‌فریم هم‌جهت")
    else: add(0, "فقط یک تایم‌فریم هم‌جهت")
    if big_opp: add(-2, "تایم‌فریم بزرگ مخالف: " + "،".join(big_opp))
    p = sigs[ptf]
    if p.get("regime") == "trend" and p["side"] == side: add(1, "رژیم روندی و هم‌جهت")
    if p.get("agree", 0) >= 0.75: add(1, f"هم‌سویی مولفه‌ها {p['agree'] * 100:.0f}٪")
    f = fcs.get(ptf) or {}
    if f.get("alignment") == "aligned": add(1, "پیش‌بینی ۳۲ کندل هم‌جهت")
    elif f.get("alignment") == "divergent": add(-1, "پیش‌بینی ۳۲ کندل مخالف")
    e = f.get("edge") if p["side"] == side else None
    if e:
        if e["p_tp1"] >= 0.5: add(1, f"احتمال رسیدن به TP1 {e['p_tp1'] * 100:.0f}٪")
        if e["ev_r"] < -0.15: add(-1, f"امید ریاضی شبیه‌سازی منفی ({e['ev_r']:+.2f}R)")
    ps = ((p.get("extras") or {}).get("pat") or {})
    if ps.get("items") and abs(ps.get("score", 0)) >= 35:
        aligned = (ps["score"] > 0) == (side == "LONG")
        add(1 if aligned else -1, ("الگوی تاییدکننده: " if aligned else "الگوی مخالف: ") + "، ".join(ps["items"][:2]))
    rr = p.get("risk_reward", 0)
    if rr >= 2.2: add(2, f"R:R عالی ({rr:.1f})")
    elif rr >= 1.7: add(1, f"R:R خوب ({rr:.1f})")
    elif rr < 1.25: add(-1, f"R:R ضعیف ({rr:.1f})")
    ek = (p.get("indicators") or {}).get("entry_kind") or (p.get("levels") or {}).get("entry_kind")
    if ek == "limit":
        add(1, "ورود لیمیت روی ساختار (بهبود R:R و کاهش chase)")
    if p.get("regime") == "trend" and abs(cons) >= 40 and p.get("agree", 0) >= 0.6:
        add(1, "روند قوی + اجماع مولفه‌ها")
    if len(p.get("warnings", [])) >= 3: add(-1, "هشدارهای متعدد")
    # Cap grade inflation; still A only for truly clean multi-factor setups
    g = "A" if pts >= 8 else "B" if pts >= 5 else "C" if pts >= 2 else "D"
    return {"grade": g, "points": pts, "why": why, "aligned": len(same)}

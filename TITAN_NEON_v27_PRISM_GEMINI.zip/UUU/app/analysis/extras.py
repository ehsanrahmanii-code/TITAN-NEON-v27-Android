"""Extra analytics per (symbol, timeframe): Ichimoku, Fibonacci, pivots, volume profile and
return statistics. Pure functions of the closed-candle frame - no network, no randomness."""
from __future__ import annotations
import numpy as np
import pandas as pd


def _g(x: float) -> float:
    return float(f"{float(x):.8g}")


def ichimoku(df: pd.DataFrame) -> dict:
    h, l, c = df["high"], df["low"], df["close"]
    tk = (h.rolling(9).max() + l.rolling(9).min()) / 2
    kj = (h.rolling(26).max() + l.rolling(26).min()) / 2
    sa = (tk + kj) / 2
    sb = (h.rolling(52).max() + l.rolling(52).min()) / 2
    if len(df) < 80 or np.isnan(sb.iloc[-1]) or np.isnan(sa.iloc[-27]) or np.isnan(sb.iloc[-27]):
        return {}
    a_now, b_now = float(sa.iloc[-27]), float(sb.iloc[-27])         # cloud drawn above the present bar
    top, bot = max(a_now, b_now), min(a_now, b_now)
    px = float(c.iloc[-1])
    pos = 1 if px > top else -1 if px < bot else 0
    t, k = float(tk.iloc[-1]), float(kj.iloc[-1])
    cross = 1 if (tk.iloc[-1] > kj.iloc[-1] and tk.iloc[-2] <= kj.iloc[-2]) else -1 if (tk.iloc[-1] < kj.iloc[-1] and tk.iloc[-2] >= kj.iloc[-2]) else 0
    chikou = 1 if px > float(c.iloc[-27]) else -1
    return {"tenkan": _g(t), "kijun": _g(k), "cloud_top": _g(top), "cloud_bot": _g(bot), "pos": pos, "tk_cross": cross,
            "future_bull": bool(sa.iloc[-1] > sb.iloc[-1]), "chikou": chikou,
            "thick_pct": round((top - bot) / px * 100, 3)}


def fibonacci(df: pd.DataFrame, look: int = 120) -> dict:
    d = df.tail(look)
    if len(d) < 30:
        return {}
    hi_i, lo_i = int(np.argmax(d["high"].values)), int(np.argmin(d["low"].values))
    hi, lo = float(d["high"].values[hi_i]), float(d["low"].values[lo_i])
    if hi <= lo:
        return {}
    up = lo_i < hi_i                               # last swing was upward -> retracements measured down from the high
    rs = (0.236, 0.382, 0.5, 0.618, 0.786)
    lv = [{"r": r, "p": _g(hi - r * (hi - lo) if up else lo + r * (hi - lo))} for r in rs]
    ext = [{"r": r, "p": _g(hi + (r - 1) * (hi - lo) if up else lo - (r - 1) * (hi - lo))} for r in (1.272, 1.618)]
    px = float(d["close"].iloc[-1])
    pos = (px - lo) / (hi - lo)
    near = min(lv, key=lambda x: abs(x["p"] - px))
    return {"dir": "up" if up else "down", "hi": _g(hi), "lo": _g(lo), "levels": lv, "ext": ext, "pos": round(pos, 3),
            "near": near, "bars_since": len(d) - 1 - max(hi_i, lo_i)}


_PIV_N = {"15m": 96, "1h": 24, "4h": 6, "1d": 7}


def pivots(df: pd.DataFrame, tf: str) -> dict:
    n = _PIV_N.get(tf, 24)
    if len(df) < 2 * n + 2:
        return {}
    prev = df.iloc[-2 * n:-n]
    H, L, C = float(prev["high"].max()), float(prev["low"].min()), float(prev["close"].iloc[-1])
    p = (H + L + C) / 3
    rng = H - L
    return {"p": _g(p), "r1": _g(2 * p - L), "r2": _g(p + rng), "r3": _g(H + 2 * (p - L)),
            "s1": _g(2 * p - H), "s2": _g(p - rng), "s3": _g(L - 2 * (H - p)), "span": n}


def volume_profile(df: pd.DataFrame, look: int = 150, bins: int = 36) -> dict:
    d = df.tail(look)
    if len(d) < 30:
        return {}
    lo, hi = float(d["low"].min()), float(d["high"].max())
    if hi <= lo:
        return {}
    edges = np.linspace(lo, hi, bins + 1)
    vol = np.zeros(bins)
    for h, l, v in zip(d["high"].values, d["low"].values, d["volume"].values):
        a = min(bins - 1, int((l - lo) / (hi - lo) * bins))
        b = min(bins - 1, int((h - lo) / (hi - lo) * bins))
        vol[a:b + 1] += v / (b - a + 1)
    poc = int(np.argmax(vol))
    tot, acc, i0, i1 = vol.sum(), vol[poc], poc, poc
    while acc < 0.7 * tot and (i0 > 0 or i1 < bins - 1):
        up = vol[i1 + 1] if i1 < bins - 1 else -1
        dn = vol[i0 - 1] if i0 > 0 else -1
        if up >= dn:
            i1 += 1; acc += up
        else:
            i0 -= 1; acc += dn
    mid = (edges[:-1] + edges[1:]) / 2
    mx = vol.max() or 1
    return {"poc": _g(mid[poc]), "vah": _g(edges[i1 + 1]), "val": _g(edges[i0]),
            "bins": [{"p": _g(m), "v": round(float(v / mx), 3)} for m, v in zip(mid, vol)]}


def stats(df: pd.DataFrame) -> dict:
    c = df["close"].astype(float)
    r = c.pct_change().dropna().tail(200)
    if len(r) < 40:
        return {}
    h, l = df["high"].astype(float), df["low"].astype(float)
    atrp = ((h - l) / c).rolling(14).mean().dropna().tail(120)
    cur = float(atrp.iloc[-1]) if len(atrp) else 0.0
    vol_pct = float((atrp < cur).mean() * 100) if len(atrp) > 10 else 50.0
    r4 = c.pct_change(4).dropna().tail(200)
    vr = float(r4.var() / (4 * r.var() + 1e-18))
    d100 = df.tail(100)
    hi100, lo100 = float(d100["high"].max()), float(d100["low"].min())
    px = float(c.iloc[-1])
    sign = np.sign((df["close"] - df["open"]).values)
    streak = 1
    for i in range(len(sign) - 2, -1, -1):
        if sign[i] == sign[-1] and sign[i] != 0:
            streak += 1
        else:
            break
    o = df["open"].astype(float)
    body = (c - o).abs()
    rng = (h - l).replace(0, np.nan)
    return {"vol_pct": round(vol_pct, 1), "skew": round(float(r.skew()), 2), "kurt": round(float(r.kurt()), 2),
            "ac1": round(float(r.autocorr(1)), 3), "vr4": round(vr, 2),
            "dd_from_high": round((px / hi100 - 1) * 100, 2), "up_from_low": round((px / lo100 - 1) * 100, 2),
            "range_pos": round((px - lo100) / (hi100 - lo100 + 1e-12), 3),
            "streak": int(streak * (sign[-1] if sign[-1] else 0)), "avg_range_pct": round(float(((h - l) / c).tail(20).mean() * 100), 3),
            "up_ratio": round(float((sign[-50:] > 0).mean()), 3), "body_ratio": round(float((body / rng).tail(20).mean()), 2),
            "best_pct": round(float(r.max() * 100), 2), "worst_pct": round(float(r.min() * 100), 2),
            "hurst_hint": "روندی" if vr > 1.15 else "بازگشتی" if vr < 0.85 else "تصادفی"}


def flow(df: pd.DataFrame, look: int = 60) -> dict:
    """Order-flow proxies from candles only: close-location-value delta volume (CVD), OBV, spikes, divergences."""
    d = df.tail(max(look + 45, 100))
    if len(d) < 50:
        return {}
    o, h, l, c, v = (d[k].values.astype(float) for k in ("open", "high", "low", "close", "volume"))
    rng = np.where(h - l > 0, h - l, np.nan)
    clv = np.nan_to_num(((c - l) - (h - c)) / rng)
    delta = v * clv
    cvd = np.cumsum(delta)
    obv = np.cumsum(np.sign(np.diff(c, prepend=c[0])) * v)
    vavg = float(np.mean(v[-60:])) or 1.0

    def div(a, b, n=20):                                  # price extreme vs flow extreme: last n vs the n before
        pa, pb = a[-n:], a[-2 * n:-n]
        fa, fb = b[-n:], b[-2 * n:-n]
        if l[-n:].min() < l[-2 * n:-n].min() and fa.min() > fb.min():
            return "bull"
        if h[-n:].max() > h[-2 * n:-n].max() and fa.max() < fb.max():
            return "bear"
        return None
    sp = [i for i in range(len(v) - look, len(v)) if v[i] >= 2.0 * np.mean(v[max(0, i - 20):i] if i > 3 else v[:4])]
    t = d["open_time"]
    pos, neg = float(np.clip(delta[-20:], 0, None).sum()), float(-np.clip(delta[-20:], None, 0).sum())
    cv = cvd[-look:] - cvd[-look:].min()
    sc = cv / (cv.max() or 1)
    pr = c[-look:]
    return {"cvd": [round(float(x), 3) for x in sc[::2]], "price": [float(f"{x:.8g}") for x in pr[::2]],
            "buy_share": round(pos / (pos + neg + 1e-12), 3), "div": div(c, cvd), "obv_div": div(c, obv),
            "cvd_slope": round(float(np.polyfit(np.arange(20), cvd[-20:], 1)[0] / vavg), 3),
            "rel_vol": round(float(v[-1] / vavg), 2), "rel_vol5": round(float(np.mean(v[-5:]) / vavg), 2),
            "spikes": [{"ago": int(len(v) - 1 - i), "ratio": round(float(v[i] / vavg), 1), "up": bool(c[i] >= o[i]), "t": int(t.iloc[i].timestamp() * 1000)} for i in sp[-5:]][::-1]}


# ───────────────────────── smart-money structure (swings, BOS/CHoCH, FVG, order blocks, liquidity) ─────────────────────────
def _swings(df: pd.DataFrame, k: int = 3):
    h, l = df["high"].values.astype(float), df["low"].values.astype(float)
    sh, sl = [], []
    for i in range(k, len(df) - k):
        if h[i] == h[i - k:i + k + 1].max() and h[i] > h[i - 1]:
            sh.append(i)
        if l[i] == l[i - k:i + k + 1].min() and l[i] < l[i - 1]:
            sl.append(i)
    return sh, sl


def smc(df: pd.DataFrame, look: int = 160) -> dict:
    d = df.tail(look).reset_index(drop=True)
    n = len(d)
    if n < 60:
        return {}
    o, h, l, c = (d[k].values.astype(float) for k in ("open", "high", "low", "close"))
    tr = np.maximum(h[1:] - l[1:], np.maximum(np.abs(h[1:] - c[:-1]), np.abs(l[1:] - c[:-1])))
    atr = float(np.mean(tr[-14:])) or 1e-9
    px = c[-1]
    sh, sl = _swings(d, 3)
    out: dict = {"atr": _g(atr)}
    # structure from the last two swing highs / lows
    trend, label = "range", "رنج"
    if len(sh) >= 2 and len(sl) >= 2:
        hh, hl = h[sh[-1]] > h[sh[-2]], l[sl[-1]] > l[sl[-2]]
        lh, ll = h[sh[-1]] < h[sh[-2]], l[sl[-1]] < l[sl[-2]]
        if hh and hl: trend, label = "bull", "HH + HL (صعودی)"
        elif lh and ll: trend, label = "bear", "LH + LL (نزولی)"
        elif hh and ll: trend, label = "expand", "گسترش نوسان"
        elif lh and hl: trend, label = "squeeze", "فشردگی (LH + HL)"
    out["structure"] = {"trend": trend, "label": label,
                        "last_high": _g(h[sh[-1]]) if sh else None, "last_low": _g(l[sl[-1]]) if sl else None,
                        "prev_high": _g(h[sh[-2]]) if len(sh) > 1 else None, "prev_low": _g(l[sl[-2]]) if len(sl) > 1 else None}
    # BOS / CHoCH: latest close beyond the most recent opposing swing (only swings that are at least 3 bars old are "confirmed")
    ev = None
    for i in range(n - 1, max(n - 40, 8), -1):
        ph = [j for j in sh if j < i - 1]; pl = [j for j in sl if j < i - 1]
        if not ph or not pl:
            continue
        up = c[i] > h[ph[-1]] and c[i - 1] <= h[ph[-1]]
        dn = c[i] < l[pl[-1]] and c[i - 1] >= l[pl[-1]]
        if up or dn:
            prior_bull = len(ph) >= 2 and len(pl) >= 2 and l[pl[-1]] > l[pl[-2]] and h[ph[-1]] > h[ph[-2]]
            prior_bear = len(ph) >= 2 and len(pl) >= 2 and l[pl[-1]] < l[pl[-2]] and h[ph[-1]] < h[ph[-2]]
            if up:
                kind = "CHoCH" if prior_bear else "BOS"; lvl = h[ph[-1]]
            else:
                kind = "CHoCH" if prior_bull else "BOS"; lvl = l[pl[-1]]
            ev = {"kind": kind, "dir": "up" if up else "down", "level": _g(lvl), "ago": int(n - 1 - i)}
            break
    out["event"] = ev
    # fair-value gaps (3-candle imbalances) that price has not fully refilled
    fvg = []
    for i in range(max(2, n - 90), n):
        if l[i] > h[i - 2] and c[i - 1] > o[i - 1]:
            lo_z, hi_z, kind = h[i - 2], l[i], "bull"
        elif h[i] < l[i - 2] and c[i - 1] < o[i - 1]:
            lo_z, hi_z, kind = h[i], l[i - 2], "bear"
        else:
            continue
        if (hi_z - lo_z) < 0.25 * atr:
            continue
        after_l, after_h = (l[i + 1:].min() if i + 1 < n else px), (h[i + 1:].max() if i + 1 < n else px)
        filled = (after_l <= lo_z) if kind == "bull" else (after_h >= hi_z)
        if filled:
            continue
        part = (after_l < hi_z) if kind == "bull" else (after_h > lo_z)
        fvg.append({"kind": kind, "lo": _g(lo_z), "hi": _g(hi_z), "ago": int(n - 1 - i), "size_atr": round((hi_z - lo_z) / atr, 2), "partial": bool(part)})
    fvg.sort(key=lambda z: min(abs(z["lo"] - px), abs(z["hi"] - px)))
    out["fvg"] = fvg[:6]
    # order blocks: last opposite candle before an impulsive displacement that broke a swing
    obs = []
    for i in range(max(3, n - 100), n - 3):
        imp_up = c[i + 1:i + 4].max() - c[i] > 1.6 * atr and c[i] < o[i]
        imp_dn = c[i] - c[i + 1:i + 4].min() > 1.6 * atr and c[i] > o[i]
        if not (imp_up or imp_dn):
            continue
        kind = "bull" if imp_up else "bear"
        zlo, zhi = (l[i], max(o[i], c[i])) if imp_up else (min(o[i], c[i]), h[i])
        later = c[i + 1:]
        if (kind == "bull" and later.min() < zlo) or (kind == "bear" and later.max() > zhi):
            continue                                               # mitigated / invalidated
        obs.append({"kind": kind, "lo": _g(zlo), "hi": _g(zhi), "ago": int(n - 1 - i), "touched": bool((l[i + 4:] <= zhi).any() if kind == "bull" and i + 4 < n else (h[i + 4:] >= zlo).any() if i + 4 < n else False)})
    obs.sort(key=lambda z: min(abs(z["lo"] - px), abs(z["hi"] - px)))
    out["ob"] = obs[:5]
    # liquidity pools: equal highs / equal lows (stops cluster there) + recent sweeps
    def pools(idx, arr, above):
        res, used = [], set()
        for a in range(len(idx)):
            grp = [idx[a]] + [idx[b] for b in range(a + 1, len(idx)) if abs(arr[idx[b]] - arr[idx[a]]) <= 0.18 * atr and idx[b] not in used]
            if len(grp) >= 2:
                used.update(grp); lvl = float(np.mean([arr[j] for j in grp]))
                if (lvl > px) == above:
                    res.append({"p": _g(lvl), "n": len(grp), "dist_pct": round((lvl / px - 1) * 100, 2)})
        return sorted(res, key=lambda z: abs(z["dist_pct"]))[:3]
    out["liq_above"], out["liq_below"] = pools(sh[-8:], h, True), pools(sl[-8:], l, False)
    sweep = None
    for j in sh[-6:]:
        if j < n - 1 and h[j + 1:].max() > h[j] and c[n - 1] < h[j] and n - 1 - (j + 1 + int(np.argmax(h[j + 1:]))) <= 8:
            sweep = {"dir": "high", "level": _g(h[j]), "note": "جمع‌آوری نقدینگی بالای سقف و بازگشت به زیر آن (نشانه نزولی)"}
    for j in sl[-6:]:
        if j < n - 1 and l[j + 1:].min() < l[j] and c[n - 1] > l[j] and n - 1 - (j + 1 + int(np.argmin(l[j + 1:]))) <= 8:
            sweep = {"dir": "low", "level": _g(l[j]), "note": "جمع‌آوری نقدینگی زیر کف و بازگشت به بالای آن (نشانه صعودی)"}
    out["sweep"] = sweep
    # premium / discount of the dealing range
    rh, rl = float(h[-60:].max()), float(l[-60:].min())
    pos = (px - rl) / (rh - rl + 1e-12)
    out["range"] = {"hi": _g(rh), "lo": _g(rl), "eq": _g((rh + rl) / 2), "pos": round(pos, 3), "zone": "premium" if pos > 0.62 else "discount" if pos < 0.38 else "equilibrium",
                    "ote_lo": _g(rh - 0.79 * (rh - rl)), "ote_hi": _g(rh - 0.62 * (rh - rl))}
    return out


# ───────────────────────── oscillator / moving-average voting + misc indicators ─────────────────────────
def _ema(a: pd.Series, n: int) -> pd.Series:
    return a.ewm(span=n, adjust=False).mean()


def osc(df: pd.DataFrame) -> dict:
    c, h, l, o, v = (df[k].astype(float) for k in ("close", "high", "low", "open", "volume"))
    n = len(df)
    if n < 60:
        return {}
    px = float(c.iloc[-1])
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    atr = float(tr.rolling(14).mean().iloc[-1])
    votes = []

    def vote(name, val, v_, note=""):
        votes.append({"n": name, "v": None if val is None or not np.isfinite(val) else _g(val), "s": v_, "note": note})
    # RSI
    d = c.diff(); g = d.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean(); ls = (-d.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    rsi = 100 - 100 / (1 + g / (ls + 1e-12)); r0, r1 = float(rsi.iloc[-1]), float(rsi.iloc[-2])
    vote("RSI 14", r0, 1 if (r0 < 30 and r0 > r1) else -1 if (r0 > 70 and r0 < r1) else 0, "اشباع فروش/خرید با برگشت")
    # Stochastic
    ll, hh = l.rolling(14).min(), h.rolling(14).max(); k = (c - ll) / (hh - ll + 1e-12) * 100; k3 = k.rolling(3).mean(); d3 = k3.rolling(3).mean()
    vote("Stochastic", float(k3.iloc[-1]), 1 if (k3.iloc[-1] < 20 and k3.iloc[-1] > d3.iloc[-1]) else -1 if (k3.iloc[-1] > 80 and k3.iloc[-1] < d3.iloc[-1]) else 0)
    # CCI
    tp = (h + l + c) / 3; wv = np.lib.stride_tricks.sliding_window_view(tp.values, 20); md = np.r_[np.full(19, np.nan), np.abs(wv - wv.mean(1, keepdims=True)).mean(1)]
    cci = (tp - tp.rolling(20).mean()) / (0.015 * pd.Series(md, index=tp.index) + 1e-12)
    cc0, cc1 = float(cci.iloc[-1]), float(cci.iloc[-2])
    vote("CCI 20", cc0, 1 if (cc0 < -100 and cc0 > cc1) else -1 if (cc0 > 100 and cc0 < cc1) else 0)
    # ADX / DI
    up, dn = h.diff(), -l.diff(); pdm = np.where((up > dn) & (up > 0), up, 0.0); mdm = np.where((dn > up) & (dn > 0), dn, 0.0)
    atr14 = tr.ewm(alpha=1 / 14, adjust=False).mean(); pdi = 100 * pd.Series(pdm, index=df.index).ewm(alpha=1 / 14, adjust=False).mean() / atr14; mdi = 100 * pd.Series(mdm, index=df.index).ewm(alpha=1 / 14, adjust=False).mean() / atr14
    dx = (pdi - mdi).abs() / (pdi + mdi + 1e-12) * 100; adx = dx.ewm(alpha=1 / 14, adjust=False).mean(); a0 = float(adx.iloc[-1])
    vote("ADX / DI", a0, (1 if pdi.iloc[-1] > mdi.iloc[-1] else -1) if a0 > 20 else 0, f"+DI {pdi.iloc[-1]:.0f} / −DI {mdi.iloc[-1]:.0f}")
    # Awesome oscillator
    mp = (h + l) / 2; ao = mp.rolling(5).mean() - mp.rolling(34).mean(); a_0, a_1 = float(ao.iloc[-1]), float(ao.iloc[-2])
    vote("Awesome Osc", a_0, 1 if (a_0 > 0 and a_0 > a_1) else -1 if (a_0 < 0 and a_0 < a_1) else 0)
    # Momentum
    mo = c - c.shift(10); vote("Momentum 10", float(mo.iloc[-1]), 1 if mo.iloc[-1] > mo.iloc[-2] and mo.iloc[-1] > 0 else -1 if mo.iloc[-1] < mo.iloc[-2] and mo.iloc[-1] < 0 else 0)
    # MACD
    m = _ema(c, 12) - _ema(c, 26); sg = _ema(m, 9); vote("MACD", float(m.iloc[-1] - sg.iloc[-1]), 1 if m.iloc[-1] > sg.iloc[-1] else -1 if m.iloc[-1] < sg.iloc[-1] else 0)
    # Williams %R
    wr = (hh - c) / (hh - ll + 1e-12) * -100; w0, w1 = float(wr.iloc[-1]), float(wr.iloc[-2])
    vote("Williams %R", w0, 1 if (w0 < -80 and w0 > w1) else -1 if (w0 > -20 and w0 < w1) else 0)
    # Elder bull / bear power
    e13 = _ema(c, 13); bp, brp = h - e13, l - e13
    vote("Bull/Bear Power", float(bp.iloc[-1] + brp.iloc[-1]), 1 if (e13.iloc[-1] > e13.iloc[-2] and brp.iloc[-1] < 0 and brp.iloc[-1] > brp.iloc[-2]) else -1 if (e13.iloc[-1] < e13.iloc[-2] and bp.iloc[-1] > 0 and bp.iloc[-1] < bp.iloc[-2]) else 0)
    # Ultimate oscillator
    bpu = c - pd.concat([l, c.shift()], axis=1).min(axis=1); trr = pd.concat([h, c.shift()], axis=1).max(axis=1) - pd.concat([l, c.shift()], axis=1).min(axis=1)
    av = lambda p: bpu.rolling(p).sum() / (trr.rolling(p).sum() + 1e-12); uo = 100 * (4 * av(7) + 2 * av(14) + av(28)) / 7; u0 = float(uo.iloc[-1])
    vote("Ultimate Osc", u0, 1 if u0 < 30 else -1 if u0 > 70 else 0)
    # Aroon
    ar_up = 100 * h.tail(26).values.argmax() / 25; ar_dn = 100 * (l.tail(26).values.argmin()) / 25
    vote("Aroon 25", ar_up - ar_dn, 1 if ar_up > 70 and ar_dn < 30 else -1 if ar_dn > 70 and ar_up < 30 else 0, f"↑{ar_up:.0f} ↓{ar_dn:.0f}")
    # TRIX
    tx = _ema(_ema(_ema(c, 15), 15), 15).pct_change() * 100; vote("TRIX 15", float(tx.iloc[-1]), 1 if tx.iloc[-1] > 0 and tx.iloc[-1] > tx.iloc[-2] else -1 if tx.iloc[-1] < 0 and tx.iloc[-1] < tx.iloc[-2] else 0)
    # moving averages
    mas = []
    for nm, ser in [("EMA 10", _ema(c, 10)), ("EMA 20", _ema(c, 20)), ("EMA 30", _ema(c, 30)), ("EMA 50", _ema(c, 50)), ("EMA 100", _ema(c, 100)), ("EMA 200", _ema(c, 200)),
                    ("SMA 20", c.rolling(20).mean()), ("SMA 50", c.rolling(50).mean()), ("SMA 100", c.rolling(100).mean()), ("SMA 200", c.rolling(200).mean()),
                    ("VWMA 20", (c * v).rolling(20).sum() / (v.rolling(20).sum() + 1e-12)), ("HMA 9", (2 * c.rolling(4).mean() - c.rolling(9).mean()).rolling(3).mean())]:
        val = float(ser.iloc[-1]) if np.isfinite(ser.iloc[-1]) else None
        mas.append({"n": nm, "v": _g(val) if val else None, "s": 0 if val is None else (1 if px > val else -1)})
    osc_b, osc_s = sum(1 for x in votes if x["s"] > 0), sum(1 for x in votes if x["s"] < 0)
    ma_b, ma_s = sum(1 for x in mas if x["s"] > 0), sum(1 for x in mas if x["s"] < 0)
    # misc
    psar_dir, psar = _psar(df)
    ma20, sd20 = c.rolling(20).mean(), c.rolling(20).std(); kc_mid = _ema(c, 20); kc_u, kc_l = kc_mid + 1.5 * atr, kc_mid - 1.5 * atr
    sq = bool(ma20.iloc[-1] + 2 * sd20.iloc[-1] < kc_u.iloc[-1] and ma20.iloc[-1] - 2 * sd20.iloc[-1] > kc_l.iloc[-1])
    er = lambda p: float(abs(c.iloc[-1] - c.iloc[-1 - p]) / (c.diff().abs().tail(p).sum() + 1e-12))
    lr = np.log(c).diff().dropna(); sig = float(lr.tail(60).std())
    hh22, ll22 = float(h.tail(22).max()), float(l.tail(22).min())
    fi = _ema(c.diff() * v, 13)
    misc = {"psar": _g(psar), "psar_dir": psar_dir, "keltner": {"u": _g(kc_u.iloc[-1]), "m": _g(kc_mid.iloc[-1]), "l": _g(kc_l.iloc[-1])}, "squeeze_kc": sq,
            "er10": round(er(10), 3), "er30": round(er(30), 3), "force": "مثبت" if fi.iloc[-1] > 0 else "منفی",
            "chandelier_long": _g(hh22 - 3 * atr), "chandelier_short": _g(ll22 + 3 * atr),
            "atr_stops": [{"m": m_, "long": _g(px - m_ * atr), "short": _g(px + m_ * atr)} for m_ in (1.0, 1.5, 2.0, 3.0)],
            "cone": [{"n": k_, "sd": round(sig * np.sqrt(k_) * 100, 2), "lo": _g(px * np.exp(-sig * np.sqrt(k_))), "hi": _g(px * np.exp(sig * np.sqrt(k_)))} for k_ in (4, 8, 16, 32)]}
    def lab(b, s_, tot):
        d_ = (b - s_) / max(1, tot)
        return "خرید قوی" if d_ > .5 else "خرید" if d_ > .15 else "فروش قوی" if d_ < -.5 else "فروش" if d_ < -.15 else "خنثی"
    return {"osc": votes, "ma": mas, "osc_buy": osc_b, "osc_sell": osc_s, "osc_neu": len(votes) - osc_b - osc_s, "ma_buy": ma_b, "ma_sell": ma_s,
            "osc_label": lab(osc_b, osc_s, len(votes)), "ma_label": lab(ma_b, ma_s, len(mas)), "all_label": lab(osc_b + ma_b, osc_s + ma_s, len(votes) + len(mas)),
            "all_score": round((osc_b + ma_b - osc_s - ma_s) / (len(votes) + len(mas)) * 100, 1), "misc": misc}


def _psar(df: pd.DataFrame, af0=0.02, afm=0.2):
    h, l = df["high"].values.astype(float), df["low"].values.astype(float)
    bull, sar, ep, af = True, l[0], h[0], af0
    for i in range(1, len(h)):
        sar = sar + af * (ep - sar)
        if bull:
            sar = min(sar, l[i - 1], l[i - 2] if i > 1 else l[i - 1])
            if l[i] < sar:
                bull, sar, ep, af = False, ep, l[i], af0
            elif h[i] > ep:
                ep, af = h[i], min(afm, af + af0)
        else:
            sar = max(sar, h[i - 1], h[i - 2] if i > 1 else h[i - 1])
            if h[i] > sar:
                bull, sar, ep, af = True, ep, h[i], af0
            elif l[i] < ep:
                ep, af = l[i], min(afm, af + af0)
    return ("up" if bull else "down"), sar


def _pat(df: pd.DataFrame) -> dict:
    from app.analysis import patterns as P
    return P.summarize(P.detect_recent(df, 5), P.structures(df), None)


def compute(df: pd.DataFrame, tf: str) -> dict:
    out = {}
    for k, fn in (("ichimoku", lambda: ichimoku(df)), ("fib", lambda: fibonacci(df)), ("pivots", lambda: pivots(df, tf)),
                  ("vp", lambda: volume_profile(df)), ("stats", lambda: stats(df)), ("flow", lambda: flow(df)), ("pat", lambda: _pat(df)), ("smc", lambda: smc(df)), ("osc", lambda: osc(df))):
        try:
            out[k] = fn()
        except Exception:                                   # noqa: BLE001 - extras must never break a signal
            out[k] = {}
    return out

"""Multi-timeframe fusion: weighted consensus, higher-TF veto, coherent verdict + narrative.
Also attaches the advanced analytics pack (microstructure, Edge, checklist, RS, session)."""
from __future__ import annotations
from typing import Any
import pandas as pd

from app.config import TF_WEIGHT, SIDE_THRESHOLD, FORECAST_CANDLES
from app.analysis.technicals import analyze
from app.analysis.forecast import forecast_summary
from app.analysis.grade import fuse, grade_from
from app.analysis import advanced as adv

REGIME_FA = {"trend": "روندی", "range": "رنج", "neutral": "گذار", "unknown": "نامشخص"}
SIDE_SHORT = {"LONG": "خرید", "SHORT": "فروش", "WAIT": "انتظار"}
SIDE_FA = {"LONG": "خرید (LONG)", "SHORT": "فروش (SHORT)", "WAIT": "انتظار"}


def deep_analyze(frames: dict[str, pd.DataFrame], symbol: str, primary_tf: str = "1h",
                 prices: dict[str, float] | None = None,
                 derivs: dict | None = None, depth: dict | None = None,
                 btc_frame: pd.DataFrame | None = None,
                 hour_stats: dict | None = None) -> dict[str, Any]:
    prices = prices or {}
    sigs, fcs = {}, {}
    for tf, df in frames.items():
        if df is None or len(df) < 60:
            continue
        s = analyze(df, symbol, tf, price=prices.get(tf))
        sigs[tf] = s
        lv = {"entry": s.entry, "stop": s.stop, "tp1": s.tp1, "tp2": s.tp2, "tp3": s.tp3} if s.side != "WAIT" else None
        fcs[tf] = forecast_summary(df, s.side, n_ahead=FORECAST_CANDLES, seed_key=f"{symbol}{tf}", levels=lv)
    if not sigs:
        return {"symbol": symbol, "primary_tf": primary_tf, "signal": None, "all_tf": {}, "verdict": "WAIT",
                "consensus_score": 0, "conviction": 0, "agreement": "mixed", "regime": "unknown",
                "narrative": "داده کافی نیست", "advanced": {}}

    consensus, side, note = fuse({t: x.score for t, x in sigs.items()})
    wsum = sum(TF_WEIGHT.get(t, .2) for t in sigs)
    sides = [s.side for s in sigs.values()]
    ln, sn = sides.count("LONG"), sides.count("SHORT")
    agreement = ("strong_long" if ln >= 3 else "strong_short" if sn >= 3 else
                 "lean_long" if ln > sn else "lean_short" if sn > ln else "mixed")
    aligned = sum(TF_WEIGHT.get(t, .2) for t, s in sigs.items() if (s.score > 10) == (consensus > 0) and abs(s.score) > 10) / wsum
    conviction = round(min(0.97, 0.55 * min(1, abs(consensus) / 70) + 0.45 * aligned), 3)

    ptf = primary_tf if primary_tf in sigs else next(iter(sigs))
    prim = sigs[ptf]
    plan = prim
    if side in ("LONG", "SHORT") and prim.side != side:
        plan = analyze(frames[ptf], symbol, ptf, price=prices.get(ptf), force_side=side)
    regime = prim.regime
    pf = fcs[ptf]
    if side in ("LONG", "SHORT"):
        pf = forecast_summary(frames[ptf], side, n_ahead=FORECAST_CANDLES, seed_key=f"{symbol}{ptf}",
                              levels={"entry": plan.entry, "stop": plan.stop, "tp1": plan.tp1, "tp2": plan.tp2, "tp3": plan.tp3})
        fcs[ptf] = pf
    sd = {t: x.to_dict() for t, x in sigs.items()}
    if side in ("LONG", "SHORT") and plan is not prim:
        sd[ptf] = plan.to_dict()
    gr = grade_from(sd, fcs, side, consensus, ptf)

    plan_d = plan.to_dict()
    try:
        pack = adv.build_pack(
            plan_d,
            deep={"grade": gr, "conviction": conviction, "verdict": side},
            forecast=pf,
            derivs=derivs,
            depth=depth,
            sym_df=frames.get(ptf),
            btc_df=btc_frame,
            hour_stats=hour_stats,
        )
    except Exception:                                        # noqa: BLE001
        pack = {}

    mb = (pack.get("micro") or {}).get("bias_pack") or {}
    bias = float(mb.get("bias") or 0)
    if side == "LONG" and bias >= 0.2:
        conviction = round(min(0.97, conviction + 0.04), 3)
    elif side == "SHORT" and bias <= -0.2:
        conviction = round(min(0.97, conviction + 0.04), 3)
    elif side == "LONG" and bias <= -0.25:
        conviction = round(max(0.2, conviction - 0.05), 3)
    elif side == "SHORT" and bias >= 0.25:
        conviction = round(max(0.2, conviction - 0.05), 3)

    edge = pack.get("edge") or {}
    parts = [f"رژیم {REGIME_FA.get(regime, regime)} · اجماع وزنی {consensus:+.0f} → {SIDE_FA[side]}"]
    if note:
        parts.append(note)
    parts.append("تایم‌فریم‌ها: " + " | ".join(f"{t}: {SIDE_SHORT[s.side]} {s.score:+.0f}" for t, s in sigs.items()))
    parts.append(f"احتمال صعود ({ptf}، ۳۲ کندل) {pf['prob_up'] * 100:.0f}٪ · حرکت میانه {pf['expected_move_pct']:+.2f}٪")
    if side != "WAIT":
        ek = (plan_d.get("indicators") or {}).get("entry_kind") or "market"
        parts.append(
            f"ورود {plan.entry} ({'لیمیت' if ek == 'limit' else 'بازار'}) · حدضرر {plan.stop} "
            f"· اهداف {plan.tp1}/{plan.tp2}/{plan.tp3} · R:R {plan.risk_reward}"
        )
    if edge.get("edge"):
        parts.append(f"امتیاز برتری (Edge) {edge['edge']:.0f}/100 — {edge.get('label', '')}")
    if mb.get("label") and mb.get("label") != "خنثی":
        parts.append(f"میکروساختار: {mb['label']}")
    if prim.reasons:
        parts.append("دلایل: " + " · ".join(prim.reasons[:4]))

    return {
        "symbol": symbol, "primary_tf": ptf, "signal": plan_d, "primary": prim.to_dict(),
        "forecast": pf, "all_tf": {t: s.to_dict() for t, s in sigs.items()}, "all_forecasts": fcs, "grade": gr,
        "consensus_score": round(consensus, 1), "conviction": conviction, "verdict": side, "veto": note,
        "agreement": agreement, "regime": regime, "narrative": " — ".join(parts),
        "long_count": ln, "short_count": sn, "wait_count": sides.count("WAIT"),
        "advanced": pack,
    }

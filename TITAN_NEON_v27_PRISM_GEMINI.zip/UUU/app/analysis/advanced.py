"""TITAN advanced analytics layer — microstructure bias, composite Edge score,
session quality, relative-strength pack and setup-completeness checklist.

Pure functions of already-fetched frames / signal dicts / optional micro payload.
Never raises into the signal path; every helper returns safe defaults on failure.
"""
from __future__ import annotations
from typing import Any
import math
import time
import numpy as np
import pandas as pd


def _g(x: float, n: int = 4) -> float:
    try:
        return round(float(x), n)
    except Exception:                                        # noqa: BLE001
        return 0.0


def _safe(d: dict | None) -> dict:
    return d if isinstance(d, dict) else {}


# ───────────────────────── microstructure bias ─────────────────────────
def micro_bias(derivs: dict | None, depth: dict | None) -> dict:
    """Translate funding / OI / L-S / order-book imbalance into a signed bias in [-1, +1]
    and a human-readable note. Positive = supports LONG, negative = supports SHORT."""
    out = {
        "bias": 0.0, "score": 0.0, "label": "خنثی", "parts": [],
        "funding_pct": None, "oi_usd": None, "ls_buy": None, "basis_pct": None,
        "imbalance": None, "spread_bps": None, "wall_bid": None, "wall_ask": None,
    }
    d = _safe(derivs)
    dep = _safe(depth)
    parts: list[tuple[str, float, str]] = []

    if d.get("ok"):
        fr = float(d.get("funding_pct") or 0)
        out["funding_pct"] = fr
        out["oi_usd"] = d.get("oi_usd")
        out["basis_pct"] = d.get("basis_pct")
        out["ls_buy"] = d.get("ls_buy")
        # Extreme positive funding → crowded longs → mild short bias (and vice-versa)
        if fr >= 0.03:
            parts.append(("funding", -0.55, f"فاندینگ بالا ({fr:+.3f}٪) → ازدحام لانگ"))
        elif fr >= 0.012:
            parts.append(("funding", -0.25, f"فاندینگ مثبت ({fr:+.3f}٪)"))
        elif fr <= -0.03:
            parts.append(("funding", 0.55, f"فاندینگ منفی قوی ({fr:+.3f}٪) → ازدحام شورت"))
        elif fr <= -0.012:
            parts.append(("funding", 0.25, f"فاندینگ منفی ({fr:+.3f}٪)"))
        else:
            parts.append(("funding", 0.0, f"فاندینگ خنثی ({fr:+.3f}٪)"))

        ls = d.get("ls_buy")
        if ls is not None:
            # buyRatio > 0.58 → too many longs; < 0.42 → too many shorts
            if ls >= 0.62:
                parts.append(("ls", -0.40, f"نسبت لانگ/شورت {ls:.0%} (ازدحام لانگ)"))
            elif ls >= 0.55:
                parts.append(("ls", -0.18, f"نسبت لانگ غالب {ls:.0%}"))
            elif ls <= 0.38:
                parts.append(("ls", 0.40, f"نسبت شورت غالب {ls:.0%}"))
            elif ls <= 0.45:
                parts.append(("ls", 0.18, f"نسبت شورت بیشتر {ls:.0%}"))
            else:
                parts.append(("ls", 0.0, f"نسبت L/S متعادل {ls:.0%}"))

        basis = float(d.get("basis_pct") or 0)
        if basis >= 0.15:
            parts.append(("basis", -0.15, f"پریمیوم مارک {basis:+.3f}٪"))
        elif basis <= -0.15:
            parts.append(("basis", 0.15, f"دیسکانت مارک {basis:+.3f}٪"))

        hist = d.get("ls_hist") or []
        if len(hist) >= 6:
            slope = hist[-1] - hist[-6]
            if slope > 0.06:
                parts.append(("ls_trend", -0.12, "روند افزایش لانگ‌ها"))
            elif slope < -0.06:
                parts.append(("ls_trend", 0.12, "روند افزایش شورت‌ها"))

    if dep.get("ok"):
        imb = dep.get("imb_1pct")
        if imb is None:
            imb = dep.get("imbalance")
        if imb is not None:
            out["imbalance"] = float(imb)
            parts.append(("book", _g(max(-0.45, min(0.45, float(imb) * 0.7)), 3),
                          f"عدم‌تعادل دفتر سفارش {float(imb):+.2f}"))
        sp_pct = dep.get("spread_pct")
        if sp_pct is not None:
            out["spread_bps"] = float(sp_pct) * 100.0
            if out["spread_bps"] > 8:
                parts.append(("spread", -0.08, f"اسپرد وسیع ({out['spread_bps']:.1f} bps)"))
        bw, aw = dep.get("bid_walls") or [], dep.get("ask_walls") or []
        if bw:
            out["wall_bid"] = bw[0]
        if aw:
            out["wall_ask"] = aw[0]

    if not parts:
        return out

    raw = sum(w for _, w, _ in parts)
    bias = max(-1.0, min(1.0, raw / 1.35))
    out["bias"] = _g(bias, 3)
    out["score"] = _g(bias * 100, 1)
    out["parts"] = [{"k": k, "w": _g(w, 3), "t": t} for k, w, t in parts]
    if bias >= 0.28:
        out["label"] = "حمایت لانگ (میکرو)"
    elif bias <= -0.28:
        out["label"] = "حمایت شورت (میکرو)"
    elif abs(bias) >= 0.12:
        out["label"] = "تمایل ملایم " + ("لانگ" if bias > 0 else "شورت")
    else:
        out["label"] = "خنثی"
    return out


# ───────────────────────── session quality ─────────────────────────
_SESSION = {
    # UTC hour → (name_fa, liquidity_mult, typical_range_mult)
    range(0, 7): ("آسیا", 0.75, 0.85),
    range(7, 13): ("اروپا", 1.05, 1.05),
    range(13, 17): ("هم‌پوشانی EU/US", 1.20, 1.25),
    range(17, 22): ("آمریکا", 1.10, 1.15),
    range(22, 24): ("پایان روز", 0.80, 0.90),
}


def session_quality(hour_utc: int | None = None, hour_stats: dict | None = None) -> dict:
    h = int(hour_utc if hour_utc is not None else time.gmtime().tm_hour)
    name, liq, rng = "نامشخص", 1.0, 1.0
    for rng_h, meta in _SESSION.items():
        if h in rng_h:
            name, liq, rng = meta
            break
    out = {"hour_utc": h, "name": name, "liquidity": liq, "range_mult": rng,
           "label": name, "score": _g((liq - 1.0) * 50, 1)}
    hs = _safe(hour_stats)
    if hs.get("range") and len(hs["range"]) == 24:
        r = hs["range"][h]
        med = float(np.median(hs["range"])) or 1e-9
        out["range_vs_med"] = _g(r / med, 2)
        out["note"] = f"بازه معمول این ساعت {r:.2f}٪ (میانه شبانه‌روز {med:.2f}٪)"
    return out


# ───────────────────────── relative strength pack ─────────────────────────
def rel_strength(sym_df: pd.DataFrame | None, btc_df: pd.DataFrame | None,
                 look: int = 48) -> dict:
    """Beta, correlation, 24h relative return and rank-style RS vs BTC."""
    out = {"ok": False}
    if sym_df is None or btc_df is None or len(sym_df) < look + 5 or len(btc_df) < look + 5:
        return out
    try:
        n = min(len(sym_df), len(btc_df), look + 1)
        a = np.log(sym_df["close"].astype(float).values[-n:])
        b = np.log(btc_df["close"].astype(float).values[-n:])
        ra, rb = np.diff(a), np.diff(b)
        if ra.std() < 1e-12 or rb.std() < 1e-12:
            return out
        corr = float(np.corrcoef(ra, rb)[0, 1])
        beta = float(np.cov(ra, rb)[0, 1] / (rb.var() + 1e-18))
        ret_a = float(np.exp(a[-1] - a[0]) - 1) * 100
        ret_b = float(np.exp(b[-1] - b[0]) - 1) * 100
        rs = ret_a - ret_b
        out = {
            "ok": True, "corr": _g(corr, 3), "beta": _g(beta, 3),
            "ret_sym_pct": _g(ret_a, 2), "ret_btc_pct": _g(ret_b, 2),
            "rs_pct": _g(rs, 2), "look": n - 1,
            "label": ("قوی‌تر از BTC" if rs >= 1.5 else "ضعیف‌تر از BTC" if rs <= -1.5 else "هم‌سطح BTC"),
        }
    except Exception:                                        # noqa: BLE001
        pass
    return out


# ───────────────────────── setup completeness ─────────────────────────
def setup_checklist(sig: dict, deep: dict | None = None, micro: dict | None = None) -> dict:
    """Explainable checklist of what makes a setup complete. Each item is shown in UI."""
    items = []
    side = sig.get("side") or "WAIT"
    if side == "WAIT":
        return {"score": 0, "max": 10, "pct": 0, "items": [{"ok": False, "t": "سیگنال فعال نیست"}], "label": "—"}

    def add(ok: bool, text: str, w: int = 1):
        items.append({"ok": bool(ok), "t": text, "w": w})

    score = float(sig.get("score") or 0)
    agree = float(sig.get("agree") or 0)
    conf = float(sig.get("confidence") or 0)
    rr = float(sig.get("risk_reward") or 0)
    regime = sig.get("regime") or "unknown"
    warns = sig.get("warnings") or []
    ind = sig.get("indicators") or {}
    ek = ind.get("entry_kind") or (sig.get("levels") or {}).get("entry_kind") or "market"

    add(abs(score) >= 40, f"امتیاز |{score:.0f}| ≥ ۴۰", 1)
    add(agree >= 0.62, f"هم‌سویی مولفه‌ها {agree * 100:.0f}٪", 1)
    add(conf >= 0.55, f"اعتماد مدل {conf * 100:.0f}٪", 1)
    add(rr >= 1.5, f"R:R {rr:.2f} ≥ ۱٫۵", 1)
    add(regime == "trend", f"رژیم {regime}", 1)
    add(ek == "limit", "ورود لیمیت روی ساختار", 1)
    add(len(warns) <= 1, f"هشدارها: {len(warns)}", 1)
    add(float(ind.get("vol_ratio") or 0) >= 0.9, f"حجم نسبی {float(ind.get('vol_ratio') or 0):.1f}×", 1)

    d = _safe(deep)
    if d:
        gr = (d.get("grade") or {}).get("grade") or "—"
        add(gr in ("A", "B"), f"درجه ستاپ {gr}", 1)
        aligned = int((d.get("grade") or {}).get("aligned") or 0)
        add(aligned >= 2, f"{aligned} تایم‌فریم هم‌جهت", 1)
        conv = float(d.get("conviction") or 0)
        add(conv >= 0.55, f"conviction {conv * 100:.0f}٪", 1)

    mb = _safe(micro).get("bias_pack") or {}
    if mb:
        bias = float(mb.get("bias") or 0)
        aligned_micro = (side == "LONG" and bias >= 0.1) or (side == "SHORT" and bias <= -0.1)
        add(aligned_micro or abs(bias) < 0.1, f"میکروساختار: {mb.get('label', '—')}", 1)

    got = sum(i["w"] for i in items if i["ok"])
    mx = sum(i["w"] for i in items) or 1
    pct = got / mx
    label = "کامل" if pct >= 0.85 else "قوی" if pct >= 0.65 else "قابل قبول" if pct >= 0.45 else "ناقص"
    return {"score": got, "max": mx, "pct": _g(pct, 3), "items": items, "label": label}


# ───────────────────────── composite Edge score ─────────────────────────
def edge_score(sig: dict, deep: dict | None = None, forecast: dict | None = None,
               micro: dict | None = None, rs: dict | None = None,
               session: dict | None = None) -> dict:
    """Single 0–100 Edge number + breakdown. Higher = better risk-adjusted opportunity.
    Not a calibrated probability — a ranking / quality score for the dashboard."""
    side = (sig or {}).get("side") or "WAIT"
    if side == "WAIT":
        return {"edge": 0, "label": "بدون سیگنال", "parts": {}, "note": "منتظر ستاپ"}

    parts: dict[str, float] = {}
    score = abs(float(sig.get("score") or 0))
    conf = float(sig.get("confidence") or 0)
    agree = float(sig.get("agree") or 0)
    rr = float(sig.get("risk_reward") or 0)
    regime = sig.get("regime") or "neutral"

    parts["signal"] = min(28, score / 100 * 28)
    parts["confidence"] = conf * 18
    parts["agreement"] = agree * 12
    parts["rr"] = min(12, max(0, (rr - 1.0) / 2.0 * 12))
    parts["regime"] = 8 if regime == "trend" else 4 if regime == "neutral" else 2

    d = _safe(deep)
    gr = (d.get("grade") or {}).get("grade") or "—"
    parts["grade"] = {"A": 10, "B": 7, "C": 3, "D": 0}.get(gr, 0)
    parts["conviction"] = float(d.get("conviction") or 0) * 8

    fc = _safe(forecast)
    edge_fc = fc.get("edge") or {}
    if edge_fc:
        p_tp1 = float(edge_fc.get("p_tp1") or 0)
        ev = float(edge_fc.get("ev_r") or 0)
        parts["forecast_tp1"] = min(8, p_tp1 * 8)
        parts["forecast_ev"] = max(-4, min(6, ev * 4))
    elif fc.get("alignment") == "aligned":
        parts["forecast_tp1"] = 4
        parts["forecast_ev"] = 0
    else:
        parts["forecast_tp1"] = 0
        parts["forecast_ev"] = -1 if fc.get("alignment") == "divergent" else 0

    mb = _safe(micro).get("bias_pack") or {}
    bias = float(mb.get("bias") or 0)
    if (side == "LONG" and bias > 0) or (side == "SHORT" and bias < 0):
        parts["micro"] = min(8, abs(bias) * 10)
    elif (side == "LONG" and bias < -0.2) or (side == "SHORT" and bias > 0.2):
        parts["micro"] = -min(6, abs(bias) * 8)
    else:
        parts["micro"] = 0

    rs = _safe(rs)
    if rs.get("ok"):
        rs_pct = float(rs.get("rs_pct") or 0)
        if (side == "LONG" and rs_pct > 0) or (side == "SHORT" and rs_pct < 0):
            parts["rel_strength"] = min(5, abs(rs_pct) / 3)
        else:
            parts["rel_strength"] = -min(3, abs(rs_pct) / 4)
    else:
        parts["rel_strength"] = 0

    sess = _safe(session)
    parts["session"] = float(sess.get("score") or 0) * 0.06  # small tilt

    total = sum(parts.values())
    edge = max(0, min(100, total))
    if edge >= 72:
        label = "برتری بالا"
    elif edge >= 55:
        label = "برتری خوب"
    elif edge >= 40:
        label = "برتری متوسط"
    else:
        label = "برتری ضعیف"

    note_bits = []
    if parts.get("micro", 0) > 2:
        note_bits.append("میکروساختار هم‌جهت")
    if parts.get("micro", 0) < -2:
        note_bits.append("میکروساختار مخالف")
    if gr in ("A", "B"):
        note_bits.append(f"درجه {gr}")
    if rr >= 2:
        note_bits.append(f"R:R {rr:.1f}")
    return {
        "edge": _g(edge, 1),
        "label": label,
        "parts": {k: _g(v, 2) for k, v in parts.items()},
        "note": " · ".join(note_bits) if note_bits else "ترکیب چندعاملی",
        "side": side,
    }


# ───────────────────────── package for deep / API ─────────────────────────
def build_pack(sig: dict, deep: dict | None = None, forecast: dict | None = None,
               derivs: dict | None = None, depth: dict | None = None,
               sym_df: pd.DataFrame | None = None, btc_df: pd.DataFrame | None = None,
               hour_stats: dict | None = None) -> dict:
    """One call that assembles everything the dashboard needs under `advanced`."""
    mb = micro_bias(derivs, depth)
    sess = session_quality(hour_stats=hour_stats)
    rs = rel_strength(sym_df, btc_df)
    dep = _safe(depth)
    micro = {"bias_pack": mb, "derivs": _safe(derivs), "depth": {
        "ok": bool(dep.get("ok")),
        "imbalance": dep.get("imb_1pct", dep.get("imbalance")),
        "spread_bps": (float(dep["spread_pct"]) * 100.0) if dep.get("spread_pct") is not None else dep.get("spread_bps"),
        "bid_walls": dep.get("bid_walls"),
        "ask_walls": dep.get("ask_walls"),
        "bid_usd_1pct": dep.get("bid_usd_1pct"),
        "ask_usd_1pct": dep.get("ask_usd_1pct"),
    }}
    check = setup_checklist(sig, deep, micro)
    edge = edge_score(sig, deep, forecast, micro, rs, sess)
    return {
        "micro": micro,
        "session": sess,
        "rel_strength": rs,
        "checklist": check,
        "edge": edge,
        "ts": time.time(),
    }

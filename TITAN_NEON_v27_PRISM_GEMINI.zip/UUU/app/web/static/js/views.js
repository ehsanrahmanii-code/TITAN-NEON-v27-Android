/* TITAN PRO NEON v2.1 — views: home, coin analysis tabs, chart, market, exchange, settings */
(function () {
'use strict';
const T = window.T, ST = T.ST, R = T.R, esc = T.esc, $ = T.$, ch = T.ch, UI = () => T.UI;
const motion = () => T.UI.motion === 'on' || (T.UI.motion === 'auto' && !matchMedia('(prefers-reduced-motion:reduce)').matches);
const put = (el, html, before) => {
  if (el._h === html) return false;
  const ae = document.activeElement; if (ae && el.contains(ae) && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName)) return false;   // never steal focus while typing
  if (before) before(); el._h = html; el.innerHTML = html; return true;
};
const ICON = n => `<svg><use href="#i-${n}"/></svg>`;
const rowsOf = () => (ST.syms.length ? ST.syms : Object.keys(ST.matrix)).map(s => ST.matrix[s]).filter(r => r && Object.keys(r.tfs).length);
const dot = b => `<span class="dot">${esc(b.slice(0, 3))}</span>`;
const sgn = v => '\u200E' + (v > 0 ? '+' : '') + Math.round(v) + '\u200E';
const card = (title, icon, body, cls = '', right = '') => `<div class="card ${cls}"><h3>${icon ? ICON(icon) : ''}${title}<span class="sp"></span>${right}</h3>${body}</div>`;
const tfChips = cur => `<div class="chips">${ST.tfs.map(t => `<button class="chip ${t === cur ? 'on' : ''}" data-act="tf" data-tf="${t}">${t}</button>`).join('')}</div>`;
const barSigned = v => { const w = Math.min(50, Math.abs(v) / 2); return `<div class="bar" style="height:9px"><i style="${v >= 0 ? 'left' : 'right'}:50%;width:${w}%;background:${T.scol(v)};box-shadow:0 0 calc(var(--glow)*8px) ${T.scol(v)}"></i><i style="left:50%;width:1px;background:var(--mu)"></i></div>`; };
const gchip = g => g && g !== '—' ? `<span class="gr g${g}" data-tip="درجه ستاپ (A بهترین، D ضعیف‌ترین)">${g}</span>` : '';
const pct = (v, d = 0) => T.dg(((Number(v) || 0) * 100).toFixed(d)) + '٪';
const kvs = arr => `<div class="kv">${arr.map(([k, v, c]) => `<span>${k}</span><b class="ltr" ${c ? `style="color:${c}"` : ''}>${v}</b>`).join('')}</div>`;
const hrs = (n, tf) => { const m = n * ({ '15m': 15, '1h': 60, '4h': 240, '1d': 1440 }[tf] || 60); return T.dg(m < 120 ? Math.round(m) + ' دقیقه' : m < 2880 ? (m / 60).toFixed(1) + ' ساعت' : (m / 1440).toFixed(1) + ' روز'); };

/* ═══════════ HOME ═══════════ */
const W = {};
W.kpi = rows => {
  let l = 0, s = 0, w = 0, sum = 0, best = null;
  rows.forEach(r => { const c = T.cons(r), sd = T.consSide(c); sd === 'LONG' ? l++ : sd === 'SHORT' ? s++ : w++; sum += c; if (!best || Math.abs(c) > Math.abs(best.c)) best = { r, c }; });
  const avg = rows.length ? sum / rows.length : 0, a = ST.acct;
  const K = (ic, v, lb, col) => `<div class="kpi" title="${esc(lb)}"><svg class="ic" style="color:${col}" aria-hidden="true"><use href="#i-${ic}"/></svg><b style="color:${col}">${v}</b><span>${lb}</span></div>`;
  return card('شاخص‌های کلیدی', 'pulse', `<div class="kpis">${K('bolt', T.dg(l), 'سیگنال خرید', 'var(--up)')}${K('bolt', T.dg(s), 'سیگنال فروش', 'var(--dn)')}${K('shield', T.dg(w), 'در انتظار', 'var(--mu)')}${K('pulse', T.dg(sgn(avg)), 'میانگین اجماع', T.scol(avg))}${best ? K('target', esc((best.r.base || '').slice(0, 8)), 'بهترین · ' + T.dg(sgn(best.c)), T.scol(best.c)) : ''}${a ? K('wallet', T.usd(a.equity), 'سرمایه کاغذی', a.equity >= a.starting ? 'var(--up)' : 'var(--dn)') : ''}</div>`, 'w2');
};
W.circuit = rows => T.isPhone()
  ? card('تابلوی بازار', 'flow', ch.board(rows, ST.sel), 'w2', `<small>${T.dg(rows.length)} ارز · مرتب‌شده بر اساس قدرت اجماع</small>`)
  : card('برد مدار بازار', 'flow', `<div class="svgw sx">${ch.circuit(rows, ST.sel, motion())}</div><div class="legend"><span><i style="background:var(--up)"></i>جریان صعودی (ورودی به هسته)</span><span><i style="background:var(--dn)"></i>جریان نزولی (خروجی از هسته)</span><span>روی هر تراشه بزنید ← تحلیل کامل</span></div>`, 'w2', `<small>${T.dg(rows.length)} ارز</small>`);
W.gauge = rows => {
  const avg = rows.reduce((s, r) => s + T.cons(r), 0) / (rows.length || 1); let l = 0, s = 0, w = 0; rows.forEach(r => { const d = T.consSide(T.cons(r)); d === 'LONG' ? l++ : d === 'SHORT' ? s++ : w++; });
  return card('جهت بازار', 'target', `<div class="row" style="justify-content:space-around;flex-wrap:nowrap"><div style="width:min(260px,58%)">${ch.gauge(avg, 'میانگین اجماع', T.consSide(avg) === 'WAIT' ? 'بازار خنثی' : T.SIDE_FA[T.consSide(avg)])}</div><div style="width:min(130px,36%)">${ch.donut([{ v: l, c: 'var(--up)', l: 'خرید' }, { v: s, c: 'var(--dn)', l: 'فروش' }, { v: w, c: 'var(--mu)', l: 'انتظار' }], rows.length, 'ارز')}</div></div>`);
};
W.tfcons = rows => {
  const out = ST.tfs.map(tf => { let sum = 0, n = 0, l = 0, s = 0; rows.forEach(r => { const t = r.tfs[tf]; if (t) { sum += t.score; n++; t.side === 'LONG' ? l++ : t.side === 'SHORT' ? s++ : 0; } }); const a = n ? sum / n : 0; return `<div style="margin:10px 0"><div class="row sb" style="font-size:.85em"><b>${tf}</b><span style="color:${T.scol(a)}">${T.dg(sgn(a))}</span><span class="mu">▲${T.dg(l)} ▼${T.dg(s)}</span></div>${barSigned(a)}</div>`; }).join('');
  return card('اجماع تایم‌فریم‌ها', 'chart', out);
};
W.scatter = rows => card('نقشه حبابی', 'target', `<div class="svgw">${ch.scatter(rows, ST.sel)}</div><div class="note">محور افقی: اجماع · محور عمودی: اطمینان · اندازه حباب: نوسان ۲۴ ساعته</div>`);
W.setups = rows => {
  const gi = g => 'ABCD'.indexOf(g);
  const best = rows.filter(r => r.verdict && r.verdict !== 'WAIT' && 'AB'.includes(r.grade)).sort((a, b) => gi(a.grade) - gi(b.grade) || Math.abs(b.cons) - Math.abs(a.cons)).slice(0, 8);
  return card('بهترین ستاپ‌ها', 'bolt', best.length ? `<div class="list">${best.map(r => { const t = r.tfs['1h'] || Object.values(r.tfs)[0] || {}, tk = r.ticker || {};
    return `<div class="li" data-sym="${r.symbol}"><div class="coin">${dot(r.base)}${esc(r.base)}</div>${T.badge(r.verdict)}${gchip(r.grade)}<span class="mu sm">اجماع ${T.dg(sgn(r.cons))}</span><span class="sp"></span><span class="sm">R:R ${T.dg(t.rr || 0)}</span><span class="${tk.change_pct >= 0 ? 'up' : 'dn'} sm">${T.fpct(tk.change_pct, 1)}</span></div>`; }).join('')}</div><div class="note">درجه بر اساس اجماع، هم‌جهتی تایم‌فریم‌ها، رژیم، پیش‌بینی ۳۲ کندل، R:R و هشدارهاست (جزئیات در تب «خلاصه»).</div>` : '<div class="empty">فعلاً ستاپ درجه A/B وجود ندارد؛ صبر هم یک موقعیت است.</div>', 'w2');
};
W.top = rows => {
  const top = rows.map(r => ({ r, c: T.cons(r) })).sort((a, b) => Math.abs(b.c) - Math.abs(a.c)).slice(0, 6);
  return card('برترین سیگنال‌ها · کندل واقعی + ۳۲ کندل آینده', 'bolt', `<div class="grid2" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,230px),1fr))">${top.map(({ r, c }) => { const sd = T.consSide(c), col = T.col(sd), t = r.ticker || {}; return `<div class="pos chip-node" data-sym="${r.symbol}" style="cursor:pointer;border-color:color-mix(in srgb,${col} 45%,transparent)"><div class="row sb"><div class="coin">${dot(r.base)}${esc(r.base)}</div><span>${gchip(r.grade)} ${T.badge(sd)}</span></div><div class="row sb" style="font-size:.85em"><span class="ltr">${T.fp(t.price)}</span><span class="${t.change_pct >= 0 ? 'up' : 'dn'}">${T.fpct(t.change_pct, 1)}</span></div><div style="margin:6px 0 2px">${ch.miniCandles(r, 240, 84, col)}</div><div class="row sb note"><span>اجماع ${T.dg(sgn(c))}</span><span>${r.tfs['1h'] ? 'احتمال صعود ' + T.dg(Math.round((r.tfs['1h'].prob_up || .5) * 100)) + '٪' : ''}</span></div></div>`; }).join('')}</div><div class="mini-legend"><span><i style="background:var(--up)"></i>کندل واقعی صعودی</span><span><i style="background:var(--dn)"></i>نزولی</span><span><i style="background:var(--fu)"></i>آینده ▲</span><span><i style="background:var(--fd)"></i>آینده ▼</span><span>سایه = مخروط ۱۰–۹۰٪</span></div>`, 'w2');
};
W.alerts = () => {
  const al = ST.alerts || [], act = al.filter(a => !a.fired), fired = al.filter(a => a.fired).sort((a, b) => b.fired.t - a.fired.t).slice(0, 4);
  return card('هشدارهای من', 'bolt', `<div class="row sb"><span>${T.dg(act.length)} هشدار فعال</span><button class="btn" data-act="goalerts">افزودن هشدار</button></div>` + (fired.length ? `<div class="list" style="margin-top:8px">${fired.map(a => `<div class="li"><span class="go">🔔</span><span>${esc(a.fired.msg)}</span></div>`).join('')}</div>` : '<div class="note" style="margin-top:6px">برای هر ارز در تب «هشدار» می‌توانید هشدار قیمت یا سیگنال بسازید.</div>'));
};
W.mood = () => {
  const m = ST.market; if (!m) return card('حال‌وهوای بازار', 'pulse', '<div class="skel"></div>');
  const t1 = m.per_tf['1h'] || {}, t4 = m.per_tf['4h'] || {}, mt = m.mood >= 65 ? 'ریسک‌پذیری بالا' : m.mood >= 52 ? 'کمی خوش‌بین' : m.mood >= 40 ? 'خنثی' : m.mood >= 28 ? 'کمی بدبین' : 'ریسک‌گریزی شدید';
  return card('حال‌وهوای بازار', 'pulse', `<div class="row" style="flex-wrap:nowrap;justify-content:space-around"><div style="width:min(210px,56%)">${ch.gauge(m.avg_cons, 'میانگین اجماع', mt)}</div><div class="kpi" style="min-width:92px"><b style="color:${T.scol(m.avg_cons)}">${T.dg(m.mood)}</b><span>شاخص بازار</span></div></div><div class="kv" style="margin-top:8px"><span>بالای EMA200 (۱س / ۴س)</span><b>${T.dg(t1.above200 || 0)}٪ / ${T.dg(t4.above200 || 0)}٪</b><span>سیگنال خرید / فروش (۱س)</span><b><span class="up">${T.dg(t1.long || 0)}</span> / <span class="dn">${T.dg(t1.short || 0)}</span></b></div>`);
};
W.heat = rows => {
  const s = rows.slice().sort((a, b) => ((b.ticker || {}).change_pct || 0) - ((a.ticker || {}).change_pct || 0));
  return card('نقشه حرارتی ۲۴س · فشرده', 'pulse', `<div class="heat heat-sm">${s.map(r => {
    const c = (r.ticker || {}).change_pct || 0, col = c >= 0 ? 'var(--up)' : 'var(--dn)';
    const a = Math.min(78, 18 + Math.abs(c) * 10);
    const nm = (r.base || '').slice(0, 4);
    return `<div class="ht" data-sym="${r.symbol}" data-tip="${esc(r.base)}: ${T.fpct(c, 2)} · اجماع ${T.dg(sgn(T.cons(r)))}" style="--hc:${col};--ha:${a}%"><span class="ht-n">${esc(nm)}</span><span class="ht-v">${T.fpct(c, 1)}</span></div>`;
  }).join('')}</div><div class="note">مربع‌های کوچک رنگی · کلیک = تحلیل ارز</div>`, 'w2');
};
const tfCell = (tf, x) => x ? `<span class="tfc ${x.side}" data-tip="${tf}: ${T.SIDE_FA[x.side]} · امتیاز ${T.dg(sgn(x.score))} · اطمینان ${T.dg(Math.round(x.confidence * 100))}٪"><i>${tf}</i>${x.side === 'LONG' ? '▲' : x.side === 'SHORT' ? '▼' : '●'}</span>` : '';
W.matrix = rows => {
  if (T.isPhone()) return card('ماتریس کامل', 'chart', `<div class="mcards">${rows.map(r => { const t = r.ticker || {}, c = T.cons(r), sd = T.consSide(c);
    return `<div class="mc" data-sym="${r.symbol}"><div class="row sb" style="flex-wrap:nowrap"><div class="coin">${dot(r.base)}${esc(r.base)}${r.stale ? '<span class="go">⚠</span>' : ''}</div><div style="text-align:end"><div class="ltr">${T.fp(t.price)}</div><span class="${t.change_pct >= 0 ? 'up' : 'dn'}" style="font-size:.78em">${T.fpct(t.change_pct, 1)}</span></div></div>
    <div class="row sb" style="margin-top:6px;flex-wrap:nowrap"><div class="tfs">${ST.tfs.map(tf => tfCell(tf, r.tfs[tf])).join('')}</div><span style="color:${T.scol(c)};font-weight:800">${T.dg(sgn(c))}</span>${gchip(r.grade)}</div></div>`; }).join('')}</div>`, 'w2');
  const body = rows.map(r => { const t = r.ticker || {}, c = T.cons(r), sd = T.consSide(c), f = r.tfs['1h'] && r.tfs['1h'].forecast, fa = f === 'bullish' ? '<span class="up">▲</span>' : f === 'bearish' ? '<span class="dn">▼</span>' : '<span class="mu">▬</span>';
    return `<tr data-sym="${r.symbol}"><td><div class="coin">${dot(r.base)}${esc(r.base)}${r.stale ? '<span class="go" data-tip="داده قدیمی (منبع قطع)">⚠</span>' : ''}</div></td><td class="ltr">${T.fp(t.price)}</td><td class="${t.change_pct >= 0 ? 'up' : 'dn'}">${T.fpct(t.change_pct, 1)}</td><td style="min-width:90px">${ch.spark(r.spark, 90, 26, T.col(sd))}</td>
    ${ST.tfs.map(tf => { const x = r.tfs[tf]; return x ? `<td data-tip="${T.SIDE_FA[x.side]} · امتیاز ${T.dg(sgn(x.score))} · اطمینان ${T.dg(Math.round(x.confidence * 100))}٪ · رژیم ${T.REGIME_FA[x.regime] || ''}">${T.badge(x.side)}<span class="mu" style="font-size:.78em"> ${T.dg(sgn(x.score))}</span></td>` : '<td class="mu">·</td>'; }).join('')}
    <td style="color:${T.scol(c)};font-weight:800">${T.dg(sgn(c))}</td><td>${gchip(r.grade)}</td><td>${fa}</td></tr>`; }).join('');
  return card('ماتریس کامل', 'chart', `<div class="tw"><table><thead><tr><th>ارز</th><th>قیمت</th><th>۲۴س</th><th>روند</th>${ST.tfs.map(t => `<th>${t}</th>`).join('')}<th>اجماع</th><th>درجه</th><th>پیش‌بینی</th></tr></thead><tbody>${body}</tbody></table></div>`, 'w2');
};

/* ── extra dashboard windows (v2.6.1) ── */
W.heatcons = rows => {
  const s = rows.slice().sort((a, b) => Math.abs(T.cons(b)) - Math.abs(T.cons(a)));
  return card('نقشه حرارتی اجماع', 'target', `<div class="heat heat-sm">${s.map(r => {
    const c = T.cons(r), col = T.scol(c), a = Math.min(80, 15 + Math.abs(c) * 0.7);
    return `<div class="ht" data-sym="${r.symbol}" data-tip="${esc(r.base)} · اجماع ${T.dg(sgn(c))}" style="--hc:${col};--ha:${a}%"><span class="ht-n">${esc((r.base||'').slice(0,4))}</span><span class="ht-v">${T.dg(sgn(c))}</span></div>`;
  }).join('')}</div>`, 'w2');
};
W.leaders = rows => {
  const ranked = rows.map(r => ({ r, c: T.cons(r) })).sort((a, b) => b.c - a.c);
  const longs = ranked.filter(x => x.c >= 36).slice(0, 6);
  const shorts = ranked.filter(x => x.c <= -36).slice(0, 6);
  const row = (x, dir) => `<div class="li" data-sym="${x.r.symbol}"><div class="coin">${dot(x.r.base)}${esc(x.r.base)}</div>${T.badge(dir)}<span class="sp"></span><b style="color:${T.scol(x.c)}">${T.dg(sgn(x.c))}</b></div>`;
  return card('رهبران خرید / فروش', 'bolt', `<div class="grid2"><div><div class="note up">قوی‌ترین LONG</div>${longs.map(x => row(x,'LONG')).join('') || '<div class="empty">—</div>'}</div><div><div class="note dn">قوی‌ترین SHORT</div>${shorts.map(x => row(x,'SHORT')).join('') || '<div class="empty">—</div>'}</div></div>`, 'w2');
};
W.volrank = rows => {
  const s = rows.slice().sort((a, b) => ((b.ticker||{}).quote_volume||0) - ((a.ticker||{}).quote_volume||0)).slice(0, 12);
  return card('رتبه حجم معاملات', 'wallet', `<div class="heat heat-sm">${s.map((r,i) => {
    const qv = (r.ticker||{}).quote_volume || 0, c = T.cons(r);
    return `<div class="ht" data-sym="${r.symbol}" data-tip="${esc(r.base)} · حجم ${T.usd(qv)}" style="--hc:var(--a);--ha:${Math.min(75, 25 + (12-i)*4)}%"><span class="ht-n">${esc((r.base||'').slice(0,4))}</span><span class="ht-v">#${T.dg(i+1)}</span></div>`;
  }).join('')}</div>`, '');
};
W.squeeze = rows => {
  const sq = rows.filter(r => {
    const t = Object.values(r.tfs||{})[0] || {};
    return t.squeeze || (t.warns && t.warns > 0 && (t.atr||0) < 1);
  }).slice(0, 16);
  const all = rows.filter(r => (Object.values(r.tfs||{})[0]||{}).squeeze).slice(0, 16);
  const list = all.length ? all : sq;
  return card('فشردگی / آماده حرکت', 'pulse', list.length ? `<div class="chips">${list.map(r => `<span class="chip chip-node" data-sym="${r.symbol}" style="cursor:pointer">${esc(r.base)} ${T.badge(T.consSide(T.cons(r)))}</span>`).join('')}</div><div class="note">بولینگر فشرده یا هشدار نوسان کم — احتمال حرکت انفجاری</div>` : '<div class="empty">الان فشردگی مشخصی نیست.</div>');
};
W.gradeboard = rows => {
  const buckets = { A: [], B: [], C: [], D: [] };
  rows.forEach(r => { const g = r.grade || '—'; if (buckets[g]) buckets[g].push(r); });
  const cell = (g, arr) => `<div class="kpi" style="min-height:auto"><b class="gr g${g}" style="font-size:1.4em">${g}</b><span>${T.dg(arr.length)} ستاپ</span><div class="chips" style="margin-top:6px">${arr.slice(0,5).map(r => `<span class="chip chip-node" data-sym="${r.symbol}" style="cursor:pointer">${esc((r.base||'').slice(0,5))}</span>`).join('')}</div></div>`;
  return card('تابلوی درجه ستاپ', 'shield', `<div class="kpis">${['A','B','C','D'].map(g => cell(g, buckets[g])).join('')}</div>`, 'w2');
};
W.momentum = rows => {
  const s = rows.slice().sort((a, b) => Math.abs(((b.ticker||{}).change_pct||0)) - Math.abs(((a.ticker||{}).change_pct||0))).slice(0, 10);
  return card('شتاب ۲۴ ساعته', 'bolt', `<div class="tw"><table><thead><tr><th>ارز</th><th>تغییر</th><th>اجماع</th><th>سیگنال</th></tr></thead><tbody>${s.map(r => {
    const chg = (r.ticker||{}).change_pct||0, c = T.cons(r), sd = T.consSide(c);
    return `<tr data-sym="${r.symbol}" style="cursor:pointer"><td>${esc(r.base)}</td><td class="${chg>=0?'up':'dn'}">${T.fpct(chg,1)}</td><td style="color:${T.scol(c)}">${T.dg(sgn(c))}</td><td>${T.badge(sd)}</td></tr>`;
  }).join('')}</tbody></table></div>`, 'w2');
};
W.session = () => {
  const h = new Date().getUTCHours();
  const name = h < 7 ? 'آسیا' : h < 13 ? 'اروپا' : h < 17 ? 'هم‌پوشانی EU/US' : h < 22 ? 'آمریکا' : 'پایان روز';
  const liq = h < 7 ? 75 : h < 13 ? 105 : h < 17 ? 120 : h < 22 ? 110 : 80;
  return card('جلسه معاملاتی (UTC)', 'radar', `<div class="kpis"><div class="kpi"><b>${esc(name)}</b><span>جلسه فعلی · ساعت ${T.dg(h)} UTC</span></div><div class="kpi"><b>${T.dg(liq)}٪</b><span>نقدشوندگی نسبی</span></div></div><div class="note">بهترین نقدشوندگی معمولاً در هم‌پوشانی اروپا/آمریکا است.</div>`);
};
W.riskmap = rows => {
  const hot = rows.filter(r => Math.abs(T.cons(r)) >= 50 && (r.grade === 'C' || r.grade === 'D')).slice(0, 8);
  const safe = rows.filter(r => (r.grade === 'A' || r.grade === 'B') && Math.abs(T.cons(r)) >= 36).slice(0, 8);
  return card('نقشه ریسک / کیفیت', 'shield', `<div class="grid2"><div><div class="note up">کیفیت بالا (A/B)</div>${safe.map(r => `<div class="li" data-sym="${r.symbol}"><div class="coin">${dot(r.base)}${esc(r.base)}</div>${gchip(r.grade)}<span class="sp"></span><b style="color:${T.scol(T.cons(r))}">${T.dg(sgn(T.cons(r)))}</b></div>`).join('') || '<div class="empty">—</div>'}</div><div><div class="note dn">اجماع قوی ولی درجه ضعیف</div>${hot.map(r => `<div class="li" data-sym="${r.symbol}"><div class="coin">${dot(r.base)}${esc(r.base)}</div>${gchip(r.grade)}<span class="sp"></span><b style="color:${T.scol(T.cons(r))}">${T.dg(sgn(T.cons(r)))}</b></div>`).join('') || '<div class="empty">—</div>'}</div></div>`, 'w2');
};
W.align = rows => {
  const good = rows.filter(r => (r.aligned || 0) >= 3 || (r.grade === 'A')).slice(0, 10);
  return card('هم‌جهتی چندتایم‌فریم', 'chart', good.length ? `<div class="chips">${good.map(r => `<span class="chip chip-node" data-sym="${r.symbol}" style="cursor:pointer">${esc(r.base)} · ${T.dg(r.aligned||0)}TF ${gchip(r.grade)}</span>`).join('')}</div>` : '<div class="empty">هم‌جهتی کامل کمیاب است؛ صبر ارزشمند است.</div>');
};
W.breadth = rows => {
  let up = 0, dn = 0;
  rows.forEach(r => { const c = (r.ticker||{}).change_pct||0; if (c > 0) up++; else if (c < 0) dn++; });
  const tot = rows.length || 1;
  return card('عرض بازار (Breadth)', 'flow', `<div class="kpis"><div class="kpi"><b class="up">${T.dg(up)}</b><span>مثبت ۲۴س</span></div><div class="kpi"><b class="dn">${T.dg(dn)}</b><span>منفی ۲۴س</span></div><div class="kpi"><b>${T.dg(Math.round(up/tot*100))}٪</b><span>نسبت صعودی</span></div></div><div class="bar" style="height:10px;margin-top:8px"><i style="left:0;width:${up/tot*100}%;background:var(--up)"></i><i style="right:0;width:${dn/tot*100}%;background:var(--dn)"></i></div>`);
};
W.watch = rows => {
  const picks = rows.filter(r => r.grade === 'A' || r.grade === 'B').sort((a,b) => Math.abs(T.cons(b))-Math.abs(T.cons(a))).slice(0, 8);
  return card('واچ‌لیست پیشنهادی امروز', 'target', picks.length ? `<div class="scgrid">${picks.map(r => {
    const c = T.cons(r), sd = T.consSide(c), t = r.ticker||{};
    return `<div class="sc" data-sym="${r.symbol}"><div class="row sb"><div class="coin">${dot(r.base)}${esc(r.base)}</div>${gchip(r.grade)}${T.badge(sd)}</div><div class="row sb"><span class="ltr">${T.fp(t.price)}</span><b style="color:${T.scol(c)}">${T.dg(sgn(c))}</b></div></div>`;
  }).join('')}</div>` : '<div class="empty">ستاپ A/B آماده نیست.</div>', 'w2');
};
W.corrbtc = rows => {
  const withC = rows.filter(r => r.corr != null).sort((a,b) => (b.corr||0)-(a.corr||0));
  const hi = withC.slice(0, 6), lo = withC.slice(-6).reverse();
  if (!withC.length) return card('همبستگی با BTC', 'radar', '<div class="empty">بعد از اسکن با داده ۱ساعته محاسبه می‌شود.</div>');
  const row = r => `<div class="li" data-sym="${r.symbol}"><div class="coin">${dot(r.base)}${esc(r.base)}</div><span class="sp"></span><b>ρ ${T.dg((r.corr||0).toFixed(2))}</b></div>`;
  return card('همبستگی با BTC', 'radar', `<div class="grid2"><div><div class="note">بیشترین همبستگی</div>${hi.map(row).join('')}</div><div><div class="note">کمترین همبستگی</div>${lo.map(row).join('')}</div></div>`, 'w2');
};

let homeChart = null, homeKey = '';
function storiesHtml(rows) {
  const d = rows.map(r => ({ r, c: T.cons(r) })).sort((a, b) => Math.abs(b.c) - Math.abs(a.c)).slice(0, 14);
  return `<div class="stories">${d.map(({ r, c }) => `<div class="story" data-sym="${r.symbol}" style="--sc:${T.col(T.consSide(c))}"><i>${esc(r.base.slice(0, 4))}</i>${T.dg(sgn(c))}<small class="${((r.ticker || {}).change_pct || 0) >= 0 ? 'up' : 'dn'}">${T.fpct((r.ticker || {}).change_pct, 1)}</small></div>`).join('')}</div>`;
}
function homeTop(rows) {
  const top = $('#home-top');
  if (T.UI.skin !== 'chart') { if (homeChart) { homeChart.destroy(); homeChart = null; } top._h = ''; if (top.innerHTML) top.innerHTML = ''; return; }
  if (!top.querySelector('#hh-host')) { top.innerHTML = '<div class="card chcard homehero"><div id="hh-bar"></div><div id="hh-host"></div></div>'; if (homeChart) homeChart.destroy(); homeChart = null; homeKey = ''; }
  const strip = rows.slice().sort((a, b) => Math.abs(T.cons(b)) - Math.abs(T.cons(a))).slice(0, 14);
  put($('#hh-bar'), `<div class="row sb" style="flex-wrap:nowrap"><b class="ctitle">${esc((ST.sel || '').replace('USDT', '') || '—')}<small> / USDT</small></b>${tfChips(ST.tf)}</div><div class="chips hs" style="margin:8px 0">${strip.map(r => `<button class="chip ${r.symbol === ST.sel ? 'on' : ''} ${T.consSide(T.cons(r))}" data-act="hsel" data-s="${r.symbol}">${esc(r.base)}</button>`).join('')}</div>`);
  if (!ST.sel && strip.length && !ST._autoSel) { ST._autoSel = 1; T.loadCoin(strip[0].symbol); }
  const c = ST.coin; if (!c || c.error) return; const d = ST.deep, plan = d && d.verdict && d.verdict !== 'WAIT' && d.signal ? d.signal : c.signal;
  const key = [ST.sel, ST.tf, c.updated, JSON.stringify(T.UI.chart), T.UI.candle, T.UI.cone, T.UI.grid, T.UI.wick, ST.pat && ST.patAt, plan && plan.entry].join('|'); if (key === homeKey && homeChart) return; homeKey = key;
  if (!homeChart) homeChart = new ch.CandleChart($('#hh-host'));
  homeChart.set(c.klines, { signal: plan, forecast: c.forecast, tf: ST.tf, layers: T.UI.chart.layers, panes: T.UI.chart.panes, pat: ST.pat && ST.pat.symbol === ST.sel ? ST.pat : null });
}
function buildTape(rows) {
  const on = T.UI.header === 'ticker' || T.UI.skin === 'terminal', el = $('#tape-in'); if (!el) return; if (!on || !rows.length) { el.innerHTML = ''; el._h = ''; return; }
  const one = rows.map(r => { const t = r.ticker || {}, up = (t.change_pct || 0) >= 0; return `<span><b>${esc(r.base)}</b> ${T.fp(t.price)} <span class="${up ? 'up' : 'dn'}">${up ? '▲' : '▼'}${T.fpct(t.change_pct, 2)}</span></span>`; }).join('');
  put(el, one + one);
}
R.home = function () {
  const rows = rowsOf(); buildTape(rows);
  let body = $('#home-body');
  if (!body) { $('#p-home').innerHTML = '<div id="home-top"></div><div id="home-body"></div>'; body = $('#home-body'); }
  homeTop(rows);
  if (!rows.length) { const p = ST.prog; put(body, card('در حال راه‌اندازی', 'scan', `<div class="empty">اولین اسکن چند ثانیه طول می‌کشد…<div class="skel" style="margin:14px auto;max-width:320px"></div>${ST.scanning ? T.dg(`${p.done}/${p.total}`) : 'برای شروع دکمه «اسکن» را بزنید.'}</div>`)); return; }
  put(body, (T.UI.skin === 'app' ? storiesHtml(rows) : '') + `<div class="hgrid">${T.UI.home.filter(w => w.on && W[w.id]).map(w => { let h = W[w.id](rows); if (w.wide === 1 && !/class="card[^"]*\bw2\b/.test(h)) h = h.replace('class="card ', 'class="card w2 '); else if (w.wide === 0) h = h.replace(/(class="card[^"]*)\bw2\b/, '$1'); return h; }).join('')}</div>`);
};

/* ═══════════ COIN ANALYSIS (tabbed) ═══════════ */
const GROUPS = { trend: 'روند', momentum: 'مومنتوم', revert: 'بازگشت', volume: 'حجم', structure: 'ساختار', pattern: 'الگو' };
function radarAxes(s) { return Object.keys(GROUPS).map(g => { const cs = (s.components || []).filter(c => c.g === g), w = cs.reduce((a, c) => a + c.w, 0) || 1; return { n: GROUPS[g], v: cs.reduce((a, c) => a + c.s * c.w, 0) / w }; }); }
const MB = { coin: [], mtf: [] };
function killMinis(k) { MB[k].forEach(m => m.destroy()); MB[k] = []; }
function mountMinis(el, k) {
  el.querySelectorAll('.mini-ch').forEach(h => { const c = new ch.CandleChart(h, { mini: true, onTap: () => { if (k === 'coin') T.go('chart'); else { ST.tf = h.dataset.tf; T.loadCoin(ST.sel, true); ST.tab.chart = 'main'; T.render(); } } }); const src = k === 'mtf' ? ST.mtf[h.dataset.tf] : ST.coin; if (!src || !src.klines) return;
    c.set(src.klines.slice(-110), { signal: src.signal, forecast: src.forecast, tf: h.dataset.tf || ST.tf, layers: { ema: 1, fc: 1, lv: 0, vol: 0, bb: 0 } }); MB[k].push(c); });
}
const stc = (v, lo, hi) => v >= hi ? 'var(--dn)' : v <= lo ? 'var(--up)' : 'var(--tx)';
const TAB = {};

TAB.sum = x => {
  const { s, t, ind, base, plan, d, c, edge, pf } = x, gr = d && d.grade, tfLbl = ST.tf;
  const adv = (d && d.advanced) || {}, eg = adv.edge || {}, ck = adv.checklist || {}, sess = adv.session || {}, rs = adv.rel_strength || {}, mb = (adv.micro || {}).bias_pack || {};
  const ek = (ind && ind.entry_kind) || ((s.levels || {}).entry_kind) || 'market';
  const hero = card(`${esc(base)} / USDT`, 'target', `<div class="hero"><div class="gw">${ch.gauge(s.score, 'امتیاز ' + tfLbl, T.SIDE_FA[s.side])}</div><div class="hb"><div class="big ltr" style="color:${T.col(s.side)}">${T.fp(t.price || s.entry)}</div><div class="row" style="margin:6px 0">${T.badge(s.side)}<span class="${t.change_pct >= 0 ? 'up' : 'dn'}">${T.fpct(t.change_pct, 2)} (۲۴س)</span><span class="chip">رژیم ${T.REGIME_FA[s.regime] || '—'}</span>${ek === 'limit' ? '<span class="chip up">ورود لیمیت</span>' : ''}${ind.squeeze ? '<span class="chip go">فشردگی</span>' : ''}${c.stale ? '<span class="chip dn">داده قدیمی</span>' : ''}</div>
  <div class="note">اطمینان ${T.dg(Math.round(s.confidence * 100))}٪ · هم‌سویی مولفه‌ها ${T.dg(Math.round((s.agree || 0) * 100))}٪ · گرایش ${s.bias === 'bull' ? 'صعودی' : s.bias === 'bear' ? 'نزولی' : 'خنثی'}${eg.edge != null ? ' · Edge ' + T.dg(eg.edge) + '/100' : ''}</div><div class="bar" style="margin:8px 0"><i style="right:0;width:${Math.round(s.confidence * 100)}%;background:linear-gradient(90deg,var(--a),var(--c))"></i></div>${tfChips(tfLbl)}</div></div>`);
  const verdict = d && !d.error ? card('حکم چندتایم‌فریمی', 'shield', `<div class="row">${T.badge(d.verdict)}${gr ? gchip(gr.grade) : ''}<span class="chip">اجماع ${T.dg(sgn(d.consensus_score))}</span><span class="chip">باور ${T.dg(Math.round(d.conviction * 100))}٪</span>${d.veto ? `<span class="chip dn">${esc(d.veto)}</span>` : ''}</div>
    ${gr && gr.why && gr.why.length ? `<details class="why"><summary>چرا درجه ${gr.grade}؟ (${T.dg(gr.points)} امتیاز)</summary>${gr.why.map(w => `<div class="wy"><b style="color:${w.p > 0 ? 'var(--up)' : w.p < 0 ? 'var(--dn)' : 'var(--mu)'}">${w.p > 0 ? '+' : ''}${T.dg(w.p)}</b><span>${esc(w.t)}</span></div>`).join('')}</details>` : '<div class="note" style="margin-top:6px">ستاپ معتبری برای ورود وجود ندارد؛ منتظر هم‌جهت شدن تایم‌فریم‌ها بمانید.</div>'}
    <p class="note" style="margin:8px 0 0">${esc(d.narrative)}</p>`) : card('حکم چندتایم‌فریمی', 'shield', '<div class="skel"></div>');
  // ── Advanced Edge + microstructure + session + RS ──
  let edgeCard = '';
  if (eg && eg.edge != null) {
    const parts = eg.parts || {};
    const bars = Object.entries(parts).map(([k, v]) => {
      const w = Math.max(2, Math.min(100, Math.abs(v) * 4));
      const col = v >= 0 ? 'var(--up)' : 'var(--dn)';
      return `<div class="wy"><b style="color:${col};min-width:42px">${v >= 0 ? '+' : ''}${T.dg(v)}</b><span>${esc(k)}</span><span class="str" style="flex:1;max-width:120px"><i style="width:${w}%;background:${col}"></i></span></div>`;
    }).join('');
    edgeCard = card(`امتیاز برتری · Edge ${T.dg(eg.edge)}/100`, 'bolt', `<div class="row"><span class="chip ${eg.edge >= 55 ? 'up' : eg.edge >= 40 ? '' : 'dn'}">${esc(eg.label || '')}</span><span class="note">${esc(eg.note || '')}</span></div><div style="margin-top:8px">${bars}</div><div class="note" style="margin-top:6px">ترکیب امتیاز سیگنال، اعتماد، هم‌سویی، R:R، درجه، conviction، پیش‌بینی، میکروساختار، قدرت نسبی و جلسه معاملاتی. برای رتبه‌بندی فرصت‌هاست نه احتمال برد کالیبره‌شده.</div>`);
  }
  let microCard = '';
  if (mb && (mb.label || mb.parts)) {
    const chips = (mb.parts || []).map(p => `<span class="chip ${p.w > 0.05 ? 'up' : p.w < -0.05 ? 'dn' : ''}">${esc(p.t)}</span>`).join('');
    const kv = [];
    if (mb.funding_pct != null) kv.push(['فاندینگ', `${mb.funding_pct >= 0 ? '+' : ''}${T.dg(mb.funding_pct)}٪`]);
    if (mb.ls_buy != null) kv.push(['نسبت لانگ', `${T.dg(Math.round(mb.ls_buy * 100))}٪`]);
    if (mb.oi_usd != null) kv.push(['بهره باز', T.usd(mb.oi_usd)]);
    if (mb.imbalance != null) kv.push(['عدم‌تعادل دفتر', `${mb.imbalance >= 0 ? '+' : ''}${T.dg(mb.imbalance)}`]);
    if (mb.basis_pct != null) kv.push(['بیسیس', `${mb.basis_pct >= 0 ? '+' : ''}${T.dg(mb.basis_pct)}٪`]);
    microCard = card('میکروساختار · فاندینگ و دفتر سفارش', 'pulse', `<div class="row"><span class="chip ${mb.bias > 0.15 ? 'up' : mb.bias < -0.15 ? 'dn' : ''}">${esc(mb.label || 'خنثی')}</span><span class="note">امتیاز ${T.dg(mb.score || 0)}</span></div>${kv.length ? kvs(kv) : ''}<div class="chips" style="margin-top:8px">${chips}</div>`);
  }
  let metaCard = '';
  if (sess.name || (rs && rs.ok) || (ck && ck.items)) {
    const bits = [];
    if (sess.name) bits.push(`<div class="kv"><span>جلسه معاملاتی (UTC ${T.dg(sess.hour_utc)})</span><b>${esc(sess.name)}</b>${sess.note ? `<span class="note">${esc(sess.note)}</span>` : ''}</div>`);
    if (rs && rs.ok) bits.push(`<div class="kv"><span>قدرت نسبی vs BTC (${T.dg(rs.look)} کندل)</span><b class="${rs.rs_pct >= 0 ? 'up' : 'dn'}">${rs.rs_pct >= 0 ? '+' : ''}${T.dg(rs.rs_pct)}٪</b><span>همبستگی ${T.dg(rs.corr)} · بتا ${T.dg(rs.beta)}</span><span class="note">${esc(rs.label || '')}</span></div>`);
    if (ck && ck.items) {
      const okN = ck.items.filter(i => i.ok).length;
      bits.push(`<div class="row" style="margin-top:6px"><span class="chip ${ck.pct >= 0.65 ? 'up' : ck.pct >= 0.45 ? '' : 'dn'}">کامل‌بودن ستاپ: ${esc(ck.label)} (${T.dg(okN)}/${T.dg(ck.max)})</span></div>
        <div style="margin-top:6px">${ck.items.map(i => `<div class="wy"><b style="color:${i.ok ? 'var(--up)' : 'var(--dn)'}">${i.ok ? '✔' : '✖'}</b><span>${esc(i.t)}</span></div>`).join('')}</div>`);
    }
    metaCard = card('کیفیت ستاپ · جلسه · قدرت نسبی', 'shield', bits.join(''));
  }
  const warn = (s.warnings || []).length ? card('هشدارها', 'shield', `<div class="chips">${s.warnings.map(w => `<span class="chip go">⚠ ${esc(w)}</span>`).join('')}</div>`) : '';
  const ev = edge ? `<div class="kv" style="margin-top:10px"><span>رسیدن به TP1 قبل از حدضرر</span><b class="${edge.p_tp1 >= .5 ? 'up' : 'dn'}">${pct(edge.p_tp1)}</b><span>رسیدن به TP2 / TP3</span><b>${pct(edge.p_tp2)} / ${pct(edge.p_tp3)}</b><span>خوردن حدضرر</span><b class="dn">${pct(edge.p_stop)}</b><span>امید ریاضی هر معامله</span><b style="color:${edge.ev_r >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(edge.ev_r.toFixed(2))}R</b><span>بازه ۹۰٪ نتیجه</span><b>${T.dg(edge.worst_r.toFixed(1))}R تا ${T.dg(edge.best_r.toFixed(1))}R</b><span>زمان میانه تا TP1</span><b>${edge.t_tp1 ? hrs(edge.t_tp1, ST.tf) : '—'}</b></div><div class="note">بر پایه ۶۰۰ مسیر شبیه‌سازی شده روی همین نمودار؛ ریسک ثابت، خروج پله‌ای ۴۰/۳۵/۲۵ و سر‌به‌سر بعد از TP1. این «احتمال ساختاری» است؛ لبه واقعی را در تب «بک‌تست» بسنجید.</div>` : '';
  const ladder = card('طرح معامله', 'target', `<div class="svgw" style="max-width:340px;margin:auto">${ch.ladder(plan || s, t.price)}</div>${ev}${plan ? `<div class="row" style="margin-top:10px"><label class="note">اهرم <input type="number" id="lev" value="10" min="1" max="${(ST.status || {}).max_leverage || 50}" style="width:64px"></label><button class="btn ${plan.side === 'LONG' ? 'up' : 'dn'}" data-act="open" data-side="${plan.side}">باز کردن ${T.SIDE_FA[plan.side]} (کاغذی)</button></div><div class="note">ریسک ۱٪ سرمایه · خروج پله‌ای · R:R ${T.dg(plan.risk_reward)}${ek === 'limit' ? ' · ورود پیشنهادی لیمیت روی ساختار' : ''}</div>` : '<div class="note" style="margin-top:8px">سیگنال فعالی نیست؛ منتظر تایید بمانید.</div>'}`);
  const prev = card(`پیش‌نمایش نمودار + ${T.dg(pf.n || 32)} کندل آینده`, 'chart', `<div class="mini-ch" data-tf="${ST.tf}"></div><div class="row sb" style="margin-top:8px"><span class="note">کندل‌های رنگی: مسیر معمول شبیه‌سازی‌شده</span><button class="btn" data-act="nav" data-p="chart">نمودار کامل</button></div>`);
  TAB.sum.parts = { hero, verdict, edgeCard, microCard, metaCard, warn, prev, ladder };
  return hero + verdict + edgeCard + microCard + metaCard + warn + prev + ladder;
};

TAB.tech = x => {
  const { s, ind, c } = x, ex = s.extras || {}, ic = ex.ichimoku || {}, st = ex.stats || {}, px = (x.t.price || s.entry);
  const dist = v => v ? ` <span class="mu">(${T.fpct((v / px - 1) * 100, 1)})</span>` : '';
  const radar = card('رادار گروه‌ها', 'brain', `<div class="svgw" style="max-width:300px;margin:auto">${ch.radar(radarAxes(s))}</div><div class="chips" style="margin-top:8px">${(s.reasons || []).slice(0, 6).map(r => `<span class="chip">${esc(r)}</span>`).join('')}</div>`);
  const sel2 = ST.dtSel && (s.components || []).find(z => z.k === ST.dtSel);
  const comps = card(`مولفه‌های تصمیم (${T.dg((s.components || []).length)})`, 'flow', `<div id="dt-info" class="note dt-info">${sel2 ? `<b style="color:${T.scol(sel2.s * 100)}">${esc(sel2.n)}</b> — ${esc(sel2.t)} · وزن ${T.dg(sel2.w)} · امتیاز ${T.dg(sgn(sel2.s * 100))}` : 'هر ردیف یک مولفه است؛ نوار سبز = صعودی، قرمز = نزولی. برای توضیح روی ردیف بزنید.'}</div>${ch.compList(s.components, ST.dtSel)}`, 'w2');
  const tree = T.isPhone() ? '' : card('شماتیک تصمیم‌گیری', 'flow', `<div class="svgw">${ch.tree(s, ST.dtSel)}</div>`);
  const I = [['RSI 14', T.dg(ind.rsi), stc(ind.rsi, 30, 70)], ['StochRSI', T.dg(ind.srsi_k), stc(ind.srsi_k, 20, 80)], ['MFI', T.dg(ind.mfi), stc(ind.mfi, 20, 80)], ['CMF', T.dg(ind.cmf), ind.cmf > 0 ? 'var(--up)' : 'var(--dn)'], ['ADX', T.dg(ind.adx), ind.adx >= 25 ? 'var(--a)' : 'var(--mu)'], ['+DI / −DI', `${T.dg(ind.pdi)} / ${T.dg(ind.mdi)}`], ['ATR٪', T.dg(ind.atr_pct)], ['حجم نسبی', T.dg(ind.vol_ratio) + '×', ind.vol_ratio > 1.5 ? 'var(--a)' : null], ['ROC 10', T.fpct(ind.roc10)], ['MACD هیستوگرام', T.dg(ind.macd_hist)], ['سوپرترند', ind.supertrend > 0 ? 'صعودی' : 'نزولی', ind.supertrend > 0 ? 'var(--up)' : 'var(--dn)'], ['موقعیت در بولینگر', pct(ind.bb_pos)]];
  const L = [['EMA 9', ind.ema9], ['EMA 21', ind.ema21], ['EMA 50', ind.ema50], ['EMA 200', ind.ema200], ['VWAP', ind.vwap], ['Donchian بالا', ind.donch_hi], ['Donchian پایین', ind.donch_lo]];
  const ind1 = card('اندیکاتورها', 'gear', kvs(I), '') + card('میانگین‌ها و فاصله از قیمت', 'gear', `<div class="kv">${L.map(([k, v]) => `<span>${k}</span><b class="ltr">${T.fp(v)}${dist(v)}</b>`).join('')}</div>`);
  const ich = ic.tenkan ? card('ایچیموکو', 'pulse', kvs([['موقعیت قیمت', ic.pos > 0 ? 'بالای ابر' : ic.pos < 0 ? 'زیر ابر' : 'داخل ابر', ic.pos > 0 ? 'var(--up)' : ic.pos < 0 ? 'var(--dn)' : 'var(--go)'], ['تنکان / کیجون', `${T.fp(ic.tenkan)} / ${T.fp(ic.kijun)}`], ['سقف / کف ابر', `${T.fp(ic.cloud_top)} / ${T.fp(ic.cloud_bot)}`], ['ضخامت ابر', T.dg(ic.thick_pct) + '٪'], ['ابر آینده', ic.future_bull ? 'صعودی' : 'نزولی', ic.future_bull ? 'var(--up)' : 'var(--dn)'], ['چیکو', ic.chikou > 0 ? 'بالای قیمت قبلی' : 'پایین قیمت قبلی']])) : '';
  const stt = st.vol_pct != null ? card('آمار رفتار قیمت', 'pulse', kvs([['صدک نوسان (۱۲۰ کندل)', T.dg(st.vol_pct) + '٪', st.vol_pct > 85 ? 'var(--go)' : null], ['ماهیت حرکت', st.hurst_hint + ' (VR ' + T.dg(st.vr4) + ')'], ['چولگی / کشیدگی', `${T.dg(st.skew)} / ${T.dg(st.kurt)}`], ['خودهمبستگی ۱', T.dg(st.ac1)], ['افت از سقف ۱۰۰ کندل', T.fpct(st.dd_from_high), 'var(--dn)'], ['رشد از کف ۱۰۰ کندل', T.fpct(st.up_from_low), 'var(--up)'], ['جایگاه در رنج ۱۰۰ کندل', pct(st.range_pos)], ['سری کندل هم‌رنگ', T.dg(Math.abs(st.streak)) + (st.streak > 0 ? ' صعودی' : st.streak < 0 ? ' نزولی' : '')], ['میانگین دامنه کندل', T.dg(st.avg_range_pct) + '٪'], ['سهم کندل صعودی (۵۰)', pct(st.up_ratio)]])) : '';
  return `<div class="grid2">${radar}${ind1}</div>` + comps + oscCards(s) + tree + `<div class="grid2">${ich}${stt}</div>`;
};

TAB.mtf = x => {
  const { d } = x; if (!d || d.error || !d.all_tf) return card('چندتایم‌فریم', 'chart', '<div class="skel"></div>');
  const tfs = Object.keys(d.all_tf), rows = tfs.map(tf => { const z = d.all_tf[tf], f = (d.all_forecasts || {})[tf] || {}, e = f.edge;
    return `<tr><td><b>${tf}</b></td><td>${T.badge(z.side)}</td><td style="color:${T.scol(z.score)}">${T.dg(sgn(z.score))}</td><td>${T.dg(Math.round(z.confidence * 100))}٪</td><td>${T.REGIME_FA[z.regime] || ''}</td><td>${T.dg(z.indicators.adx)}</td><td>${f.prob_up != null ? T.dg(Math.round(f.prob_up * 100)) + '٪↑' : ''}</td><td class="${(f.expected_move_pct || 0) >= 0 ? 'up' : 'dn'}">${f.expected_move_pct != null ? T.fpct(f.expected_move_pct, 1) : ''}</td><td>${e ? T.dg(e.ev_r.toFixed(2)) + 'R' : '—'}</td></tr>`; }).join('');
  return card('خلاصه تایم‌فریم‌ها', 'chart', `<div class="row" style="margin-bottom:8px">${T.badge(d.verdict)}${d.grade ? gchip(d.grade.grade) : ''}<span class="chip">اجماع ${T.dg(sgn(d.consensus_score))}</span><span class="chip">باور ${T.dg(Math.round(d.conviction * 100))}٪</span>${d.veto ? `<span class="chip dn">${esc(d.veto)}</span>` : ''}</div><div class="tw"><table><thead><tr><th>TF</th><th>سیگنال</th><th>امتیاز</th><th>اطمینان</th><th>رژیم</th><th>ADX</th><th>صعود ۳۲ک</th><th>حرکت</th><th>امید R</th></tr></thead><tbody>${rows}</tbody></table></div>`, 'w2')
    + card('نقشه حرارتی مولفه × تایم‌فریم', 'brain', ch.heatgrid(d.all_tf, tfs) + '<div class="note">هر خانه امتیاز یک مولفه در یک تایم‌فریم است (−۱۰۰ تا +۱۰۰). ستونی که رنگش با بقیه فرق دارد، منبع تضاد است.</div>')
    + card('روایت تحلیل', 'flow', `<p class="note" style="margin:0;line-height:2">${esc(d.narrative)}</p>`);
};

TAB.fc = x => {
  const { pf, plan, t, s } = x; if (!pf || !pf.candles || !pf.candles.length) return card('پیش‌بینی', 'pulse', '<div class="empty">داده کافی برای پیش‌بینی نیست.</div>');
  const b = pf.bands, n = pf.candles.length, last = (x.c.klines && x.c.klines.length) ? x.c.klines[x.c.klines.length - 1].c : (t.price || s.entry), mv = v => (v / last - 1) * 100;
  const marks = [{ v: pf.expected_move_pct, c: 'var(--c)', l: 'میانه' }];
  if (plan && plan.side !== 'WAIT') { marks.push({ v: mv(plan.tp1), c: 'var(--up)', l: 'TP1' }, { v: mv(plan.stop), c: 'var(--dn)', l: 'SL' }); }
  const K = (l, v, col) => `<div class="kpi"><b style="color:${col || 'var(--tx)'}">${v}</b><span>${l}</span></div>`;
  const kp = card(`خلاصه ${T.dg(n)} کندل آینده`, 'pulse', `<div class="kpis">${K('احتمال صعود', pct(pf.prob_up), pf.prob_up >= .5 ? 'var(--up)' : 'var(--dn)')}${K('حرکت میانه', T.fpct(pf.expected_move_pct), pf.expected_move_pct >= 0 ? 'var(--up)' : 'var(--dn)')}${K('احتمال > ‎+۱٪', pct(pf.p_up10), 'var(--up)')}${K('احتمال < ‎−۱٪', pct(pf.p_dn10), 'var(--dn)')}${K('نوسان هر کندل', T.dg(pf.sigma_pct.toFixed(2)) + '٪')}${K('همخوانی با سیگنال', pf.alignment === 'aligned' ? '✔ همسو' : pf.alignment === 'divergent' ? '✖ مخالف' : '—')}</div>
    <div class="kv" style="margin-top:12px"><span>خوش‌بینانه (۹۰٪)</span><b class="up ltr">${T.fp(b.p90[n - 1])} (${T.fpct(mv(b.p90[n - 1]), 1)})</b><span>میانه (۵۰٪)</span><b class="ltr">${T.fp(b.p50[n - 1])} (${T.fpct(mv(b.p50[n - 1]), 1)})</b><span>بدبینانه (۱۰٪)</span><b class="dn ltr">${T.fp(b.p10[n - 1])} (${T.fpct(mv(b.p10[n - 1]), 1)})</b><span>سقف / کف انتظاری مسیر</span><b class="ltr">${T.fp(pf.range.hi)} / ${T.fp(pf.range.lo)}</b></div>`, 'w2');
  const h1 = card('توزیع قیمت پایان بازه', 'chart', `<div class="svgw">${ch.hist(pf.hist, marks)}</div><div class="note">ستون‌ها نتیجه ۶۰۰ مسیر هستند؛ خط‌چین‌ها میانه و سطوح معامله.</div>`);
  const h2 = card('احتمال بالاتر بودن از قیمت فعلی', 'pulse', `<div class="svgw">${ch.stepProb(pf.step_prob)}</div><div class="note">محور افقی: شماره کندل آینده. نزدیک ۵۰٪ یعنی بازار جهت واضحی ندارد.</div>`);
  const stepsIdx = [3, 7, 11, 15, 19, 23, 27, 31].filter(i => i < n);
  const rows = stepsIdx.map(i => { const cd = pf.candles[i]; return `<tr><td>+${T.dg(i + 1)} <span class="mu sm">${hrs(i + 1, ST.tf)}</span></td><td class="ltr">${T.fp(cd.close)}</td><td class="${cd.close >= last ? 'up' : 'dn'}">${T.fpct(mv(cd.close), 1)}</td><td class="ltr mu">${T.fp(b.p10[i])} – ${T.fp(b.p90[i])}</td><td class="${pf.step_prob[i] >= .5 ? 'up' : 'dn'}">${pct(pf.step_prob[i])}</td></tr>`; }).join('');
  const full = pf.candles.map((cd, i) => `<tr><td>${T.dg(i + 1)}</td><td class="ltr">${T.fp(cd.open)}</td><td class="ltr">${T.fp(cd.high)}</td><td class="ltr">${T.fp(cd.low)}</td><td class="ltr ${cd.close >= cd.open ? 'up' : 'dn'}">${T.fp(cd.close)}</td></tr>`).join('');
  const tbl = card('مسیر معمول در گام‌های ۴‌تایی', 'flow', `<div class="tw"><table><thead><tr><th>کندل</th><th>بسته‌شدن</th><th>تغییر</th><th>بازه ۱۰–۹۰٪</th><th>P(بالاتر)</th></tr></thead><tbody>${rows}</tbody></table></div><details class="why"><summary>جدول کامل ${T.dg(n)} کندل (OHLC)</summary><div class="tw"><table><thead><tr><th>#</th><th>باز</th><th>سقف</th><th>کف</th><th>بسته</th></tr></thead><tbody>${full}</tbody></table></div></details>`, 'w2');
  return kp + `<div class="grid2">${h1}${h2}</div>` + tbl + card('نحوه ساخت پیش‌بینی', 'brain', '<p class="note" style="margin:0;line-height:2">شبیه‌سازی تاریخی فیلترشده: بازده‌های استاندارد شده با نوسان EWMA از خود ارز، بازگشت تدریجی نوسان به میانگین بلندمدت، مومنتوم کوچک‌شده و کشش به EMA21؛ سایه کندل‌ها هم از تاریخچه همین ارز نمونه‌برداری می‌شود. کندل‌های رنگی نمودار «مسیر معمول» (نزدیک‌ترین مسیر به میانه با زبری طبیعی) است؛ پیش‌بینی نقطه‌ای نیست و تضمینی ندارد.</p>');
};

function levelItems(x) {
  const { s, plan, pf } = x, ex = s.extras || {}, ind = s.indicators || {}, it = [], add = (p, n, k) => { if (p && isFinite(p)) it.push({ p: +p, n, k }); };
  ((s.levels || {}).zones || []).forEach(z => add(z.p, (z.kind === 'R' ? 'مقاومت' : 'حمایت') + (z.n > 1 ? ` (${T.dg(z.n)} برخورد)` : ''), z.kind === 'R' ? 'res' : 'sup'));
  const pv = ex.pivots || {}; [['p', 'پیوت'], ['r1', 'R1'], ['r2', 'R2'], ['r3', 'R3'], ['s1', 'S1'], ['s2', 'S2'], ['s3', 'S3']].forEach(([k, n]) => add(pv[k], n, k[0] === 'r' ? 'res' : k[0] === 's' ? 'sup' : 'piv'));
  const fb = ex.fib || {}; (fb.levels || []).forEach(l => add(l.p, `فیبو ${l.r}`, 'fib')); (fb.ext || []).forEach(l => add(l.p, `فیبو ${l.r}`, 'fib'));
  const vp = ex.vp || {}; add(vp.poc, 'POC (بیشترین حجم)', 'vp'); add(vp.vah, 'VAH', 'vp'); add(vp.val, 'VAL', 'vp');
  [['ema21', 'EMA 21'], ['ema50', 'EMA 50'], ['ema200', 'EMA 200'], ['vwap', 'VWAP']].forEach(([k, n]) => add(ind[k], n, 'ma'));
  const bb = (s.levels || {}).bb || {}; add(bb.upper, 'بولینگر بالا', 'ma'); add(bb.lower, 'بولینگر پایین', 'ma');
  const ic = ex.ichimoku || {}; add(ic.cloud_top, 'سقف ابر', 'ma'); add(ic.cloud_bot, 'کف ابر', 'ma'); add(ic.kijun, 'کیجون', 'ma');
  if (plan && plan.side !== 'WAIT') { add(plan.entry, 'ورود', 'plan'); add(plan.stop, 'حدضرر', 'sl'); add(plan.tp1, 'TP1', 'tp'); add(plan.tp2, 'TP2', 'tp'); add(plan.tp3, 'TP3', 'tp'); }
  if (pf && pf.bands && pf.bands.p50) { const n = pf.bands.p50.length - 1; add(pf.bands.p90[n], 'پیش‌بینی ۹۰٪', 'fc'); add(pf.bands.p50[n], 'پیش‌بینی میانه', 'fc'); add(pf.bands.p10[n], 'پیش‌بینی ۱۰٪', 'fc'); }
  return it.sort((a, b) => b.p - a.p);
}
const KCOL = { res: 'var(--dn)', sup: 'var(--up)', piv: 'var(--go)', fib: 'var(--b)', vp: 'var(--go)', ma: 'var(--a)', plan: 'var(--a)', sl: 'var(--dn)', tp: 'var(--up)', fc: 'var(--c)' };
TAB.lvl = x => {
  const { s, t } = x, px = t.price || s.entry, ex = s.extras || {}, items = levelItems(x), ab = items.filter(i => i.p > px).slice(-3), bl = items.filter(i => i.p <= px).slice(0, 3);
  const row = i => `<div class="lv" style="--kc:${KCOL[i.k]}"><i></i><span class="ln">${esc(i.n)}</span><b class="ltr">${T.fp(i.p)}</b><span class="mu sm ltr">${T.fpct((i.p / px - 1) * 100, 2)}</span></div>`;
  const near = card('نزدیک‌ترین سطوح', 'target', `<div class="lvs">${ab.map(row).join('')}<div class="lv now"><i></i><span class="ln">قیمت اکنون</span><b class="ltr">${T.fp(px)}</b><span></span></div>${bl.map(row).join('')}</div>`);
  const all = card(`نقشه کامل سطوح (${T.dg(items.length)})`, 'flow', `<div class="lvs">${items.map((i, k) => (k && items[k - 1].p > px && i.p <= px ? `<div class="lv now"><i></i><span class="ln">قیمت اکنون</span><b class="ltr">${T.fp(px)}</b><span></span></div>` : '') + row(i)).join('')}</div><div class="legend" style="margin-top:8px">${[['res', 'مقاومت'], ['sup', 'حمایت'], ['piv', 'پیوت'], ['fib', 'فیبوناچی'], ['vp', 'حجم'], ['ma', 'میانگین‌ها'], ['fc', 'پیش‌بینی']].map(([k, n]) => `<span><i style="background:${KCOL[k]}"></i>${n}</span>`).join('')}</div>`, 'w2');
  const vp = ex.vp && ex.vp.bins ? card('پروفایل حجم (۱۵۰ کندل)', 'chart', `<div class="svgw">${ch.vprofile(ex.vp, px)}</div>${kvs([['POC', T.fp(ex.vp.poc)], ['محدوده ارزش ۷۰٪', `${T.fp(ex.vp.val)} – ${T.fp(ex.vp.vah)}`], ['قیمت نسبت به محدوده', px > ex.vp.vah ? 'بالاتر (قیمت گران)' : px < ex.vp.val ? 'پایین‌تر (قیمت ارزان)' : 'داخل محدوده']])}`) : '';
  const fb = ex.fib && ex.fib.levels ? card('فیبوناچی آخرین موج', 'pulse', `${kvs([['جهت موج', ex.fib.dir === 'up' ? 'صعودی' : 'نزولی'], ['سقف / کف موج', `${T.fp(ex.fib.hi)} / ${T.fp(ex.fib.lo)}`], ['جایگاه قیمت در موج', pct(ex.fib.pos)], ['نزدیک‌ترین سطح', `${ex.fib.near.r} → ${T.fp(ex.fib.near.p)}`]])}<div class="chips" style="margin-top:8px">${ex.fib.levels.map(l => `<span class="chip ltr">${l.r} · ${T.fp(l.p)}</span>`).join('')}</div>`) : '';
  return near + `<div class="grid2">${vp}${fb}</div>` + all;
};

TAB.micro = x => {
  const m = ST.micro; if (!m || m.symbol !== ST.sel) return card('بازار خرد', 'pulse', '<div class="empty"><div class="skel" style="max-width:260px;margin:auto"></div>در حال دریافت دفتر سفارش و داده مشتقه…</div>');
  const dp = m.depth || {}, dv = m.derivs || {}, row = ST.matrix[ST.sel] || {};
  const depth = dp.ok ? card('عمق دفتر سفارش', 'chart', `<div class="svgw">${ch.depth(dp)}</div>${barSigned(dp.imb_1pct * 100)}<div class="row sb note"><span class="dn">فشار فروش</span><span>عدم‌تعادل ±۱٪: ${T.dg((dp.imb_1pct * 100).toFixed(0))}٪</span><span class="up">فشار خرید</span></div>
    ${kvs([['اسپرد', T.dg(dp.spread_pct) + '٪'], ['خرید / فروش در ±۱٪', `${T.usd(dp.bid_usd_1pct)} / ${T.usd(dp.ask_usd_1pct)}`], ['عدم‌تعادل ±۰٫۲۵٪', T.dg((dp.imb_025pct * 100).toFixed(0)) + '٪', dp.imb_025pct > 0 ? 'var(--up)' : 'var(--dn)'], ['منبع', dp.source]])}
    <div class="note" style="margin-top:8px">دیوار خرید: ${dp.bid_walls.map(w => `<span class="chip up ltr">${T.fp(w.p)} · ${T.usd(w.usd)}</span>`).join(' ')}<br>دیوار فروش: ${dp.ask_walls.map(w => `<span class="chip dn ltr">${T.fp(w.p)} · ${T.usd(w.usd)}</span>`).join(' ')}</div>`, 'w2') : card('عمق دفتر سفارش', 'chart', '<div class="empty">دفتر سفارش در دسترس نیست (منبع قطع یا ارز پشتیبانی نمی‌شود).</div>');
  let der;
  if (dv.ok) {
    const fr = dv.funding_pct, notes = [];
    if (fr > 0.03) notes.push('فاندینگ بالا: لانگ‌ها شلوغ‌اند؛ ریسک ریزش ناگهانی بیشتر است.'); else if (fr < -0.01) notes.push('فاندینگ منفی: شورت‌ها شلوغ‌اند؛ احتمال شورت‌اسکوییز.'); else notes.push('فاندینگ نزدیک خنثی است.');
    if (dv.ls_buy != null) notes.push(dv.ls_buy > .6 ? 'اکثر حساب‌ها لانگ‌اند (معمولاً علامت ازدحام).' : dv.ls_buy < .4 ? 'اکثر حساب‌ها شورت‌اند.' : 'نسبت لانگ/شورت متعادل است.');
    der = card('مشتقات (پرپچوال)', 'bolt', kvs([['نرخ فاندینگ', T.dg(fr) + '٪', fr > 0.03 ? 'var(--dn)' : fr < -0.01 ? 'var(--up)' : null], ['فاندینگ سالانه (تقریبی)', T.dg(dv.funding_apr) + '٪'], ['اوپن‌اینترست', T.usd(dv.oi_usd)], ['بیس (مارک/اندیکس)', T.dg(dv.basis_pct) + '٪'], ['حجم ۲۴س مشتقه', T.usd(dv.turnover_24h)], dv.ls_buy != null ? ['حساب‌های لانگ', pct(dv.ls_buy, 1), dv.ls_buy > .6 ? 'var(--dn)' : null] : ['', '']].filter(r => r[0])) + (dv.ls_hist ? `<div style="margin-top:8px">${ch.spark(dv.ls_hist, 300, 46, 'var(--a)')}</div><div class="note">روند نسبت لانگ ۲۴ ساعت اخیر</div>` : '') + `<ul class="note" style="margin:8px 0 0;padding-inline-start:18px">${notes.map(n => `<li>${n}</li>`).join('')}</ul>`);
  } else der = card('مشتقات (پرپچوال)', 'bolt', `<div class="empty">${dv.reason === 'no_perp' ? 'این ارز بازار پرپچوال در منبع داده ندارد.' : 'داده مشتقه در دسترس نیست.'}</div>`);
  const rel = row.corr != null ? card('نسبت به بیت‌کوین', 'target', kvs([['همبستگی ۱۰۰ کندل', T.dg(row.corr), Math.abs(row.corr) > .8 ? 'var(--go)' : null], ['بتا', T.dg(row.beta)], ['قدرت نسبی ۲۴ کندل', T.fpct(row.rs24), row.rs24 >= 0 ? 'var(--up)' : 'var(--dn)']]) + `<div class="note" style="margin-top:6px">${Math.abs(row.corr) > .8 ? 'حرکت این ارز تقریباً کپی بیت‌کوین است؛ تحلیل جداگانه ارزش کمتری دارد.' : 'حرکت نسبتاً مستقل از بیت‌کوین.'}</div>`) : '';
  return depth + `<div class="grid2">${der}${rel}</div><div class="row" style="justify-content:center"><button class="btn" data-act="micro-reload">به‌روزرسانی</button></div>`;
};

TAB.bt = x => {
  const b = ST.bt;
  const head = card('بک‌تست روی تاریخچه همین ارز', 'brain', `<p class="note" style="margin:0 0 10px;line-height:2">موتور سیگنال را گام‌به‌گام روی ~۳۵۰ کندل اخیر اجرا می‌کند؛ در هر گام فقط داده تا همان لحظه را می‌بیند، ورود با باز شدن کندل بعد، خروج پله‌ای با همان قوانین صرافی کاغذی و هزینه کارمزد+لغزش.</p><button class="btn pri" data-act="bt-run" ${ST.btBusy ? 'disabled' : ''}>${ST.btBusy ? 'در حال اجرا… (چند ثانیه)' : `اجرای بک‌تست ${esc(x.base)} · ${ST.tf}`}</button>`);
  if (ST.btBusy) return head + card('در حال محاسبه', 'scan', '<div class="empty"><div class="skel" style="max-width:260px;margin:auto"></div></div>');
  if (!b) return head;
  if (b.error) return head + card('خطا', 'shield', `<div class="empty">${esc(b.error)}</div>`);
  if (!b.n) return head + card('نتیجه', 'chart', `<div class="empty">${esc(b.note || 'سیگنالی نبود')}</div>`);
  const K = (l, v, col) => `<div class="kpi"><b style="color:${col || 'var(--tx)'}">${v}</b><span>${l}</span></div>`, sigc = b.significant ? 'var(--up)' : 'var(--go)';
  const sd = ['LONG', 'SHORT'].map(k => `<tr><td>${T.badge(k)}</td><td>${T.dg(b.by_side[k].n)}</td><td>${T.dg(b.by_side[k].win)}٪</td><td style="color:${b.by_side[k].avg_r >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(b.by_side[k].avg_r)}R</td></tr>`).join('');
  const bs = Object.entries(b.by_score).map(([k, v]) => `<tr><td>${T.dg(k)}</td><td>${T.dg(v.n)}</td><td>${T.dg(v.win)}٪</td><td style="color:${v.avg_r >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(v.avg_r)}R</td></tr>`).join('');
  const tr = b.trades.slice().reverse().map(z => `<tr><td>${new Date(z.t).toLocaleDateString('fa-IR')}</td><td>${T.badge(z.side)}</td><td>${T.dg(sgn(z.score))}</td><td style="color:${z.r >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(z.r.toFixed(2))}R</td><td class="mu">${esc(z.out)}</td><td>${T.dg(z.bars)}</td></tr>`).join('');
  return head + card(`نتیجه (${T.dg(b.n)} معامله روی ${T.dg(b.bars_tested)} کندل)`, 'chart', `<div class="kpis">${K('نرخ برد', T.dg(b.win_rate) + '٪')}${K('میانگین R', T.dg(b.avg_r) + 'R', b.avg_r >= 0 ? 'var(--up)' : 'var(--dn)')}${K('جمع R (خالص)', T.dg(b.total_r) + 'R', b.total_r >= 0 ? 'var(--up)' : 'var(--dn)')}${K('ضریب سود', T.dg(b.pf))}${K('افت سرمایه', T.dg(b.max_dd_r) + 'R', 'var(--dn)')}${K('بدترین سری باخت', T.dg(b.worst_streak))}</div>
    <div class="svgw" style="margin-top:12px">${ch.equityR(b.equity)}</div>
    <div class="row" style="margin-top:8px"><span class="chip" style="color:${sigc};border-color:${sigc}">${b.significant ? 'از نظر آماری معنادار' : 'از نظر آماری معنادار نیست'} (t = ${T.dg(b.t_stat)})</span><span class="chip">نگهداری میانگین ${T.dg(b.avg_bars)} کندل</span><span class="chip">خرید و نگهداری: ${T.fpct(b.buy_hold_pct, 1)}</span></div>
    <div class="note" style="margin-top:8px">تفسیر: اگر «معنادار نیست» می‌بینید، سیگنال‌های گذشته روی این ارز/تایم‌فریم لبه قابل‌اتکایی نشان نداده‌اند. نمونه کوچک است و گذشته ضمانت آینده نیست؛ از این نتیجه برای رد کردن ستاپ‌های ضعیف استفاده کنید، نه برای اطمینان کورکورانه.</div>`, 'w2')
    + `<div class="grid2">${card('بر اساس سمت', 'target', `<div class="tw"><table><thead><tr><th>سمت</th><th>تعداد</th><th>برد</th><th>میانگین</th></tr></thead><tbody>${sd}</tbody></table></div>`)}${card('بر اساس قدرت امتیاز', 'pulse', `<div class="tw"><table><thead><tr><th>امتیاز</th><th>تعداد</th><th>برد</th><th>میانگین</th></tr></thead><tbody>${bs}</tbody></table></div><div class="note">اگر امتیازهای بالاتر نتیجه بهتری نمی‌دهند، امتیاز روی این ارز کالیبره نیست.</div>`)}</div>`
    + card('آخرین معاملات', 'chart', `<div class="tw"><table><thead><tr><th>تاریخ</th><th>سمت</th><th>امتیاز</th><th>نتیجه</th><th>خروج</th><th>کندل</th></tr></thead><tbody>${tr}</tbody></table></div>`);
};

function calcOut() {
  const p = ST._plan, cc = ST.calc, st = ST.status || {}; if (!p) return '<div class="empty">سیگنال فعالی برای محاسبه نیست.</div>';
  const cap = +cc.cap || (ST.acct ? ST.acct.equity : st.start_capital || 10000), rk = Math.max(.05, +cc.risk || 1), lev = Math.max(1, Math.min(st.max_leverage || 50, +cc.lev || 10)), side = p.side;
  const dist = Math.abs(p.entry - p.stop), riskAmt = cap * rk / 100, qty = riskAmt / dist, notional = qty * p.entry, margin = notional / lev, d = side === 'LONG' ? 1 : -1;
  const liq = p.entry * (1 - d * (1 / lev - .005)), liqBad = side === 'LONG' ? liq >= p.stop : liq <= p.stop, fee = notional * 2 * ((st.fee || .0004) + (st.slip || .0002));
  const part = [.4, .35, .25], tps = [p.tp1, p.tp2, p.tp3], gain = k => part.slice(0, k + 1).reduce((a, f, i) => a + f * qty * Math.abs(tps[i] - p.entry), 0);
  const row = (n, v) => `<tr><td>${n}</td><td style="color:${v >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.usd(v - (n === 'حدضرر' ? 0 : 0))}</td><td class="mu">${T.dg((v / cap * 100).toFixed(2))}٪</td></tr>`;
  const kel = ST.deep && ST.deep.forecast && ST.deep.forecast.edge ? ST.deep.forecast.edge.kelly : null;
  return `${kvs([['حجم پوزیشن', T.dg(qty < 1 ? qty.toPrecision(4) : qty.toFixed(2))], ['ارزش اسمی', T.usd(notional)], ['مارجین لازم', T.usd(margin), margin > cap ? 'var(--dn)' : null], ['قیمت لیکوئید (تقریبی)', T.fp(liq), liqBad ? 'var(--dn)' : null], ['ریسک در حدضرر', T.usd(riskAmt)], ['کارمزد+لغزش رفت‌وبرگشت', T.usd(fee)]])}${liqBad ? '<div class="note dn" style="margin-top:6px">⚠ قیمت لیکوئید قبل از حدضرر است؛ اهرم را کم کنید.</div>' : ''}
  <div class="tw" style="margin-top:10px"><table><thead><tr><th>سناریو</th><th>سود/زیان</th><th>٪ سرمایه</th></tr></thead><tbody>${row('حدضرر', -riskAmt - fee)}${row('TP1 سپس سر‌به‌سر', gain(0) - fee)}${row('TP1 + TP2', gain(1) - fee)}${row('هر سه هدف', gain(2) - fee)}</tbody></table></div>
  ${kel != null ? `<div class="note" style="margin-top:8px">کسر کلی شبیه‌سازی: ${T.dg((kel * 100).toFixed(0))}٪ — نیمه‌کلی ≈ ${T.dg((kel * 50).toFixed(1))}٪ سرمایه ریسک (فقط راهنما؛ برای ریسک بالای ۲٪ توصیه نمی‌شود).</div>` : ''}`;
}
T.updCalc = () => { const o = $('#calc-out'); if (o) o.innerHTML = calcOut(); };
TAB.risk = x => {
  ST._plan = x.plan; const cc = ST.calc, cap = cc.cap || (ST.acct ? Math.round(ST.acct.equity) : (ST.status || {}).start_capital || 10000);
  const f = (l, k, v, mn, st) => `<div class="fld"><label>${l}</label><input type="number" inputmode="decimal" data-calc="${k}" value="${v}" min="${mn}" step="${st}" style="width:110px"></div>`;
  return card('ماشین‌حساب ریسک و حجم', 'shield', (x.plan ? `<div class="row" style="margin-bottom:6px">${T.badge(x.plan.side)}<span class="chip ltr">ورود ${T.fp(x.plan.entry)}</span><span class="chip dn ltr">SL ${T.fp(x.plan.stop)}</span><span class="chip up ltr">TP1 ${T.fp(x.plan.tp1)}</span></div>` : '') + f('سرمایه (دلار)', 'cap', cap, 1, 100) + f('ریسک هر معامله (٪)', 'risk', cc.risk, .05, .25) + f('اهرم', 'lev', cc.lev, 1, 1) + `<div id="calc-out" style="margin-top:10px">${calcOut()}</div>`);
};

TAB.ai = x => {
  const a = ST.ai;
  if (!a) return card('هوش مرکزی Gemini', 'brain', `<button class="btn pri" data-act="ai" ${ST.aiBusy ? 'disabled' : ''}>${ST.aiBusy ? 'در حال استدلال مرکزی…' : 'اجرای هوش مرکزی Gemini'}</button>
    <div class="note" style="margin-top:10px;line-height:1.9">تنها موتور AI: <b>Gemini</b>. کلید از <code>secret/gemini_api_key.txt</code> خوانده می‌شود.<br>
    تمام لایه‌ها (تکنیکال، درجه، پیش‌بینی، Edge، چک‌لیست، میکرو، قدرت نسبی، جلسه) یکپارچه مقایسه و استدلال می‌شوند.</div>`, 'w2');
  const src = a.source === 'gemini' ? 'Gemini' : a.source === 'local-unify' ? 'یکپارچه‌ساز محلی' : (a.source || '—');
  const conf = Math.round((a.confidence || 0) * 100);
  return card('هوش مرکزی Gemini', 'brain', `
    <div class="deep-hero">
      <div class="deep-badge" style="border-color:${T.col(a.side)};color:${T.col(a.side)}">${T.SIDE_FA[a.side] || a.side || '—'}</div>
      <div class="deep-score"><b>${T.dg(conf)}٪</b><span>اطمینان</span></div>
      <div class="deep-score"><span class="chip">${esc(src)}</span><span>منبع</span></div>
      ${a.edge != null ? `<div class="deep-score"><b>${T.dg(a.edge)}</b><span>Edge</span></div>` : ''}
    </div>
    <p style="margin-top:12px;line-height:1.9">${esc(a.summary || '')}</p>
    <ul style="line-height:1.85">${(a.bullets || []).map(b => `<li>${esc(b)}</li>`).join('')}</ul>
    ${a.action ? `<div class="vd ok"><b>اقدام پیشنهادی</b><div>${esc(a.action)}</div></div>` : ''}
    <div class="vd ${a.ok === false ? 'bad' : 'info'}"><b>ریسک / یادداشت</b><div>${esc(a.risk_note || '')}</div></div>
    <button class="btn" data-act="ai" style="margin-top:8px" ${ST.aiBusy ? 'disabled' : ''}>تازه‌سازی استدلال</button>
  `, 'w2');
};


/* ═══════════ NEW COIN TABS (v2.2): patterns · checklist · scenarios · flow · compare · alerts ═══════════ */
const patFor = () => (ST.pat && ST.pat.symbol === ST.sel && ST.pat.tf === ST.tf ? ST.pat : null);
const BIASFA = { 1: ['صعودی', 'LONG'], '-1': ['نزولی', 'SHORT'], 0: ['خنثی', 'WAIT'] };
const agoTxt = n => n === 0 ? 'آخرین کندل' : `${T.dg(n)} کندل پیش`;
function statTable(st) {
  if (!st || !st.h) return '';
  const rows = ['3', '8', '16', '32'].filter(h => st.h[h]).map(h => { const z = st.h[h]; return `<tr><td>${T.dg(h)} کندل</td><td>${T.dg(z.n)}</td><td>${T.dg(z.win)}٪</td><td style="color:${z.mean >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(z.mean)}٪</td><td style="color:${z.excess >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(z.excess)}٪</td><td class="${Math.abs(z.t) >= 1.65 ? 'go' : 'mu'}">${T.dg(z.t)}</td></tr>`; }).join('');
  return `<div class="tw"><table><thead><tr><th>بعد از</th><th>نمونه</th><th>برد</th><th>میانگین</th><th>برتری</th><th>t</th></tr></thead><tbody>${rows}</tbody></table></div>${st.mfe16 != null ? `<div class="note">در ۱۶ کندل بعدی: میانگین بیشترین سود ممکن ${T.fpct(st.mfe16, 2)} · میانگین بیشترین ضرر ممکن ${T.fpct(st.mae16, 2)}</div>` : ''}`;
}
TAB.pat = x => {
  const P = patFor();
  if (!P) return card('الگوها', 'brain', '<div class="empty"><div class="skel" style="max-width:260px;margin:auto"></div>در حال تشخیص الگوها…<br><button class="btn" data-act="pat-reload" style="margin-top:10px">تلاش دوباره</button></div>');
  const sum = P.summary, rec = P.recent, last10 = rec.filter(r => r.ago <= 9), nb = last10.filter(r => r.bias > 0).length, ns = last10.filter(r => r.bias < 0).length;
  const lbl = sum.score >= 35 ? ['الگوهای اخیر به نفع صعود هستند', 'var(--up)'] : sum.score <= -35 ? ['الگوهای اخیر به نفع نزول هستند', 'var(--dn)'] : ['الگوهای اخیر خنثی یا متناقض‌اند', 'var(--go)'];
  const top = card('جمع‌بندی الگوها', 'brain', `<div class="row sb"><b style="color:${lbl[1]}">${lbl[0]}</b><span class="chip">امتیاز ${T.dg(sgn(sum.score))}</span></div><div style="margin:8px 0">${barSigned(sum.score)}</div>
    <div class="row"><span class="chip up">${T.dg(nb)} الگوی صعودی در ۱۰ کندل اخیر</span><span class="chip dn">${T.dg(ns)} نزولی</span>${(P.structs || []).slice(0, 2).map(z => `<span class="chip ${z.bias > 0 ? 'up' : z.bias < 0 ? 'dn' : ''}">${esc(z.fa)}</span>`).join('')}</div>
    <div class="note" style="margin-top:8px">«برتری» یعنی میانگین بازده بعد از الگو منهای بازده یک کندل تصادفی همین تایم‌فریم. t بالای ۱٫۶۵ یعنی اختلاف احتمالاً تصادفی نیست. نمونه‌ها از ${T.dg((P.sample || {}).coins || 0)} ارز جمع شده‌اند و تکراری‌های چسبیده حذف شده‌اند.</div><button class="btn" data-act="showpat" style="margin-top:8px">نمایش روی نمودار</button>`);
  const rows = rec.slice(0, 14).map(r => { const bf = BIASFA[r.bias], v = r.verdict || {}, h8 = r.stat && r.stat.h && r.stat.h['8'];
    return `<details class="prow ${r.bias > 0 ? 'bull' : r.bias < 0 ? 'bear' : 'neu'}" ${r.ago <= 1 ? 'open' : ''}><summary><b>${esc(r.fa)}</b><span class="badge ${bf[1]}">${bf[0]}</span><span class="mu sm">${agoTxt(r.ago)}</span><span class="str" data-tip="قدرت الگو (اندازه، روند قبلی، حجم، محل)"><i style="width:${Math.round(r.strength * 100)}%"></i></span>${r.at_level ? '<span class="chip go">روی سطح</span>' : ''}<span class="sp"></span>${h8 ? `<span class="sm ${v.level === 'good' ? 'up' : v.level === 'bad' ? 'dn' : 'mu'}">${T.dg(h8.win)}٪ برد · ${T.dg(h8.n)} نمونه</span>` : ''}</summary>
    <div class="pb"><div><b>معنی:</b> ${esc(r.meaning)}</div><div><b>انتظار کلاسیک:</b> ${esc(r.expect)}</div><div><b>تایید / ابطال:</b> ${esc(r.confirm)}</div><div class="vd ${v.level || 'none'}">${esc(v.text || '')}</div>${statTable(r.stat)}${r.own && r.own.h && r.own.h['8'] ? `<div class="note">فقط روی همین ارز: ${T.dg(r.own.h['8'].n)} نمونه، برد ${T.dg(r.own.h['8'].win)}٪ بعد از ۸ کندل ${r.own.h['8'].n < 8 ? '(نمونه خیلی کم)' : ''}</div>` : ''}</div></details>`; }).join('');
  const recent = card(`الگوهای کندلی اخیر (${T.dg(rec.length)})`, 'chart', rows || '<div class="empty">در ۶۰ کندل اخیر الگوی مشخصی دیده نشد.</div>', 'w2');
  const st = (P.structs || []).map(z => { const px = x.t.price || x.s.entry, d = v => v ? `${T.fp(v)} <span class="mu">(${T.fpct((v / px - 1) * 100, 1)})</span>` : '—', bf = BIASFA[z.bias];
    return `<details class="prow ${z.bias > 0 ? 'bull' : z.bias < 0 ? 'bear' : 'neu'}" open><summary><b>${esc(z.fa)}</b><span class="badge ${bf[1]}">${bf[0]}</span><span class="str"><i style="width:${Math.round(z.conf * 100)}%"></i></span><span class="mu sm">اطمینان ${T.dg(Math.round(z.conf * 100))}٪</span></summary><div class="pb"><div>${esc(z.meaning)}</div><div><b>انتظار:</b> ${esc(z.expect)}</div>${kvs([['شکست رو به بالا', d(z.break_up)], ['شکست رو به پایین', d(z.break_dn)], ['هدف اندازه‌گیری‌شده', d(z.target)]])}<div class="note">${esc(z.note || '')} · الگوهای ساختاری ذهنی‌تر از الگوهای کندلی‌اند؛ فقط بعد از شکست با کندل بسته‌شده و حجم معتبر می‌شوند.</div></div></details>`; }).join('');
  const structs = card('الگوهای ساختاری (خطوط روند)', 'flow', st || '<div class="empty">الگوی ساختاری معتبری در ۱۱۰ کندل اخیر دیده نشد.</div>');
  const lead = (P.top || []).map(z => `<tr><td>${esc(z.fa)}</td><td>${z.bias > 0 ? '<span class="up">▲</span>' : z.bias < 0 ? '<span class="dn">▼</span>' : '●'}</td><td>${T.dg(z.n)}</td><td>${T.dg(z.win)}٪</td><td style="color:${z.mean >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(z.mean)}٪</td><td class="${Math.abs(z.t) >= 1.65 ? 'go' : 'mu'}">${T.dg(z.t)}</td></tr>`).join('');
  const board = card(`کدام الگوها در تایم‌فریم ${ST.tf} واقعاً کار کرده‌اند؟`, 'target', `<div class="tw"><table><thead><tr><th>الگو</th><th></th><th>نمونه</th><th>برد ۸ک</th><th>میانگین</th><th>t</th></tr></thead><tbody>${lead || '<tr><td colspan="6" class="empty">پس از اسکن کامل نمایش داده می‌شود</td></tr>'}</tbody></table></div>${P.base ? `<div class="note">نرخ پایه: ${T.dg(Math.round(P.base.up['r8'] * 100))}٪ از کندل‌های تصادفی بعد از ۸ کندل بالاتر بسته‌اند (میانگین ${T.dg((P.base.mean['r8'] * 100).toFixed(2))}٪). الگویی که از این نرخ بهتر نباشد، لبه ندارد.</div>` : ''}`, 'w2');
  return top + recent + `<div class="grid2">${structs}</div>` + board;
};

TAB.check = x => {
  const { s, d, plan, pf, ind } = x, P = patFor(), M = ST.micro && ST.micro.symbol === ST.sel ? ST.micro : null, ex = s.extras || {};
  if (!plan) return card('چک‌لیست ورود', 'shield', '<div class="empty">سیگنال فعالی نیست؛ چک‌لیست برای ستاپ خرید/فروش معنا دارد.<br>وقتی اجماع تایم‌فریم‌ها به آستانه برسد اینجا کامل می‌شود.</div>');
  const dir = plan.side === 'LONG' ? 1 : -1, px = x.t.price || plan.entry, risk = Math.abs(plan.entry - plan.stop) || 1e-9, all = d && d.all_tf, C = [];
  const add = (label, st, detail, w = 1, crit = false) => C.push({ label, st, detail, w, crit });
  const bigs = ['4h', '1d'].filter(t => all && all[t]); const opp = bigs.filter(t => all[t].score * dir <= -T.TH), same = bigs.filter(t => all[t].score * dir >= T.TH);
  add('تایم‌فریم‌های بزرگ‌تر', opp.length ? 'fail' : (bigs.length && same.length === bigs.length ? 'ok' : 'warn'), opp.length ? 'مخالف: ' + opp.join('، ') : same.length ? 'هم‌جهت: ' + same.join('، ') : 'خنثی', 2, true);
  const cons = (d ? d.consensus_score : s.score) * dir; add('اجماع چندتایم‌فریم', cons >= 55 ? 'ok' : cons >= T.TH ? 'warn' : 'fail', `${T.dg(sgn(cons))} (آستانه ${T.dg(T.TH)})`, 2);
  add('هم‌سویی اندیکاتورها', (plan.agree || 0) >= .75 ? 'ok' : (plan.agree || 0) >= .6 ? 'warn' : 'fail', `${T.dg(Math.round((plan.agree || 0) * 100))}٪`);
  const rsiBad = dir > 0 ? ind.rsi > 75 : ind.rsi < 25, macdOk = ind.macd_hist * dir > 0; add('مومنتوم (MACD / RSI)', rsiBad ? 'fail' : macdOk ? 'ok' : 'warn', `MACD ${macdOk ? 'هم‌جهت' : 'مخالف'} · RSI ${T.dg(ind.rsi)}${rsiBad ? ' (ورود دیرهنگام)' : ''}`);
  add('قدرت روند (ADX)', ind.adx >= 22 ? 'ok' : ind.adx >= 15 ? 'warn' : 'fail', `ADX ${T.dg(ind.adx)} · رژیم ${T.REGIME_FA[plan.regime] || ''}`);
  const cmfOk = ind.cmf * dir > 0; add('حجم و پول هوشمند', ind.vol_ratio >= 1 && cmfOk ? 'ok' : ind.vol_ratio >= .7 ? 'warn' : 'fail', `حجم نسبی ${T.dg(ind.vol_ratio)}× · CMF ${cmfOk ? 'هم‌جهت' : 'مخالف'}`);
  const zones = ((s.levels || {}).zones || []).filter(z => dir > 0 ? z.p > px : z.p < px).sort((a, b) => dir > 0 ? a.p - b.p : b.p - a.p), z0 = zones[0];
  if (z0) { const room = Math.abs(z0.p - px) / risk; add('فضای حرکت تا سطح مقابل', room >= 1.5 ? 'ok' : room >= .8 ? 'warn' : 'fail', `${z0.kind === 'R' ? 'مقاومت' : 'حمایت'} ${T.fp(z0.p)} در ${T.dg(room.toFixed(1))}R`, 2, true); } else add('فضای حرکت تا سطح مقابل', 'ok', 'سطح نزدیکی دیده نمی‌شود');
  add('نسبت ریسک به ریوارد', plan.risk_reward >= 2 ? 'ok' : plan.risk_reward >= 1.5 ? 'warn' : 'fail', `R:R ${T.dg(plan.risk_reward)}`, 1, plan.risk_reward < 1.2);
  const e = pf && pf.edge; add('پیش‌بینی ۳۲ کندل', pf && pf.alignment === 'aligned' && e && e.p_tp1 >= .45 ? 'ok' : pf && pf.alignment === 'divergent' ? 'fail' : 'warn', pf ? `${pf.alignment === 'aligned' ? 'هم‌جهت' : pf.alignment === 'divergent' ? 'مخالف' : 'خنثی'}${e ? ` · احتمال TP1 ${T.dg(Math.round(e.p_tp1 * 100))}٪ · امید ${T.dg(e.ev_r.toFixed(2))}R` : ''}` : '—', 2);
  if (P) { const near = P.recent.filter(r => r.ago <= 2 && r.bias !== 0), al = near.filter(r => r.bias * dir > 0), op = near.filter(r => r.bias * dir < 0); add('الگوهای کندلی/ساختاری', op.length && !al.length ? 'fail' : al.length ? 'ok' : 'warn', al.length ? 'تایید: ' + al.slice(0, 2).map(r => r.fa).join('، ') : op.length ? 'مخالف: ' + op.slice(0, 2).map(r => r.fa).join('، ') : 'الگوی مؤثری نیست'); } else add('الگوهای کندلی/ساختاری', 'na', 'در حال بارگذاری');
  const f = ex.flow; if (f) { const bs = f.buy_share, okf = dir > 0 ? bs > .52 : bs < .48, dv = f.div && ((f.div === 'bull' ? 1 : -1) * dir < 0); add('جریان سفارش (CVD)', dv ? 'fail' : okf ? 'ok' : 'warn', `سهم خرید ${T.dg(Math.round(bs * 100))}٪${f.div ? ' · واگرایی ' + (f.div === 'bull' ? 'صعودی' : 'نزولی') : ''}`); }
  if (M && M.depth && M.depth.ok) { const imb = M.depth.imb_1pct * dir, fr = M.derivs && M.derivs.ok ? M.derivs.funding_pct : null, crowded = fr != null && fr * dir > .04; add('بازار خرد (دفتر سفارش / فاندینگ)', crowded ? 'fail' : imb > .1 ? 'ok' : 'warn', `عدم‌تعادل ${T.dg((imb * 100).toFixed(0))}٪${fr != null ? ` · فاندینگ ${T.dg(fr)}٪` : ''}`); } else add('بازار خرد (دفتر سفارش / فاندینگ)', 'na', 'تب «بازار خرد» را باز کنید');
  const smx = ex.smc; if (smx && smx.range) { const z = smx.range.zone, goodZ = (dir > 0 && z === 'discount') || (dir < 0 && z === 'premium'), badZ = (dir > 0 && z === 'premium') || (dir < 0 && z === 'discount'), trOk = (smx.structure.trend === 'bull' && dir > 0) || (smx.structure.trend === 'bear' && dir < 0), trBad = (smx.structure.trend === 'bull' && dir < 0) || (smx.structure.trend === 'bear' && dir > 0);
    add('ساختار بازار و موقعیت مکانی', trBad && badZ ? 'fail' : (trOk && goodZ) ? 'ok' : (trBad || badZ) ? 'warn' : 'ok', `${smx.structure.label} · ${{ premium: 'ناحیه گران', discount: 'ناحیه ارزان', equilibrium: 'تعادل' }[z]}${smx.event ? ' · ' + smx.event.kind : ''}`, 2); }
  const oc2 = ex.osc; if (oc2 && oc2.osc) { const sc = oc2.all_score * dir; add('رای اسیلاتورها و میانگین‌ها', sc >= 25 ? 'ok' : sc > -15 ? 'warn' : 'fail', `${oc2.all_label} (${T.dg(sgn(oc2.all_score))})`); }
  add('نوسان قابل‌معامله', ind.atr_pct >= .25 && ind.atr_pct <= 5 ? 'ok' : 'warn', `ATR ${T.dg(ind.atr_pct)}٪`);
  const btc = ST.matrix.BTCUSDT; if (btc && ST.sel !== 'BTCUSDT') { const bc = T.cons(btc) * dir; add('هم‌جهتی با بیت‌کوین', bc >= -15 ? 'ok' : bc > -T.TH ? 'warn' : 'fail', `اجماع BTC ${T.dg(sgn(T.cons(btc)))}`); }
  add('هشدارهای سیستم', !(s.warnings || []).length ? 'ok' : s.warnings.length < 3 ? 'warn' : 'fail', (s.warnings || []).length ? s.warnings.join(' · ') : 'هشداری نیست');
  const act = C.filter(c => c.st !== 'na'), sc = act.reduce((a, c) => a + c.w * ({ ok: 1, warn: .5, fail: 0 })[c.st], 0) / (act.reduce((a, c) => a + c.w, 0) || 1) * 100, crit = C.filter(c => c.crit && c.st === 'fail');
  const verdict = crit.length ? ['ورود توصیه نمی‌شود: ' + crit.map(c => c.label).join('، '), 'var(--dn)'] : sc >= 78 ? ['آماده ورود؛ شرایط هم‌راستاست', 'var(--up)'] : sc >= 60 ? ['قابل‌قبول با احتیاط؛ حجم را کم کنید', 'var(--go)'] : ['صبر کنید؛ تایید کافی نیست', 'var(--dn)'];
  const icon = { ok: '✔', warn: '!', fail: '✕', na: '–' };
  return card(`چک‌لیست ورود ${T.SIDE_FA[plan.side]}`, 'shield', `<div class="row sb"><b style="color:${verdict[1]}">${esc(verdict[0])}</b><span class="chip">${T.dg(Math.round(sc))}٪</span></div><div class="bar" style="margin:8px 0 10px"><i style="right:0;width:${Math.round(sc)}%;background:${verdict[1]}"></i></div>${C.map(c => `<div class="ck"><b class="s ${c.st}">${icon[c.st]}</b><b>${esc(c.label)}</b><span class="d">${esc(c.detail)}</span></div>`).join('')}<div class="note" style="margin-top:8px">چک‌لیست تصمیم‌یار است، نه پیش‌بینی. موارد قرمزِ حیاتی (تایم‌فریم بزرگ، فضای حرکت، R:R) باید قبل از ورود رفع شوند.</div>`);
};

TAB.scen = x => {
  const { s, pf, t } = x, px = t.price || s.entry; if (!pf || !pf.bands || !pf.bands.p50) return card('سناریوها', 'target', '<div class="empty">داده کافی نیست.</div>');
  const zs = ((s.levels || {}).zones || []), up = zs.filter(z => z.p > px).sort((a, b) => a.p - b.p), dn = zs.filter(z => z.p < px).sort((a, b) => b.p - a.p), n = pf.bands.p50.length - 1, atr = (s.indicators || {}).atr || px * .01;
  const trigU = up[0] ? up[0].p : pf.range.hi, trigD = dn[0] ? dn[0].p : pf.range.lo;
  const tU = [up[1] && up[1].p, up[2] && up[2].p, pf.bands.p90[n]].filter(v => v && v > trigU).filter((v, i, a) => a.indexOf(v) === i).sort((a, b) => a - b).slice(0, 3);
  const tD = [dn[1] && dn[1].p, dn[2] && dn[2].p, pf.bands.p10[n]].filter(v => v && v < trigD).filter((v, i, a) => a.indexOf(v) === i).sort((a, b) => b - a).slice(0, 3);
  const pU = pf.p_up10 || 0, pD = pf.p_dn10 || 0, pM = Math.max(0, 1 - pU - pD), dist = v => T.fpct((v / px - 1) * 100, 1), hrz = hrs(pf.n || 32, ST.tf);
  const sc = (cls, title, p, col, trig, trigTxt, tg, inv, act) => `<div class="scn ${cls}"><div class="row sb"><b style="color:${col}">${title}</b><span class="chip">${T.dg(Math.round(p * 100))}٪ احتمال</span></div><div class="pbar" style="margin:6px 0"><i style="width:${Math.round(p * 100)}%;background:${col}"></i></div>
    ${trig ? `<div class="note"><b>محرک:</b> ${trigTxt} <b class="ltr">${T.fp(trig)}</b> (${dist(trig)})</div>` : ''}${tg && tg.length ? `<div class="note"><b>اهداف:</b> ${tg.map(v => `<span class="chip ltr">${T.fp(v)} · ${dist(v)}</span>`).join(' ')}</div>` : ''}${inv ? `<div class="note"><b>ابطال:</b> ${inv}</div>` : ''}<div class="note" style="margin-top:4px">${act}</div></div>`;
  return card(`سناریوهای ${T.dg(pf.n || 32)} کندل آینده (≈ ${hrz})`, 'target', `<div class="note" style="margin-bottom:8px">احتمال‌ها از ${T.dg(600)} مسیر شبیه‌سازی می‌آیند: «صعود» یعنی پایان بازه بیش از ۱٪ بالاتر، «نزول» یعنی بیش از ۱٪ پایین‌تر.</div>`
    + sc('up', 'سناریوی صعودی', pU, 'var(--up)', trigU, 'بسته‌شدن کندل بالای', tU, dn[0] ? `بسته‌شدن زیر ${T.fp(dn[0].p)}` : `بازگشت زیر ${T.fp(px - atr)}`, 'ورود خرید فقط بعد از شکست با حجم؛ حدضرر زیر آخرین کف.')
    + sc('', 'سناریوی رنج', pM, 'var(--go)', null, '', [pf.range.lo, pf.range.hi].map(v => +v), '', `بین ${T.fp(pf.range.lo)} و ${T.fp(pf.range.hi)} نوسان می‌کند؛ معامله‌های کوتاه نزدیک لبه‌ها یا انتظار.`)
    + sc('dn', 'سناریوی نزولی', pD, 'var(--dn)', trigD, 'بسته‌شدن کندل زیر', tD, up[0] ? `بسته‌شدن بالای ${T.fp(up[0].p)}` : `بازگشت بالای ${T.fp(px + atr)}`, 'ورود فروش فقط بعد از شکست حمایت؛ حدضرر بالای آخرین سقف.'));
};

TAB.flow = x => {
  const f = (x.s.extras || {}).flow, P = patFor(); if (!f) return card('جریان سفارش', 'pulse', '<div class="empty">داده کافی نیست.</div>');
  const dv = f.div === 'bull' ? ['واگرایی صعودی: قیمت کف پایین‌تر زد ولی جریان خرید بهتر شد', 'var(--up)'] : f.div === 'bear' ? ['واگرایی نزولی: قیمت سقف بالاتر زد ولی جریان خرید ضعیف‌تر شد', 'var(--dn)'] : ['واگرایی مهمی بین قیمت و جریان نیست', 'var(--mu)'];
  const fl = card('دلتای حجم تجمعی (CVD) در برابر قیمت', 'pulse', `<div class="svgw">${ch.cvd(f)}</div>${kvs([['سهم حجم خرید (۲۰ کندل)', pct(f.buy_share), f.buy_share > .55 ? 'var(--up)' : f.buy_share < .45 ? 'var(--dn)' : null], ['شیب CVD', T.dg(f.cvd_slope), f.cvd_slope > 0 ? 'var(--up)' : 'var(--dn)'], ['حجم نسبی (آخرین / ۵ تایی)', `${T.dg(f.rel_vol)}× / ${T.dg(f.rel_vol5)}×`]])}<div class="vd info" style="border-color:${dv[1]};margin-top:8px">${dv[0]}</div><div class="note">CVD تقریبی است: حجم هر کندل بر اساس محل بسته‌شدن آن بین سقف و کف بین خریدار و فروشنده تقسیم می‌شود (داده تیک واقعی در دسترس نیست).</div>`, 'w2');
  const sp = card('جهش‌های حجم اخیر', 'bolt', f.spikes.length ? `<div class="list">${f.spikes.map(z => `<div class="li"><span class="${z.up ? 'up' : 'dn'}">${z.up ? '▲' : '▼'}</span><span>${agoTxt(z.ago)}</span><span class="sp"></span><b>${T.dg(z.ratio)}× میانگین</b></div>`).join('')}</div>` : '<div class="empty">جهش حجم غیرعادی نبوده.</div>');
  const hrsC = P && P.hours && P.hours.range ? (() => { const off = Math.round(-new Date().getTimezoneOffset() / 60), r = P.hours.range.map((_, i, a) => a[((i - off) % 24 + 24) % 24]), top = r.map((v, i) => [v, i]).sort((a, b) => b[0] - a[0]).slice(0, 3).map(z => z[1]), lo = r.map((v, i) => [v, i]).sort((a, b) => a[0] - b[0]).slice(0, 3).map(z => z[1]);
    return card('ساعت‌های پرنوسان (به وقت شما)', 'chart', `<div class="svgw">${ch.hours(P.hours)}</div><div class="note">پرنوسان‌ترین: ${top.map(h => `<b>${T.dg(h)}:۰۰</b>`).join('، ')} · آرام‌ترین: ${lo.map(h => T.dg(h) + ':۰۰').join('، ')} (میانگین ${T.dg(P.hours.n)} کندل ۱ساعته همه ارزها)</div>`); })() : '';
  return fl + `<div class="grid2">${sp}${hrsC}</div>`;
};

TAB.comp = x => {
  const rows = rowsOf(), me = ST.matrix[ST.sel]; if (!me) return card('مقایسه', 'chart', '<div class="skel"></div>');
  const M = [['اجماع', r => T.cons(r), v => T.dg(sgn(v))], ['تغییر ۲۴س', r => (r.ticker || {}).change_pct || 0, v => T.fpct(v, 1)], ['حجم معاملات', r => (r.ticker || {}).quote_volume || 0, v => T.usd(v)], ['نوسان (ATR٪)', r => ((r.tfs['1h'] || {}).atr_pct) || 0, v => T.dg(v) + '٪'], ['قدرت نسبی به BTC', r => r.rs24 == null ? 0 : r.rs24, v => T.fpct(v, 1)]];
  const body = M.map(([n, f, fm]) => { const v = f(me), sorted = rows.map(f).sort((a, b) => b - a), rk = sorted.findIndex(z => z <= v) + 1; return `<div class="rk"><span>${n}</span><div class="bar"><i style="right:0;width:${Math.round((1 - (rk - 1) / Math.max(1, rows.length - 1)) * 100)}%;background:var(--a)"></i></div><b>${T.dg(rk)}/${T.dg(rows.length)}</b><span class="mu sm" style="grid-column:1/-1;margin-top:-4px">${fm(v)}</span></div>`; }).join('');
  const peers = rows.filter(r => r.symbol !== ST.sel && r.verdict === me.verdict && r.verdict !== 'WAIT').sort((a, b) => Math.abs(T.cons(b)) - Math.abs(T.cons(a))).slice(0, 5);
  return card('جایگاه این ارز در فهرست', 'chart', body + `<div class="note">رتبه ۱ یعنی بهترین در آن معیار بین ${T.dg(rows.length)} ارز.</div>`) + card('هم‌جهت‌های قوی‌تر', 'bolt', peers.length ? `<div class="list">${peers.map(r => `<div class="li" data-sym="${r.symbol}"><div class="coin">${dot(r.base)}${esc(r.base)}</div>${T.badge(r.verdict)}${gchip(r.grade)}<span class="sp"></span><span class="mu sm">اجماع ${T.dg(sgn(T.cons(r)))}</span></div>`).join('')}</div><div class="note">وقتی چند ارز هم‌جهت قوی هستند، حرکت بازار فراگیر است؛ اگر فقط این یک ارز سیگنال دارد، مراقب حرکت منفرد باشید.</div>` : '<div class="empty">ارز هم‌جهت دیگری با سیگنال فعال نیست.</div>');
};

TAB.alerts = x => {
  const px = x.t.price || x.s.entry, atr = (x.ind || {}).atr || px * .01, mine = (ST.alerts || []).filter(a => a.symbol === ST.sel || a.symbol === '*'), base = x.base;
  const li = mine.length ? mine.map(a => `<div class="alrt ${a.fired ? 'fired' : ''}"><span>${a.fired ? '🔔' : '⏳'}</span><span>${a.type === 'price' ? `${esc(base)} ${a.op === '>' ? 'بالاتر' : 'پایین‌تر'} از <b class="ltr">${T.fp(a.price)}</b>` : `سیگنال درجه ${a.min_grade} یا بهتر ${a.symbol === '*' ? '(همه ارزها)' : ''}`}</span>${a.fired ? `<span class="go sm">${esc(a.fired.msg)}</span>` : ''}<span class="sp"></span><button class="btn dn ibtn" data-act="al-del" data-id="${a.id}">✕</button></div>`).join('') : '<div class="empty">هشداری ثبت نشده.</div>';
  return card('هشدار قیمت', 'bolt', `<div class="row"><select id="al-op"><option value=">">بالاتر از</option><option value="<">پایین‌تر از</option></select><input type="number" inputmode="decimal" id="al-price" step="any" value="${T.fp(px + atr).replace(/,/g, '')}" style="width:130px"><button class="btn pri" data-act="al-add-price">افزودن</button></div><div class="chips" style="margin-top:8px"><button class="chip" data-act="al-fill" data-v="${px + atr}">+۱ ATR</button><button class="chip" data-act="al-fill" data-v="${px - atr}">−۱ ATR</button><button class="chip" data-act="al-fill" data-v="${x.plan ? x.plan.tp1 : px * 1.02}">TP1</button><button class="chip" data-act="al-fill" data-v="${x.plan ? x.plan.stop : px * .98}">حدضرر</button></div>`)
    + card('هشدار سیگنال', 'target', `<div class="row"><label class="note">حداقل درجه <select id="al-grade"><option value="B">B یا بهتر</option><option value="A">فقط A</option><option value="C">C یا بهتر</option></select></label><label class="note"><select id="al-scope"><option value="${x.s.symbol || ST.sel}">فقط ${esc(base)}</option><option value="*">همه ارزها</option></select></label><button class="btn pri" data-act="al-add-sig">افزودن</button></div><div class="note" style="margin-top:6px">وقتی حکم چندتایم‌فریمی به خرید/فروش با درجه کافی تغییر کند، اعلان می‌گیرید (بررسی هر اسکن).</div>`)
    + card(`هشدارهای ${esc(base)} (${T.dg(mine.length)})`, 'flow', li + `<div class="note" style="margin-top:8px">اعلان درون‌برنامه‌ای + صدا/لرزش (تنظیمات ← هشدار). برنامه باید باز باشد؛ سرور هر اسکن را بررسی می‌کند.</div>`);
};


/* ═══════════ v2.3 tabs: entry/exit plan lab · market structure (SMC) · oscillator vote ═══════════ */
T.loadPlan = async function (force) {
  const sym = ST.sel; if (!sym) return; if (!force && ST.planLab && ST.planLab.symbol === sym && ST.planLab.tf === ST.tf && Date.now() - (ST.planAt || 0) < 40000) return;
  const my = ++plTok; const r = await T.api(`/api/plan/${sym}?tf=${ST.tf}`, { timeout: 30000 }); if (my !== plTok || r.error) { if (r.error && my === plTok) { ST.planLab = { symbol: sym, tf: ST.tf, error: r.error }; T.render(); } return; }
  ST.planLab = r; ST.planAt = Date.now(); if ((ST.panel === 'coin' && ST.tab.coin === 'plan') || ST.panel === 'desk' || ST.sheet) T.render();
};
let plTok = 0;
const MODEFA = { market: 'ورود فوری', limit: 'حد پولبک', stop: 'شکست (استاپ)' };
TAB.plan = x => {
  const L = ST.planLab && ST.planLab.symbol === ST.sel && ST.planLab.tf === ST.tf ? ST.planLab : null;
  if (!L) { T.loadPlan(); return card('برنامه ورود و خروج', 'target', '<div class="empty"><div class="skel" style="max-width:260px;margin:auto"></div>در حال شبیه‌سازی ۶۰۰ مسیر برای هر طرح…</div>'); }
  if (L.error) return card('برنامه ورود و خروج', 'target', `<div class="empty">${esc(L.error)}<br><button class="btn" data-act="plan-reload" style="margin-top:8px">تلاش دوباره</button></div>`);
  const dflt = x.plan ? x.plan.side : (L.verdict_side !== 'WAIT' ? L.verdict_side : 'LONG'), side = ST.planSide || dflt, S = side === 'LONG' ? L.long : L.short, px = L.price, atr = L.atr;
  const sw = `<div class="chips" style="margin-bottom:8px"><button class="chip ${side === 'LONG' ? 'on' : ''} LONG" data-act="plan-side" data-v="LONG">خرید (Long)</button><button class="chip ${side === 'SHORT' ? 'on' : ''} SHORT" data-act="plan-side" data-v="SHORT">فروش (Short)</button><span class="note">${x.plan ? 'حکم فعلی: ' + T.SIDE_FA[x.plan.side] : 'حکم فعلی: انتظار'}</span></div>`;
  const b = S.best, pc = (v, base) => T.fpct((v / base - 1) * 100, 2);
  const hero = b ? `<div class="row sb"><b style="font-size:1.05em">${esc(b.name)}</b><span class="chip ${b.mode === 'market' ? 'go' : 'up'}">${MODEFA[b.mode]}</span></div>
    ${kvs([['قیمت ورود', `${T.fp(b.p)} (${pc(b.p, px)} از قیمت فعلی)`], ['حدضرر (' + esc(b.stop_name) + ')', `${T.fp(b.stop)} · ریسک ${T.dg(b.risk_pct)}٪`, 'var(--dn)'], ['TP1 / TP2 / TP3', `${T.fp(b.tp1)} / ${T.fp(b.tp2)} / ${T.fp(b.tp3)}`, 'var(--up)'], ['احتمال پر شدن', pct(b.p_fill)], ['احتمال TP1 (پس از ورود)', pct(b.p_tp1), b.p_tp1 >= .5 ? 'var(--up)' : null], ['احتمال خوردن حدضرر', pct(b.p_stop), 'var(--dn)'], ['امید ریاضی (خالص)', `${T.dg(b.ev_r.toFixed(2))}R`, b.ev_r > 0 ? 'var(--up)' : 'var(--dn)'], ['زمان تا پر شدن / TP1', `${b.t_fill ? hrs(b.t_fill, ST.tf) : 'فوری'} / ${b.t_tp1 ? hrs(b.t_tp1, ST.tf) : '—'}`]])}
    <div class="row" style="margin-top:10px"><button class="btn pri" data-act="plan-order" data-i="${S.rows.indexOf(b)}">${b.mode === 'market' ? 'ورود فوری (کاغذی)' : 'ثبت سفارش معلق (کاغذی)'}</button><label class="note">اعتبار سفارش ${sopt2('pl-valid', [[4, '۴ ساعت'], [8, '۸ ساعت'], [24, '۲۴ ساعت']])}</label></div>` : `<div class="banner">${esc(S.note || 'طرح مناسبی نیست')}</div>`;
  const rows = S.rows.map((r, i) => `<tr class="${r === b ? 'pbest' : ''}"><td>${esc(r.name)}${r === b ? ' ★' : ''}<div class="mu sm">${MODEFA[r.mode]}</div></td><td class="ltr">${T.fp(r.p)}</td><td class="ltr">${T.fp(r.stop)}<div class="mu sm">${esc(r.stop_name)}</div></td><td>${T.dg(Math.round(r.p_fill * 100))}٪</td><td>${T.dg(Math.round(r.p_tp1 * 100))}٪</td><td>${T.dg(Math.round(r.p_stop * 100))}٪</td><td style="color:${r.ev_r > 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(r.ev_r.toFixed(2))}</td><td><button class="btn ibtn" data-act="plan-order" data-i="${i}">＋</button></td></tr>`).join('');
  const lad = b ? card('نمای پلکانی طرح برگزیده', 'chart', `<div class="svgw" style="max-width:340px;margin:auto">${ch.ladder({ side, entry: b.p, stop: b.stop, tp1: b.tp1, tp2: b.tp2, tp3: b.tp3, risk_reward: Math.abs(b.tp2 - b.p) / Math.abs(b.p - b.stop) }, px)}</div>`) : '';
  const o = ((x.s.extras || {}).osc || {}).misc || {}, ast = (o.atr_stops || []).map(z => `<tr><td>${T.dg(z.m)}×ATR</td><td class="ltr">${T.fp(side === 'LONG' ? z.long : z.short)}</td><td class="mu">${pc(side === 'LONG' ? z.long : z.short, px)}</td></tr>`).join('');
  return sw + card(`طرح برگزیده ${T.SIDE_FA[side]}`, 'target', hero + `<div class="note" style="margin-top:8px">هر طرح روی ${T.dg(600)} مسیر شبیه‌سازی‌شده با سایه‌های واقعی آزموده شده؛ اگر حدضرر و هدف در یک کندل باشند حدضرر اول حساب می‌شود و در کندل پر‌شدن هیچ هدفی ثبت نمی‌شود. امید ریاضی ساختاری است و لبه تاریخی را تضمین نمی‌کند.</div>`, 'w2') + lad
    + card(`مقایسه همه طرح‌ها (${T.dg(S.rows.length)})`, 'chart', `<div class="tw"><table class="ptbl"><thead><tr><th>طرح</th><th>ورود</th><th>حدضرر</th><th>پر شدن</th><th>TP1</th><th>ضرر</th><th>امید R</th><th></th></tr></thead><tbody>${rows || '<tr><td colspan="8" class="empty">طرحی با نمونه کافی نیست</td></tr>'}</tbody></table></div>`, 'w2')
    + (ast ? card('جدول حدضرر بر پایه ATR', 'shield', `<div class="tw"><table><thead><tr><th>فاصله</th><th>قیمت</th><th>درصد</th></tr></thead><tbody>${ast}</tbody></table></div><div class="note">Chandelier Exit (۲۲ کندل): خرید ${T.fp(o.chandelier_long)} · فروش ${T.fp(o.chandelier_short)} — برای دنبال‌کردن حدضرر بعد از TP1.</div>`) : '');
};
const sopt2 = (id, opts) => `<select id="${id}">${opts.map(([v, n]) => `<option value="${v}">${n}</option>`).join('')}</select>`;

TAB.smc = x => {
  const sm = (x.s.extras || {}).smc; if (!sm || !sm.structure) return card('ساختار بازار', 'flow', '<div class="empty">داده کافی نیست.</div>');
  const px = x.t.price || x.s.entry, st = sm.structure, ev = sm.event, rg = sm.range, TR = { bull: ['صعودی', 'var(--up)'], bear: ['نزولی', 'var(--dn)'], range: ['رنج', 'var(--go)'], expand: ['گسترش نوسان', 'var(--go)'], squeeze: ['فشردگی', 'var(--go)'] }[st.trend];
  const zn = { premium: ['ناحیه گران (Premium)', 'var(--dn)', 'برای خرید گران است؛ برای فروش مناسب‌تر'], discount: ['ناحیه ارزان (Discount)', 'var(--up)', 'برای خرید مناسب‌تر است'], equilibrium: ['تعادل', 'var(--go)', 'نزدیک نیمه رنج؛ برتری مکانی ندارد'] }[rg.zone];
  const lines = [];
  if (st.trend === 'bull' && rg.zone === 'discount') lines.push('✔ روند صعودی + قیمت در ناحیه ارزان: بهترین موقعیت مکانی برای خرید در پولبک.');
  if (st.trend === 'bear' && rg.zone === 'premium') lines.push('✔ روند نزولی + قیمت در ناحیه گران: بهترین موقعیت مکانی برای فروش در پولبک.');
  if (st.trend === 'bull' && rg.zone === 'premium') lines.push('⚠ روند صعودی ولی قیمت گران است؛ دنبال‌کردن حرکت پرریسک است، منتظر پولبک بمانید.');
  if (st.trend === 'bear' && rg.zone === 'discount') lines.push('⚠ روند نزولی ولی قیمت ارزان است؛ فروش تعقیبی پرریسک است.');
  if (ev && ev.kind === 'CHoCH') lines.push(`⚠ تغییر ماهیت (CHoCH ${ev.dir === 'up' ? 'صعودی' : 'نزولی'}) ${T.dg(ev.ago)} کندل پیش؛ ساختار قبلی شکسته شده است.`);
  if (sm.sweep) lines.push('ℹ ' + sm.sweep.note);
  const head = card('ساختار بازار (Smart Money)', 'flow', `<div class="tv"><div><div class="mu sm">ساختار</div><div class="lbl" style="color:${TR[1]}">${TR[0]}</div><div class="sm mu">${esc(st.label)}</div></div><div><div class="mu sm">آخرین رویداد</div><div class="lbl">${ev ? `${ev.kind} ${ev.dir === 'up' ? '▲' : '▼'}` : '—'}</div><div class="sm mu">${ev ? `${T.dg(ev.ago)} کندل پیش · ${T.fp(ev.level)}` : 'شکستی دیده نشد'}</div></div><div><div class="mu sm">موقعیت در رنج</div><div class="lbl" style="color:${zn[1]}">${zn[0]}</div><div class="sm mu">${T.dg(Math.round(rg.pos * 100))}٪ از رنج</div></div></div>
    ${kvs([['آخرین سقف / کف', `${T.fp(st.last_high)} / ${T.fp(st.last_low)}`], ['سقف / کف رنج ۶۰ کندل', `${T.fp(rg.hi)} / ${T.fp(rg.lo)}`], ['تعادل (۵۰٪)', T.fp(rg.eq)], ['ناحیه OTE (فیبو ۰٫۶۲–۰٫۷۹)', `${T.fp(rg.ote_lo)} – ${T.fp(rg.ote_hi)}`]])}${lines.length ? `<div style="margin-top:8px">${lines.map(l => `<div class="vd info">${esc(l)}</div>`).join('')}</div>` : ''}`, 'w2');
  const zrow = (z, col, label) => `<div class="zone"><i style="background:${col}"></i><span>${label}${z.partial ? ' <span class="chip go">نیمه‌پر</span>' : ''}${z.touched ? ' <span class="chip">لمس‌شده</span>' : ''}</span><b class="ltr">${T.fp(z.lo)} – ${T.fp(z.hi)} <span class="mu sm">(${T.fpct(((z.lo + z.hi) / 2 / px - 1) * 100, 1)})</span></b></div>`;
  const fv = card('گپ‌های ارزش (FVG) پرنشده', 'pulse', (sm.fvg || []).map(z => zrow(z, z.kind === 'bull' ? 'var(--up)' : 'var(--dn)', `${z.kind === 'bull' ? 'صعودی' : 'نزولی'} · ${T.dg(z.ago)} کندل پیش · ${T.dg(z.size_atr)} ATR`)).join('') || '<div class="empty">گپ پرنشده‌ای نیست.</div>' + '', '') + '';
  const ob = card('اردر‌بلاک‌ها (ابطال‌نشده)', 'target', (sm.ob || []).map(z => zrow(z, z.kind === 'bull' ? 'var(--up)' : 'var(--dn)', `${z.kind === 'bull' ? 'تقاضا (خرید)' : 'عرضه (فروش)'} · ${T.dg(z.ago)} کندل پیش`)).join('') || '<div class="empty">اردر‌بلاک معتبری نیست.</div>');
  const lq = (arr, col, nm) => arr.map(l => `<div class="zone"><i style="background:${col}"></i><span>${nm} ×${T.dg(l.n)}</span><b class="ltr">${T.fp(l.p)} <span class="mu sm">(${T.fpct(l.dist_pct, 1)})</span></b></div>`).join('');
  const liq = card('استخرهای نقدینگی', 'wallet', (lq(sm.liq_above || [], 'var(--dn)', 'سقف‌های برابر (حدضررهای فروشنده‌ها)') + lq(sm.liq_below || [], 'var(--up)', 'کف‌های برابر (حدضررهای خریدارها)')) || '<div class="empty">سقف/کف برابر مشخصی نیست.</div>', '');
  return head + `<div class="grid2">${fv}${ob}</div>` + liq + card('راهنما', 'brain', '<p class="note" style="margin:0;line-height:2">BOS = شکست ساختار در جهت روند · CHoCH = اولین شکست خلاف روند (هشدار تغییر) · FVG = شکاف سه‌کندلی که قیمت معمولاً برای پر کردنش برمی‌گردد · اردر‌بلاک = آخرین کندل مخالف قبل از حرکت انفجاری · نقدینگی = جایی که حدضررهای زیادی انباشته است و قیمت اغلب برای جمع‌آوری آن سایه می‌زند. این مفاهیم تفسیری‌اند؛ در کنار چک‌لیست و برنامه ورود استفاده کنید.</p>');
};


TAB.deep = x => {
  const { s, t, ind, base, plan, d, c, edge, pf } = x;
  const adv = (d && d.advanced) || {}, eg = adv.edge || {}, ck = adv.checklist || {}, sess = adv.session || {}, rs = adv.rel_strength || {}, mb = (adv.micro || {}).bias_pack || {};
  const side = (d && d.verdict) || s.side || 'WAIT';
  const gr = (d && d.grade) || {};
  const meter = (label, val, max, col) => {
    const p = Math.max(0, Math.min(100, (val / (max || 1)) * 100));
    return `<div class="meter"><span>${esc(label)}</span><div class="bar"><i style="width:${p}%;background:${col||'var(--a)'}"></i></div><b>${T.dg(typeof val==='number'?val.toFixed?val.toFixed(0):val:val)}</b></div>`;
  };
  const verdictCol = side === 'LONG' ? 'var(--up)' : side === 'SHORT' ? 'var(--dn)' : 'var(--mu)';
  const hero = card(`تحلیل عمیق · ${esc(base)}`, 'brain', `
    <div class="deep-hero">
      <div class="deep-badge" style="border-color:${verdictCol};color:${verdictCol}">${T.SIDE_FA[side]||side}</div>
      <div class="deep-score"><b style="color:${verdictCol}">${T.dg(sgn(d ? d.consensus_score : s.score))}</b><span>اجماع چندتایم‌فریم</span></div>
      <div class="deep-score"><b>${eg.edge != null ? T.dg(eg.edge) : '—'}</b><span>Edge /100</span></div>
      <div class="deep-score">${gchip(gr.grade||'—')}<span>درجه ستاپ</span></div>
      <div class="deep-score"><b>${T.dg(Math.round((d && d.conviction || s.confidence || 0)*100))}٪</b><span>باور مدل</span></div>
    </div>
    <p class="note" style="margin-top:10px;line-height:1.9">${esc((d && d.narrative) || (s.reasons||[]).join(' · ') || 'در حال جمع‌آوری داده…')}</p>`);
  const meters = card('لایه‌های تصمیم', 'pulse', [
    meter('قدرت سیگنال', Math.abs(s.score||0), 100, T.scol(s.score)),
    meter('هم‌سویی مولفه‌ها', (s.agree||0)*100, 100, 'var(--a)'),
    meter('اعتماد', (s.confidence||0)*100, 100, 'var(--b)'),
    meter('Edge', eg.edge||0, 100, eg.edge>=55?'var(--up)':eg.edge>=40?'var(--go)':'var(--dn)'),
    meter('کامل‌بودن ستاپ', (ck.pct||0)*100, 100, (ck.pct||0)>=0.65?'var(--up)':'var(--go)'),
    meter('میکروساختار', Math.abs((mb.bias||0)*100), 100, (mb.bias||0)>=0?'var(--up)':'var(--dn)'),
  ].join(''));
  const compare = card('مقایسه عوامل (موافق / مخالف)', 'flow', `<div class="grid2">
    <div class="deep-col up-col"><h4>✔ عوامل حمایت از ${side==='WAIT'?'صبر':T.SIDE_FA[side]}</h4>
      ${(s.reasons||[]).slice(0,6).map(r=>`<div class="vd ok">${esc(r)}</div>`).join('')||'<div class="note">—</div>'}
      ${mb.bias && ((side==='LONG'&&mb.bias>0)||(side==='SHORT'&&mb.bias<0)) ? `<div class="vd ok">میکرو: ${esc(mb.label||'')}</div>`:''}
      ${rs.ok && ((side==='LONG'&&rs.rs_pct>0)||(side==='SHORT'&&rs.rs_pct<0)) ? `<div class="vd ok">RS vs BTC: ${T.dg(rs.rs_pct)}٪</div>`:''}
      ${(gr.why||[]).filter(w=>w.p>0).map(w=>`<div class="vd ok">${esc(w.t)}</div>`).join('')}
    </div>
    <div class="deep-col dn-col"><h4>✖ ریسک‌ها و هشدارها</h4>
      ${(s.warnings||[]).map(w=>`<div class="vd bad">⚠ ${esc(w)}</div>`).join('')||'<div class="note">هشدار خاصی نیست</div>'}
      ${mb.bias && ((side==='LONG'&&mb.bias<-0.15)||(side==='SHORT'&&mb.bias>0.15)) ? `<div class="vd bad">میکرو مخالف: ${esc(mb.label||'')}</div>`:''}
      ${(gr.why||[]).filter(w=>w.p<0).map(w=>`<div class="vd bad">${esc(w.t)}</div>`).join('')}
      ${d && d.veto ? `<div class="vd bad">${esc(d.veto)}</div>`:''}
    </div>
  </div>`);
  const levels = plan && plan.side !== 'WAIT' ? card('نقشه اجرا', 'target', `<div class="kpis">
    <div class="kpi"><b class="ltr">${T.fp(plan.entry)}</b><span>ورود ${(ind.entry_kind==='limit')?'لیمیت':'بازار'}</span></div>
    <div class="kpi"><b class="dn ltr">${T.fp(plan.stop)}</b><span>حدضرر</span></div>
    <div class="kpi"><b class="up ltr">${T.fp(plan.tp1)}</b><span>TP1</span></div>
    <div class="kpi"><b class="ltr">${T.dg(plan.risk_reward)}</b><span>R:R</span></div>
  </div>${edge?`<div class="kv" style="margin-top:8px"><span>P(TP1)</span><b>${pct(edge.p_tp1)}</b><span>امید ریاضی</span><b style="color:${edge.ev_r>=0?'var(--up)':'var(--dn)'}">${T.dg(edge.ev_r.toFixed(2))}R</b></div>`:''}`) : card('نقشه اجرا', 'target', '<div class="empty">سیگنال فعالی برای اجرا نیست — صبر منطقی است.</div>');
  const tfrow = d && d.all_tf ? card('هم‌خوانی تایم‌فریم‌ها', 'chart', `<div class="tw"><table><thead><tr><th>TF</th><th>سمت</th><th>امتیاز</th><th>رژیم</th><th>اطمینان</th></tr></thead><tbody>${Object.entries(d.all_tf).map(([tf,sg])=>`<tr><td>${tf}</td><td>${T.badge(sg.side)}</td><td style="color:${T.scol(sg.score)}">${T.dg(sgn(sg.score))}</td><td>${T.REGIME_FA[sg.regime]||sg.regime||'—'}</td><td>${T.dg(Math.round((sg.confidence||0)*100))}٪</td></tr>`).join('')}</tbody></table></div>`, 'w2') : '';
  return hero + meters + compare + levels + tfrow;
};

TAB.counsel = x => {
  const { s, plan, d, ind, base, edge, pf } = x;
  const adv = (d && d.advanced) || {}, eg = adv.edge || {}, ck = adv.checklist || {}, mb = (adv.micro||{}).bias_pack || {}, rs = adv.rel_strength || {}, sess = adv.session || {};
  const side = (d && d.verdict) || s.side || 'WAIT';
  const gr = ((d && d.grade) || {}).grade || '—';
  const lines = [];
  // Professional consulting narrative
  if (side === 'WAIT') {
    lines.push({ t: 'نظر مشاور', c: 'info', b: `برای ${base} الان ستاپ تمیزی دیده نمی‌شود. اجماع تایم‌فریم‌ها یا هم‌سویی مولفه‌ها به آستانه ورود نرسیده است.` });
    lines.push({ t: 'اقدام', c: 'ok', b: 'وارد نشوید. واچ‌لیست کنید و منتظر بسته شدن کندل تایم‌فریم بالاتر با هم‌جهتی بمانید.' });
  } else {
    const act = side === 'LONG' ? 'خرید' : 'فروش';
    lines.push({ t: 'نظر مشاور', c: gr==='A'||gr==='B'?'ok':'warn', b: `سمت غالب: ${act}. درجه ستاپ ${gr} · Edge ${eg.edge!=null?Math.round(eg.edge):'—'} · باور ${Math.round(((d&&d.conviction)||s.confidence||0)*100)}٪.` });
    if (gr === 'A' || (gr==='B' && (eg.edge||0) >= 55)) {
      lines.push({ t: 'کیفیت', c: 'ok', b: 'ستاپ از نظر چندتایم‌فریم و ساختار قابل قبول است. ورود فقط با رعایت حدضرر و حجم ریسک ثابت.' });
    } else if (gr === 'C' || gr === 'D') {
      lines.push({ t: 'کیفیت', c: 'bad', b: 'درجه پایین است — یا صبر کنید تا هم‌جهتی بهتر شود، یا حجم را نصف کنید.' });
    }
    if (ind.entry_kind === 'limit') {
      lines.push({ t: 'نحوه ورود', c: 'ok', b: `ورود لیمیت روی ساختار (${T.fp(plan.entry)}) ترجیح داده می‌شود تا chase نشود و R:R بهتر بماند.` });
    } else {
      lines.push({ t: 'نحوه ورود', c: 'warn', b: 'ورود بازار فقط اگر شکست تأییدشده با حجم دارید؛ در غیر این صورت منتظر پولبک بمانید.' });
    }
    if ((s.risk_reward||0) < 1.5) lines.push({ t: 'R:R', c: 'bad', b: `نسبت ریوارد به ریسک ${T.dg(s.risk_reward)} ضعیف است — حجم را کم کنید یا رد کنید.` });
    else lines.push({ t: 'R:R', c: 'ok', b: `R:R حدود ${T.dg(s.risk_reward)} — با خروج پله‌ای (۴۰/۳۵/۲۵) مدیریت کنید.` });
    if (mb.label && mb.label !== 'خنثی') {
      const align = (side==='LONG'&&(mb.bias||0)>0)||(side==='SHORT'&&(mb.bias||0)<0);
      lines.push({ t: 'میکروساختار', c: align?'ok':'bad', b: `${mb.label}. فاندینگ/دفتر سفارش ${align?'هم‌جهت با سیگنال':'مخالف سیگنال'} است.` });
    }
    if (rs.ok) lines.push({ t: 'قدرت نسبی', c: (side==='LONG'&&rs.rs_pct>0)||(side==='SHORT'&&rs.rs_pct<0)?'ok':'warn', b: `نسبت به BTC در ${T.dg(rs.look)} کندل: ${T.dg(rs.rs_pct)}٪ (${rs.label||''}).` });
    if (sess.name) lines.push({ t: 'جلسه', c: 'info', b: `الان جلسه ${sess.name} (UTC ${T.dg(sess.hour_utc||0)}) است. نقدشوندگی نسبی را در نظر بگیرید.` });
    if ((s.warnings||[]).length) lines.push({ t: 'هشدارها', c: 'bad', b: s.warnings.slice(0,4).join(' · ') });
    if (edge && edge.ev_r != null) lines.push({ t: 'امید ریاضی شبیه‌سازی', c: edge.ev_r>=0?'ok':'bad', b: `${T.dg(edge.ev_r.toFixed(2))}R · احتمال TP1 ${pct(edge.p_tp1)} · احتمال استاپ ${pct(edge.p_stop)}.` });
    lines.push({ t: 'مدیریت', c: 'info', b: 'حداکثر ۱٪ ریسک سرمایه · بعد از TP1 استاپ را به سر‌به‌سر بیاورید · اگر حکم چندتایم‌فریم برعکس شد خارج شوید.' });
  }
  if (ck.items) {
    lines.push({ t: 'چک‌لیست', c: (ck.pct||0)>=0.65?'ok':'warn', b: `کامل‌بودن: ${ck.label||'—'} (${T.dg(ck.score)}/${T.dg(ck.max)}).` });
  }
  return card(`مشاوره معاملاتی · ${esc(base)}`, 'shield', lines.map(L => `<div class="vd ${L.c}"><b>${esc(L.t)}</b><div>${esc(L.b)}</div></div>`).join('') +
    `<div class="note" style="margin-top:12px;line-height:1.9">این مشاوره بر اساس موتور چندتایم‌فریم، ساختار، پیش‌بینی مسیری، میکروساختار و Edge است؛ جایگزین مدیریت ریسک شخصی شما نیست.</div>`, 'w2');
};

TAB.edge = x => {
  const { s, d, plan } = x;
  const adv = (d && d.advanced) || {}, eg = adv.edge || {}, parts = eg.parts || {};
  if (!eg || eg.edge == null) return card('امتیاز برتری (Edge)', 'bolt', '<div class="empty">بعد از بارگذاری تحلیل عمیق محاسبه می‌شود.</div>');
  const bars = Object.entries(parts).map(([k,v]) => {
    const w = Math.max(3, Math.min(100, Math.abs(v)*5));
    const col = v>=0?'var(--up)':'var(--dn)';
    return `<div class="meter"><span>${esc(k)}</span><div class="bar"><i style="width:${w}%;background:${col}"></i></div><b style="color:${col}">${v>=0?'+':''}${T.dg(v)}</b></div>`;
  }).join('');
  return card(`Edge ${T.dg(eg.edge)}/100 · ${esc(eg.label||'')}`, 'bolt', bars + `<div class="note" style="margin-top:8px">${esc(eg.note||'')}</div><div class="note">Edge برای رتبه‌بندی فرصت‌هاست، نه احتمال برد تضمینی.</div>`, 'w2');
};


function oscCards(s) {
  const o = (s.extras || {}).osc; if (!o || !o.osc) return '';
  const lblc = t => t.includes('خرید') ? 'var(--up)' : t.includes('فروش') ? 'var(--dn)' : 'var(--mu)', m = o.misc || {};
  const row = z => `<div class="vote"><span>${esc(z.n)}<span class="mu sm"> ${z.note ? esc(z.note) : ''}</span></span><span class="ltr mu sm">${z.v == null ? '' : T.fp(z.v)}</span><b class="s ${z.s > 0 ? 'buy' : z.s < 0 ? 'sell' : 'neu'}">${z.s > 0 ? 'خرید' : z.s < 0 ? 'فروش' : 'خنثی'}</b></div>`;
  const sum = card('رای‌گیری اسیلاتورها و میانگین‌ها', 'gear', `<div class="tv"><div><div class="mu sm">اسیلاتورها</div><div class="lbl" style="color:${lblc(o.osc_label)}">${o.osc_label}</div><div class="sm mu">${T.dg(o.osc_buy)} خرید · ${T.dg(o.osc_neu)} خنثی · ${T.dg(o.osc_sell)} فروش</div></div><div><div class="mu sm">جمع‌بندی</div><div class="lbl" style="color:${lblc(o.all_label)};font-size:1.3em">${o.all_label}</div><div class="sm mu">امتیاز ${T.dg(sgn(o.all_score))}</div></div><div><div class="mu sm">میانگین‌ها</div><div class="lbl" style="color:${lblc(o.ma_label)}">${o.ma_label}</div><div class="sm mu">${T.dg(o.ma_buy)} خرید · ${T.dg(o.ma_sell)} فروش</div></div></div>`, 'w2');
  const lists = `<div class="grid2">${card('اسیلاتورها', 'pulse', o.osc.map(row).join(''))}${card('میانگین‌های متحرک', 'chart', o.ma.map(z => `<div class="vote"><span>${esc(z.n)}</span><span class="ltr mu sm">${z.v == null ? '' : T.fp(z.v)}</span><b class="s ${z.s > 0 ? 'buy' : z.s < 0 ? 'sell' : 'neu'}">${z.s > 0 ? 'زیر قیمت' : z.s < 0 ? 'بالای قیمت' : '—'}</b></div>`).join(''))}</div>`;
  const misc = card('شاخص‌های تکمیلی', 'gear', kvs([['Parabolic SAR', `${T.fp(m.psar)} · ${m.psar_dir === 'up' ? 'صعودی' : 'نزولی'}`, m.psar_dir === 'up' ? 'var(--up)' : 'var(--dn)'], ['فشردگی بولینگر درون کلتنر', m.squeeze_kc ? 'بله (آماده انفجار)' : 'خیر', m.squeeze_kc ? 'var(--go)' : null], ['ضریب کارایی (۱۰ / ۳۰)', `${T.dg(m.er10)} / ${T.dg(m.er30)}`, m.er10 > .45 ? 'var(--a)' : null], ['فشار حجمی (Force)', m.force], ['کلتنر بالا / پایین', `${T.fp(m.keltner.u)} / ${T.fp(m.keltner.l)}`]]) + `<div class="note" style="margin:8px 0 4px"><b>مخروط نوسان (یک انحراف معیار):</b></div><div class="tw"><table><thead><tr><th>کندل</th><th>±٪</th><th>کف</th><th>سقف</th></tr></thead><tbody>${m.cone.map(z => `<tr><td>${T.dg(z.n)}</td><td>${T.dg(z.sd)}</td><td class="ltr">${T.fp(z.lo)}</td><td class="ltr">${T.fp(z.hi)}</td></tr>`).join('')}</tbody></table></div>`);
  return sum + lists + misc;
}

const COIN_TABS = [['sum', 'خلاصه'], ['deep', 'تحلیل عمیق'], ['counsel', 'مشاوره معاملاتی'], ['edge', 'امتیاز برتری'], ['plan', 'برنامه ورود/خروج'], ['check', 'چک‌لیست ورود'], ['pat', 'الگوها'], ['smc', 'ساختار بازار'], ['scen', 'سناریوها'], ['tech', 'تکنیکال'], ['mtf', 'چندتایم‌فریم'], ['fc', 'پیش‌بینی'], ['lvl', 'سطوح'], ['flow', 'جریان سفارش'], ['micro', 'بازار خرد'], ['comp', 'مقایسه'], ['bt', 'بک‌تست'], ['alerts', 'هشدار'], ['risk', 'ریسک'], ['ai', 'هوش مرکزی Gemini']];
function coinCtx() {
  const sel = ST.sel, c = ST.coin, d = ST.deep; if (!sel || !c || c.error || !c.signal) return null;
  const s = c.signal, t = c.ticker || {}, ind = s.indicators || {}, base = c.base || sel.replace('USDT', '');
  const plan = d && d.verdict && d.verdict !== 'WAIT' && d.signal ? d.signal : (s.side !== 'WAIT' ? s : null);
  const pf = (d && d.forecast && !d.error ? d.forecast : c.forecast) || {}, edge = plan && pf ? pf.edge : null;
  return { s, t, ind, base, plan, d, c, edge, pf };
}
R.coin = function () {
  const el = $('#p-coin'), sel = ST.sel, c = ST.coin, d = ST.deep;
  const q = el.querySelector('#coin-q'), qv = q ? q.value : '';
  const picker = `<div class="card pk"><input type="text" id="coin-q" placeholder="جستجوی ارز…" value="${esc(qv)}"><div class="chips hs" id="coin-chips">${ST.syms.map(s => { const r = ST.matrix[s], sd = r ? T.consSide(T.cons(r)) : 'WAIT'; return `<button class="chip ${s === sel ? 'on' : ''} ${sd}" data-sym="${s}" data-b="${s.replace('USDT', '')}">${s.replace('USDT', '')}</button>`; }).join('')}</div></div>`;
  const tabs = T.tabs('coin', COIN_TABS);
  if (!sel || !c) { put(el, picker + card('در حال بارگذاری', 'scan', '<div class="empty"><div class="skel" style="max-width:300px;margin:auto"></div></div>')); bindQ(); return; }
  if (c.error) { put(el, picker + card('خطا', 'shield', `<div class="empty">${esc(c.error)}<br><button class="btn" data-act="reload" style="margin-top:10px">تلاش مجدد</button></div>`)); bindQ(); return; }
  const s = c.signal, t = c.ticker || {}, ind = s.indicators || {}, base = c.base || sel.replace('USDT', '');
  const plan = d && d.verdict && d.verdict !== 'WAIT' ? d.signal : (s.side !== 'WAIT' ? s : null);
  const pf = (d && d.forecast && !d.error ? d.forecast : c.forecast) || {}, edge = plan && pf ? pf.edge : null;
  const x = { s, t, ind, base, plan, d, c, edge, pf }, tab = TAB[ST.tab.coin] ? ST.tab.coin : 'sum';
  if (put(el, picker + tabs + `<div class="tabbody">${TAB[tab](x)}</div>`, () => killMinis('coin'))) mountMinis(el, 'coin');
  bindQ(); const nq = el.querySelector('#coin-q'); if (nq && nq.value) filterChips(nq.value);
};
function filterChips(v) { v = v.trim().toUpperCase(); T.$$('#coin-chips .chip').forEach(b => b.style.display = !v || b.dataset.b.includes(v) ? '' : 'none'); }
function bindQ() { const q = $('#coin-q'); if (q) q.oninput = () => filterChips(q.value); }

/* ═══════════ CHART PANEL ═══════════ */
let chart = null, chKey = '', mtfKey = '';
R.redrawChart = () => { if (chart) chart.sched(); };
const LAYERS = [['pat', 'الگوها'], ['ema', 'EMA'], ['e200', 'EMA200'], ['bb', 'بولینگر'], ['vwap', 'VWAP'], ['ich', 'ایچیموکو'], ['st', 'سوپرترند'], ['sr', 'حمایت/مقاومت'], ['pv', 'پیوت'], ['fib', 'فیبو'], ['vp', 'پروفایل حجم'], ['lv', 'ورود/SL/TP'], ['fc', 'آینده ۳۲'], ['vol', 'حجم']];
const PANES = [['rsi', 'RSI'], ['macd', 'MACD'], ['srsi', 'StochRSI']];
const IB = (a, i, t) => `<button class="btn ibtn tb" data-act="${a}" ${i ? `data-f="${i}"` : ''} data-tip="${t}" aria-label="${t}">${({ zin: '＋', zout: '－', zr: '⟲', fs: '⛶', png: '⤓' })[a]}</button>`;
R.chart = function () {
  const el = $('#p-chart'), c = ST.coin, d = ST.deep, L = T.UI.chart.layers, P = T.UI.chart.panes, tab = ST.tab.chart;
  if (!$('#ch-main')) { el.innerHTML = '<div id="ch-tabs"></div><div id="ch-main" class="card chcard"><div id="ch-bar"></div><div id="ch-host"></div><div class="note" id="ch-note"></div></div><div id="ch-mtf"></div>'; if (chart) { chart.destroy(); chart = null; } chKey = ''; }
  put($('#ch-tabs'), T.tabs('chart', [['main', 'نمودار'], ['mtf', 'همه تایم‌فریم‌ها']]));
  $('#ch-main').style.display = tab === 'main' ? '' : 'none'; $('#ch-mtf').style.display = tab === 'mtf' ? '' : 'none';
  const lay = ([k, n]) => `<button class="chip ${L[k] ? 'on' : ''} ${k === 'fc' ? 'fcl' : ''}" data-act="layer" data-k="${k}">${n}</button>`, pan = ([k, n]) => `<button class="chip ${P[k] ? 'on' : ''}" data-act="pane" data-k="${k}">${n}</button>`;
  put($('#ch-bar'), `<div class="row sb" style="flex-wrap:nowrap"><b class="ctitle">${esc((ST.sel || '').replace('USDT', ''))}<small> / USDT</small></b><div class="row" style="gap:6px;flex-wrap:nowrap">${IB('zin', '.8', 'بزرگ‌نمایی')}${IB('zout', '1.25', 'کوچک‌نمایی')}${IB('zr', '', 'بازنشانی نما')}${IB('png', '', 'ذخیره تصویر')}${IB('fs', '', 'تمام‌صفحه')}</div></div>
    <div class="row" style="margin:8px 0 6px">${tfChips(ST.tf)}</div><div class="chips hs" style="margin-bottom:6px">${LAYERS.map(lay).join('')}<span class="sepv"></span>${PANES.map(pan).join('')}</div>
    <div class="chips hs" style="margin-bottom:8px">${ST.syms.map(s => `<button class="chip ${s === ST.sel ? 'on' : ''}" data-sym="${s}">${s.replace('USDT', '')}</button>`).join('')}</div>`);
  if (tab === 'mtf') {
    if (!Object.keys(ST.mtf).length && !ST._mtfL) { ST._mtfL = true; T.loadMtf().finally(() => { ST._mtfL = false; }); }
    const ready = ST.tfs.filter(tf => ST.mtf[tf] && ST.mtf[tf].sym === ST.sel), key = ready.map(tf => tf + ST.mtf[tf].updated).join('|') + ST.sel;
    const html = `<div class="mtfgrid">${ST.tfs.map(tf => { const m = ST.mtf[tf]; if (!m || m.sym !== ST.sel) return card(tf, 'chart', '<div class="skel"></div>'); const s = m.signal; return card(`${tf} ${T.badge(s.side)}`, 'chart', `<div class="mini-ch" data-tf="${tf}"></div><div class="row sb note" style="margin-top:6px"><span>امتیاز ${T.dg(sgn(s.score))}</span><span>صعود ${T.dg(Math.round(((m.forecast || {}).prob_up || .5) * 100))}٪</span><span>${T.REGIME_FA[s.regime] || ''}</span></div>`); }).join('')}</div><div class="note" style="text-align:center">برای نمودار کامل هر تایم‌فریم روی آن بزنید.</div>`;
    if (mtfKey !== key || !$('#ch-mtf')._h) { mtfKey = key; if (put($('#ch-mtf'), html, () => killMinis('mtf'))) mountMinis($('#ch-mtf'), 'mtf'); }
    return;
  }
  if (!c || c.error) { $('#ch-note').textContent = c && c.error ? c.error : 'در حال بارگذاری…'; return; }
  const plan = d && d.verdict && d.verdict !== 'WAIT' && d.signal ? d.signal : c.signal, host = $('#ch-host'), full = $('#ch-main').classList.contains('ch-full');
  host.dataset.full = full ? '1' : '0';
  if (L.pat && !patFor()) T.loadPat(ST.sel);
  const key = [ST.sel, ST.tf, c.updated, JSON.stringify(L), JSON.stringify(P), full, plan && plan.entry, ST.patAt, T.UI.candle, T.UI.cone, T.UI.grid, T.UI.wick, T.UI.chartN].join('|'); if (key === chKey && chart) return; chKey = key;
  if (!chart) chart = new ch.CandleChart(host);
  chart.set(c.klines, { signal: plan, forecast: c.forecast, tf: ST.tf, layers: L, panes: P, pat: patFor() });
  $('#ch-note').innerHTML = `یک‌انگشت: جابه‌جایی · دو‌انگشت: زوم · لمس: جزئیات کندل · دوبار لمس: بازنشانی<br><span class="fsw"><i style="background:var(--fu)"></i>کندل آینده صعودی</span> <span class="fsw"><i style="background:var(--fd)"></i>کندل آینده نزولی</span> · ناحیه بنفش: مخروط ۵–۹۵٪ / ۱۰–۹۰٪ / ۲۵–۷۵٪ · خط‌چین: مسیر میانه`;
};

/* ═══════════ MARKET (screener · breadth · correlation · system) ═══════════ */
const SCR_TABS = [['opp', 'فرصت‌ها'], ['breadth', 'نمای بازار'], ['corr', 'همبستگی'], ['sys', 'سیستم']];
function scrRows() {
  const f = ST.scr, gi = g => 'ABCD'.indexOf(g) < 0 ? 9 : 'ABCD'.indexOf(g);
  let rows = rowsOf().filter(r => { const v = r.verdict || 'WAIT', t = r.tfs['1h'] || Object.values(r.tfs)[0] || {};
    if (f.side === 'sig' && v === 'WAIT') return false; if ((f.side === 'LONG' || f.side === 'SHORT') && v !== f.side) return false;
    if (f.grade === 'AB' && !'AB'.includes(r.grade)) return false; if (f.grade === 'A' && r.grade !== 'A') return false;
    if (Math.abs(r.cons || 0) < f.min) return false; if (f.rr && (t.rr || 0) < f.rr) return false;
    if (f.q && !r.base.includes(f.q.toUpperCase())) return false; return true; });
  const key = { cons: r => -Math.abs(r.cons || 0), grade: r => gi(r.grade) * 1000 - Math.abs(r.cons || 0), chg: r => -((r.ticker || {}).change_pct || 0), vol: r => -((r.ticker || {}).quote_volume || 0), ev: r => -(((r.tfs['1h'] || {}).ev_r) || -9), atr: r => -(((r.tfs['1h'] || {}).atr_pct) || 0) }[f.sort] || (r => 0);
  return rows.sort((a, b) => key(a) - key(b));
}
function scrResHtml() {
  const rows = scrRows(); if (!rows.length) return '<div class="empty">هیچ ارزی با این فیلترها نیست؛ فیلتر را شل‌تر کنید.</div>';
  return `<div class="note" style="margin:0 2px 8px">${T.dg(rows.length)} نتیجه</div><div class="scgrid">${rows.map(r => { const t = r.ticker || {}, tf = r.tfs['1h'] || Object.values(r.tfs)[0] || {}, v = r.verdict || 'WAIT', col = T.col(v);
    return `<div class="sc" data-sym="${r.symbol}" style="border-color:color-mix(in srgb,${col} 40%,var(--ln))"><div class="row sb" style="flex-wrap:nowrap"><div class="coin">${dot(r.base)}${esc(r.base)}</div><span>${gchip(r.grade)} ${T.badge(v)}</span></div>
    <div class="row sb" style="font-size:.88em;flex-wrap:nowrap"><span class="ltr">${T.fp(t.price)}</span><span class="${t.change_pct >= 0 ? 'up' : 'dn'}">${T.fpct((r.ticker || {}).change_pct, 1)}</span></div>
    <div style="margin:4px 0">${barSigned(r.cons || 0)}</div><div class="row sb" style="flex-wrap:nowrap"><div class="tfs">${ST.tfs.map(k => tfCell(k, r.tfs[k])).join('')}</div><b style="color:${T.scol(r.cons || 0)}">${T.dg(sgn(r.cons || 0))}</b></div>
    <div style="margin:6px 0 2px">${ch.miniCandles(r, 260, 70, col)}</div><div class="chips sm">${tf.rr ? `<span class="chip">R:R ${T.dg(tf.rr)}</span>` : ''}${tf.p_tp1 != null ? `<span class="chip">TP1 ${pct(tf.p_tp1)}</span>` : ''}${tf.ev_r != null ? `<span class="chip" style="color:${tf.ev_r >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(tf.ev_r.toFixed(2))}R</span>` : ''}${tf.rsi != null ? `<span class="chip">RSI ${T.dg(Math.round(tf.rsi))}</span>` : ''}${r.corr != null ? `<span class="chip">BTC ρ${T.dg(r.corr)}</span>` : ''}${tf.squeeze ? '<span class="chip go">فشردگی</span>' : ''}</div></div>`; }).join('')}</div>`;
}
const sopt = (k, opts) => `<select data-scr="${k}">${opts.map(([v, n]) => `<option value="${v}" ${String(ST.scr[k]) === String(v) ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
const scch = (k, list) => `<div class="chips hs">${list.map(([v, n]) => `<button class="chip ${ST.scr[k] === v ? 'on' : ''}" data-act="scr" data-k="${k}" data-v="${v}">${n}</button>`).join('')}</div>`;
function oppHtml() {
  return card('فیلتر فرصت‌ها', 'target', `${scch('side', [['sig', 'همه سیگنال‌ها'], ['LONG', 'فقط خرید'], ['SHORT', 'فقط فروش'], ['all', 'همه ارزها']])}<div style="height:6px"></div>${scch('grade', [['any', 'هر درجه'], ['AB', 'A و B'], ['A', 'فقط A']])}
    <div class="row" style="margin-top:8px"><label class="note">مرتب‌سازی ${sopt('sort', [['cons', 'قدرت اجماع'], ['grade', 'درجه'], ['chg', 'تغییر ۲۴س'], ['vol', 'حجم'], ['ev', 'امید ریاضی'], ['atr', 'نوسان']])}</label><label class="note">حداقل |اجماع| ${sopt('min', [[0, 'همه'], [36, '۳۶'], [50, '۵۰'], [65, '۶۵']])}</label><label class="note">حداقل R:R ${sopt('rr', [[0, 'همه'], [1.5, '۱٫۵'], [2, '۲']])}</label></div>
    <input type="text" data-scr="q" placeholder="جستجوی نام ارز…" value="${esc(ST.scr.q)}" style="width:100%;margin-top:8px"></div>`) + '<div id="scr-res"></div>';
}
function breadthHtml() {
  const m = ST.market; if (!m) return card('نمای بازار', 'pulse', '<div class="empty"><div class="skel" style="max-width:260px;margin:auto"></div></div>');
  const tfr = Object.entries(m.per_tf).map(([tf, z]) => `<tr><td><b>${tf}</b></td><td><div class="bar"><i style="right:0;width:${z.above50}%;background:var(--a)"></i></div><span class="sm">${T.dg(z.above50)}٪</span></td><td><div class="bar"><i style="right:0;width:${z.above200}%;background:var(--b)"></i></div><span class="sm">${T.dg(z.above200)}٪</span></td><td class="up">${T.dg(z.long)}</td><td class="dn">${T.dg(z.short)}</td><td>${T.dg(z.rsi)}</td><td>${T.dg(z.adx)}</td></tr>`).join('');
  const lst = (arr, f) => `<div class="list">${arr.map(r => `<div class="li" data-sym="${r.symbol}"><div class="coin">${dot(r.base)}${esc(r.base)}</div><span class="sp"></span>${f(r)}</div>`).join('') || '<div class="empty">—</div>'}</div>`;
  const mood = m.mood, mt = mood >= 65 ? 'ریسک‌پذیری بالا' : mood >= 52 ? 'کمی خوش‌بین' : mood >= 40 ? 'خنثی' : mood >= 28 ? 'کمی بدبین' : 'ریسک‌گریزی شدید';
  return card('حال‌وهوای بازار', 'pulse', `<div class="row" style="justify-content:space-around;flex-wrap:nowrap"><div style="width:min(250px,60%)">${ch.gauge(m.avg_cons, 'میانگین اجماع', mt)}</div><div class="kpi" style="min-width:90px"><b style="color:${T.scol(m.avg_cons)}">${T.dg(mood)}</b><span>شاخص حال بازار (۰–۱۰۰)</span></div></div>`)
    + card('پهنای بازار به تفکیک تایم‌فریم', 'chart', `<div class="tw"><table><thead><tr><th>TF</th><th>بالای EMA50</th><th>بالای EMA200</th><th>خرید</th><th>فروش</th><th>RSI</th><th>ADX</th></tr></thead><tbody>${tfr}</tbody></table></div><div class="note">وقتی بیشتر ارزها بالای EMA200 و در تایم‌فریم‌های بزرگ‌اند، ستاپ‌های خرید شانس بهتری دارند (و برعکس).</div>`, 'w2')
    + `<div class="grid2">${card('بیشترین رشد ۲۴س', 'bolt', lst(m.gainers, r => `<span class="up">${T.fpct(r.chg, 1)}</span>`))}${card('بیشترین افت ۲۴س', 'bolt', lst(m.losers, r => `<span class="dn">${T.fpct(r.chg, 1)}</span>`))}${card('پرحجم‌ترین‌ها', 'wallet', lst(m.volume, r => `<span class="mu sm">${T.usd(r.qv)}</span>`))}${card('پرنوسان‌ترین‌ها (ATR٪)', 'pulse', lst(m.volatile, r => `<span>${T.dg(r.atr)}٪</span>`))}${card('فشردگی بولینگر (احتمال حرکت شدید)', 'target', lst(m.squeeze, r => `${T.badge(r.verdict)}`))}${card('ستاپ‌های برتر', 'bolt', lst(m.best, r => `${gchip(r.grade)}${T.badge(r.verdict)}`))}</div>`;
}
function corrHtml() {
  const m = ST.market, rows = rowsOf().filter(r => r.corr != null).sort((a, b) => b.corr - a.corr);
  const body = rows.map(r => `<tr data-sym="${r.symbol}"><td><div class="coin">${dot(r.base)}${esc(r.base)}</div></td><td style="color:${Math.abs(r.corr) > .8 ? 'var(--go)' : 'var(--tx)'}">${T.dg(r.corr)}</td><td>${T.dg(r.beta)}</td><td class="${r.rs24 >= 0 ? 'up' : 'dn'}">${T.fpct(r.rs24, 1)}</td></tr>`).join('');
  return card('ماتریس همبستگی (۱۰ ارز پرحجم، ۱۰۰ کندل ۱ساعته)', 'flow', m ? ch.corrmap(m.corr.names, m.corr.m) + '<div class="note">همبستگی بالا یعنی چند سیگنال هم‌جهت در عمل یک شرط‌بندی‌اند؛ ریسک را تقسیم نکنید.</div>' : '<div class="skel"></div>', 'w2')
    + card('نسبت هر ارز به بیت‌کوین', 'target', `<div class="tw"><table><thead><tr><th>ارز</th><th>همبستگی</th><th>بتا</th><th>قدرت نسبی ۲۴ک</th></tr></thead><tbody>${body || '<tr><td colspan="4" class="empty">پس از اسکن کامل نمایش داده می‌شود</td></tr>'}</tbody></table></div>`, 'w2');
}

/* ═══════════ FLOW (system schematic) ═══════════ */
const FINFO = {
  cache: ['کش و تیکر گروهی', 'یک درخواست گروهی برای همه قیمت‌ها (به‌جای ۴ درخواست برای هر ارز). کندل‌ها با TTL مخصوص هر تایم‌فریم کش می‌شوند و در قطعی منابع، تا ۱۵ دقیقه داده قدیمی با هشدار نمایش داده می‌شود.'],
  ind: ['۱۷ مولفه اندیکاتور', 'EMA، EMA200، سوپرترند، ADX/DI، MACD، RSI، ROC، واگرایی، استوکاستیک، بولینگر، OBV، حجم، VWAP، ساختار بازار، S/R و الگوهای کندلی؛ هرکدام امتیاز ‎−۱..+۱ دارند. فقط کندل‌های بسته‌شده استفاده می‌شوند (بدون repaint).'],
  regime: ['رژیم بازار', 'ADX رژیم را تعیین می‌کند: روندی (≥۲۵)، رنج (<۱۸) یا گذار. وزن گروه‌های اندیکاتور بر اساس رژیم تنظیم می‌شود؛ در روند، مومنتوم قوی‌تر و در رنج، بازگشت‌ها پررنگ‌ترند.'],
  mc: ['مونت‌کارلو', '۵۰۰ مسیر با بوت‌استرپ بازده‌های استانداردشده، نوسان EWMA، بازگشت به EMA21 و مومنتوم کوچک‌شده. خروجی: مسیر میانه، مخروط ۱۰–۹۰٪ و احتمال صعود؛ ثابت برای هر کندل (seed قطعی).'],
  levels: ['ساختار و سطوح', 'پیوت‌های سقف/کف برای حمایت و مقاومت و محاسبه حدضرر هوشمند (ترکیب ATR و کف/سقف سوینگ) و اهداف پله‌ای.'],
  fusion: ['فیوژن چندتایم‌فریم', 'اجماع وزنی ۱۵m/1h/4h/1d (۱۵/۲۵/۳۰/۳۰). اگر هر دو تایم‌فریم بزرگ مخالف باشند، وتو می‌شود و سیگنال به «انتظار» تبدیل می‌شود.'],
  dash: ['داشبورد نئون', 'همین رابط؛ کاملاً شخصی‌سازی‌پذیر از تب تنظیمات.'],
  paper: ['صرافی کاغذی', 'ریسک ۱٪ هر معامله (اهرم ریسک را ضرب نمی‌کند)، مدل لیکوئیدیشن، خروج پله‌ای ۴۰/۳۵/۲۵، انتقال استاپ به نقطه سر‌به‌سر، تشخیص سایه کندل، ذخیره اتمی با بکاپ.'],
  ai: ['Gemini (اختیاری)', 'نظر متنی هوش مصنوعی روی خروجی فیوژن. بدون کلید، خلاصه محلی نمایش داده می‌شود.'],
};

function flowHtml() {
  const s = ST.status || {}, src = s.sources || {}, names = ['mexc', 'binance', 'bybit', 'gate'];
  const nodes = [], N = (id, x, y, w, h, t, sub, o = {}) => nodes.push(Object.assign({ id, x, y, w, h, t, s: sub }, o));
  names.forEach((n, i) => { const h = src[n] || { ok: 0, fail: 0 }, bad = h.cooling || (h.ok === 0 && h.fail > 0); N('src-' + n, 10, 20 + i * 82, 150, 56, n.toUpperCase(), `${T.dg(h.ok)} موفق · ${T.dg(h.fail)} خطا`, { bad, tip: `${n.toUpperCase()} — تاخیر ${h.lat_ms || '—'}ms ${h.last_err ? '· ' + h.last_err : ''}` }); });
  N('cache', 215, 140, 150, 60, 'کش + تیکر گروهی', `${T.dg(s.cached || 0)} سری`, { busy: s.scanning }); N('ind', 420, 20, 150, 56, '۲۴ مولفه اندیکاتور', 'EMA·MACD·ایچیموکو·…'); N('regime', 420, 102, 150, 56, 'رژیم بازار', 'ADX → وزن‌دهی');
  N('mc', 420, 184, 150, 56, 'مونت‌کارلو ۳۲ کندل', '۶۰۰ مسیر · مخروط'); N('levels', 420, 266, 150, 56, 'ساختار و سطوح', 'S/R · فیبو · پیوت'); N('fusion', 625, 130, 140, 76, 'فیوژن MTF + درجه', 'اجماع وزنی + وتو', { col: 'var(--c)' });
  N('dash', 800, 30, 130, 56, 'داشبورد', 'نئون'); N('paper', 800, 140, 130, 56, 'صرافی کاغذی', 'ریسک ۱٪'); N('ai', 800, 250, 130, 56, 'Gemini', 'اختیاری', { col: 'var(--b)' });
  const E = []; names.forEach(n => E.push(['src-' + n, 'cache'])); ['ind', 'regime', 'mc', 'levels'].forEach(n => { E.push(['cache', n]); E.push([n, 'fusion']); }); ['dash', 'paper', 'ai'].forEach(n => E.push(['fusion', n]));
  const k = ST.flowSel, info = k.startsWith('src-') ? [k.slice(4).toUpperCase(), `منبع داده. ${(() => { const h = src[k.slice(4)] || {}; return `موفق ${h.ok || 0} · خطا ${h.fail || 0} · تاخیر ${h.lat_ms || '—'}ms · ${h.cooling ? 'در حالت استراحت (circuit breaker)' : 'فعال'} ${h.last_err ? '· آخرین خطا: ' + h.last_err : ''}`; })()}`] : (FINFO[k] || FINFO.ind);
  const st = [['آخرین اسکن', s.last_scan ? T.ago(Math.round(Date.now() / 1000 - s.last_scan)) : '—'], ['مدت اسکن', T.dg((s.duration || 0) + ' ثانیه')], ['سری‌های کش‌شده', T.dg(s.cached || 0)], ['نسخه', s.version || '—'], ['آستانه سیگنال', T.dg(s.threshold || '')]];
  const diagram = T.innerW() < 700
    ? `<div class="list">${nodes.map(n => `<div class="li ${n.id === k ? 'sel' : ''}" data-act="fnode" data-k="${n.id}"><span class="led ${n.bad ? 'bad' : n.busy ? 'busy' : 'ok'}"></span><b>${esc(n.t)}</b><span class="sp"></span><span class="mu sm">${esc(n.s || '')}</span></div>`).join('')}</div>`
    : `<div class="svgw">${ch.pipeline(nodes, E, k, motion())}</div>`;
  return card('نقشه سیستم', 'flow', diagram, '', '<small>روی هر مورد بزنید</small>') + card(esc(info[0]), 'shield', `<p style="margin:0;line-height:2">${esc(info[1])}</p>`) +
    `<div class="grid2">${card('وضعیت سیستم', 'pulse', `<div class="kv">${st.map(([a, b]) => `<span>${a}</span><b class="ltr">${esc(b)}</b>`).join('')}</div>`)}${card('خطاهای اخیر', 'shield', (s.errors || []).length ? `<ul class="note" style="margin:0;padding-inline-start:18px">${s.errors.map(e => `<li class="ltr">${esc(e)}</li>`).join('')}</ul>` : '<div class="empty">بدون خطا ✔</div>')}</div>`;
}
T.innerW = () => innerWidth;

R.mkt = function () {
  const el = $('#p-mkt'), tab = ST.tab.mkt;
  if (tab === 'opp') {
    if (el.dataset.tab !== 'opp') { el.dataset.tab = 'opp'; el._h = null; put(el, T.tabs('mkt', SCR_TABS) + oppHtml()); }
    put($('#scr-res'), scrResHtml()); return;
  }
  el.dataset.tab = tab; put(el, T.tabs('mkt', SCR_TABS) + (tab === 'breadth' ? breadthHtml() : tab === 'corr' ? corrHtml() : flowHtml()));
};

/* ═══════════ EXCHANGE ═══════════ */
function equityCurve(log, start) {
  if (!log || log.length < 2) return '<div class="empty">با ثبت معاملات، منحنی سرمایه اینجا رسم می‌شود.</div>';
  const v = log.map(x => x.eq), lo = Math.min(...v, start), hi = Math.max(...v, start), W = 600, H = 150, X = i => 4 + i / (v.length - 1) * (W - 8), Y = e => 12 + (1 - (e - lo) / ((hi - lo) || 1)) * (H - 24), col = v[v.length - 1] >= start ? 'var(--up)' : 'var(--dn)';
  const d = v.map((e, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)} ${Y(e).toFixed(1)}`).join('');
  return `<div class="eqw"><svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none"><defs><linearGradient id="eqg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".4"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs><path d="M4 ${Y(start)}H${W - 4}" stroke="var(--mu)" stroke-dasharray="4 4" opacity=".6" vector-effect="non-scaling-stroke"/><path d="${d}L${X(v.length - 1)} ${H}L4 ${H}Z" fill="url(#eqg)"/><path d="${d}" fill="none" stroke="${col}" stroke-width="2.4" vector-effect="non-scaling-stroke" style="filter:drop-shadow(0 0 calc(var(--glow)*6px) ${col})"/></svg><b style="color:${col}">${T.usd(v[v.length - 1])}</b></div>`;
}

/* ═══════════ smart auto-trader panel ═══════════ */
const REASON_FA = { stop: 'حدضرر', tp3: 'TP3', be: 'سر‌به‌سر', time: 'توقف زمانی', signal_flip: 'برعکس شدن سیگنال', manual: 'دستی', liq: 'لیکوئید', daily: 'سقف ضرر روزانه' };
function autoHtml(a) {
  const C = ST.autoCfg; if (!C) return card('ترید خودکار هوشمند', 'bolt', '<div class="skel"></div>');
  const cfg = C.cfg, ev = ST.evid || {}, agg = ev.agg || {}, ago = t => T.ago(Math.round(Date.now() / 1000 - t));
  const ctl = (k, l, step, mn) => `<label class="note" style="display:flex;flex-direction:column;gap:2px">${l}<input type="number" data-acfg="${k}" value="${cfg[k]}" step="${step}" min="${mn}" style="width:92px"></label>`;
  const orders = (a.orders || []).map(o => `<div class="alrt"><span>⏳</span><span>${esc(o.symbol.replace('USDT', ''))} ${T.badge(o.side)} · ${esc(o.plan || o.mode)} @ <b class="ltr">${T.fp(o.price)}</b> · SL ${T.fp(o.stop)}</span><span class="mu sm">تا ${T.ago(Math.max(0, Math.round(Date.now() / 1000 - o.expires)))} دیگر</span><span class="sp"></span><button class="btn dn ibtn" data-act="order-cancel" data-id="${esc(o.id)}">✕</button></div>`).join('') || '<div class="note">سفارش معلقی نیست.</div>';
  const log = (a.auto_log || []).slice().reverse().slice(0, 16).map(l => `<div class="alog"><b style="background:${l.ok ? 'var(--up)' : 'var(--dn)'}">${l.ok ? '✔' : '✕'}</b><span><b>${esc((l.symbol || '').replace('USDT', ''))}</b> ${l.grade ? `<span class="gr g${l.grade}">${l.grade}</span>` : ''} ${esc(l.text)} <span class="mu sm">· ${ago(l.t)}</span></span></div>`).join('') || '<div class="note">هنوز تصمیمی ثبت نشده؛ بعد از اسکن بعدی می‌آید.</div>';
  const evrows = Object.entries(ev.rows || {}).sort((x, y) => y[1].avg_r - x[1].avg_r).map(([s, r]) => `<tr><td>${esc(s.replace('USDT', ''))}</td><td>${T.dg(r.n)}</td><td>${T.dg(r.win)}٪</td><td style="color:${r.avg_r >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(r.avg_r)}R</td><td>${T.dg(r.t)}</td></tr>`).join('');
  return (a.paused ? `<div class="banner">⏸ ${esc(a.pause_reason)} <button class="btn" data-act="auto-resume" style="margin-inline-start:8px">ازسرگیری</button></div>` : '')
    + card('ترید خودکار هوشمند', 'bolt', `<div class="row sb"><label class="row"><button class="sw ${a.auto_trade ? 'on' : ''}" data-act="auto"></button><b>${a.auto_trade ? 'فعال' : 'خاموش'}</b></label><span class="chip">${T.dg(a.consec_losses || 0)} ضرر پیاپی</span></div>
      <div class="chips" style="margin:10px 0">${Object.entries(C.modes).map(([k, m]) => `<button class="chip ${cfg.mode === k ? 'on' : ''}" data-act="auto-mode" data-m="${k}">${esc(m.name)}</button>`).join('')}</div>
      <div class="row" style="align-items:flex-end">${ctl('risk_pct', 'ریسک هر معامله ٪', 0.1, 0.1)}${ctl('max_open', 'سقف پوزیشن', 1, 1)}${ctl('min_rr', 'حداقل R:R', 0.1, 1)}${ctl('min_ev', 'حداقل امید R', 0.01, -1)}${ctl('time_stop_h', 'توقف زمانی (ساعت)', 1, 4)}<label class="note" style="display:flex;flex-direction:column;gap:2px">حداقل درجه<select data-acfg="min_grade"><option ${cfg.min_grade === 'A' ? 'selected' : ''}>A</option><option ${cfg.min_grade === 'B' ? 'selected' : ''}>B</option><option ${cfg.min_grade === 'C' ? 'selected' : ''}>C</option></select></label></div>
      <div class="note" style="margin-top:10px;line-height:1.9">ربات فقط وقتی وارد می‌شود که <b>همه</b> شرط‌ها هم‌زمان برقرار باشد: درجه ستاپ، اجماع چندتایم‌فریم، هم‌سویی اندیکاتورها، امید ریاضی مثبت یک طرح مشخص (اغلب ورود در پولبک با سفارش معلق، نه تعقیب قیمت)، حجم کافی، بک‌تست گام‌به‌گام همان ارز، ریسک کل پورتفو، هم‌بستگی بین پوزیشن‌ها و هم‌جهتی با بیت‌کوین. خروج: ۳ هدف پله‌ای، سر‌به‌سر بعد از TP1، توقف زمانی برای معامله‌های بی‌حرکت، خروج زودهنگام اگر سیگنال برعکس شد، و توقف خودکار بعد از ۳ ضرر پیاپی. این روش ضرر را کم و گزینش را سخت‌گیرانه می‌کند ولی سود را تضمین نمی‌کند.</div>`, 'w2')
    + `<div class="grid2">${card(`سفارش‌های معلق (${T.dg((a.orders || []).length)})`, 'flow', orders)}${card('چرا باز شد / چرا باز نشد؟', 'brain', log)}</div>`
    + card('شواهد بک‌تست هر ارز', 'chart', (agg.coins ? `<div class="kv"><span>ارزهای آزمون‌شده</span><b>${T.dg(agg.coins)}</b><span>مجموع معامله‌ها</span><b>${T.dg(agg.trades)}</b><span>میانگین R همه</span><b style="color:${agg.avg_r >= 0 ? 'var(--up)' : 'var(--dn)'}">${T.dg(agg.avg_r)}R</b><span>ارزهای با میانگین مثبت</span><b>${T.dg(agg.positive)} از ${T.dg(agg.coins)}</b></div>` : '<div class="note">در حال محاسبه روی تاریخچه ۵۰۰ کندلی هر ارز (چند دقیقه اول)…</div>') + (evrows ? `<details class="why"><summary>جدول همه ارزها</summary><div class="tw"><table><thead><tr><th>ارز</th><th>معامله</th><th>برد</th><th>میانگین</th><th>t</th></tr></thead><tbody>${evrows}</tbody></table></div></details>` : '') + '<div class="note">ارزی که بک‌تست گام‌به‌گامش منفی باشد به‌صورت خودکار مسدود می‌شود.</div>', 'w2');
}

R.ex = function () {
  const el = $('#p-ex'), a = ST.acct; if (!a) { el.innerHTML = card('صرافی کاغذی', 'wallet', '<div class="empty"><div class="skel" style="max-width:260px;margin:auto"></div></div>'); return; }
  const k = (v, l, c) => `<div class="kpi"><b style="color:${c || 'var(--tx)'}">${v}</b><span>${l}</span></div>`, pc = v => v >= 0 ? 'var(--up)' : 'var(--dn)', S = a.stats || {};
  const pos = a.open_positions.map(p => { const r = ST.matrix[p.symbol], px = r && r.ticker ? r.ticker.price : p.entry, d = p.side === 'LONG' ? 1 : -1, lo = Math.min(p.stop0 || p.stop, p.tp3), hi = Math.max(p.stop0 || p.stop, p.tp3), pos = v => Math.max(0, Math.min(100, (v - lo) / (hi - lo) * 100)), pnl = (px - p.entry) * p.qty_left * d + p.realized;
    return `<div class="pos"><div class="row sb"><div class="coin">${dot(p.symbol.replace('USDT', ''))}${p.symbol.replace('USDT', '')} ${T.badge(p.side)}<span class="chip">×${T.dg(p.leverage)}</span>${p.stage ? `<span class="chip up">TP${T.dg(p.stage)} ✔</span>` : ''}${p.source === 'auto' ? '<span class="chip">خودکار</span>' : ''}</div><b style="color:${pc(pnl)}">${T.usd(pnl)}</b></div>
    <div style="position:relative;margin:14px 0 8px" class="bar"><i style="left:0;width:100%;background:linear-gradient(90deg,var(--dn),var(--mu) 50%,var(--up));opacity:${p.side === 'LONG' ? 1 : 0};transform:none"></i><i style="left:0;width:100%;background:linear-gradient(270deg,var(--dn),var(--mu) 50%,var(--up));opacity:${p.side === 'SHORT' ? 1 : 0}"></i></div>
    <div style="position:relative;height:16px;margin-top:-22px" data-tip="ورود ${T.fp(p.entry)} · الان ${T.fp(px)}"><span style="position:absolute;left:${pos(p.entry)}%;top:0;width:2px;height:16px;background:var(--a)"></span><span style="position:absolute;left:calc(${pos(px)}% - 6px);top:2px;width:12px;height:12px;border-radius:50%;background:var(--go);box-shadow:0 0 calc(var(--glow)*10px) var(--go)"></span></div>
    <div class="row sb note ltr"><span class="dn">SL ${T.fp(p.stop)}</span><span>${T.fp(px)}</span><span class="up">TP3 ${T.fp(p.tp3)}</span></div><div class="row sb note"><span>مارجین ${T.usd(p.margin_left)} · لیکوئید ${T.fp(p.liq)}</span><button class="btn dn" data-act="close" data-id="${esc(p.id)}">بستن</button></div></div>`; }).join('') || '<div class="empty">پوزیشن بازی وجود ندارد.</div>';
  const hist = a.history.slice().reverse().map(h => `<tr><td>${esc(h.symbol.replace('USDT', ''))}</td><td>${T.badge(h.side)}</td><td style="color:${pc(h.pnl)}">${T.usd(h.pnl)}</td><td>${T.dg(h.r || 0)}R</td><td class="mu">${esc(REASON_FA[h.reason] || h.reason)}</td></tr>`).join('');
  put(el, (a.notice ? `<div class="card" style="border-color:var(--go)">⚠ ${esc(a.notice)}</div>` : '') + card('حساب کاغذی', 'wallet', `<div class="kpis">${k(T.usd(a.equity), 'سرمایه کل', pc(a.equity - a.starting))}${k(T.usd(a.wallet), 'موجودی آزاد')}${k(T.usd(a.unrealized_pnl), 'سود/زیان باز', pc(a.unrealized_pnl))}${k(T.usd(a.day_pnl), 'امروز', pc(a.day_pnl))}${k(T.dg(a.win_rate) + '٪', `نرخ برد (${T.dg(a.trades)} معامله)`)}${k(T.dg(a.max_drawdown_pct) + '٪', 'افت سرمایه', a.max_drawdown_pct > 0 ? 'var(--dn)' : 'var(--mu)')}</div>
    <div class="svgw" style="margin-top:12px">${equityCurve(a.equity_log, a.starting)}</div><div class="row sb" style="margin-top:10px"><span class="note">ترید خودکار از کارت «ترید خودکار هوشمند» پایین کنترل می‌شود.</span><button class="btn dn" data-act="reset">ریست حساب</button></div>`) +
    autoHtml(a) + `<div class="grid2">${card('آمار عملکرد', 'pulse', `<div class="kv"><span>ضریب سود (PF)</span><b>${T.dg(S.profit_factor)}</b><span>امید ریاضی هر معامله</span><b style="color:${pc(S.expectancy)}">${T.usd(S.expectancy)}</b><span>میانگین R</span><b>${T.dg(S.avg_r)}R</b><span>میانگین برد / باخت</span><b>${T.usd(S.avg_win)} / ${T.usd(S.avg_loss)}</b><span>بهترین / بدترین</span><b>${T.usd(S.best)} / ${T.usd(S.worst)}</b><span>سری اخیر</span><b>${T.dg(S.streak)}</b><span>کارمزد کل</span><b>${T.usd(a.total_fees)}</b></div>`)}${card('پوزیشن‌های باز (' + T.dg(a.open_positions.length) + ')', 'bolt', pos)}</div>` +
    card('تحلیل معاملات', 'brain', (() => { const h = a.history || []; if (h.length < 3) return '<div class="empty">پس از چند معامله، تفکیک نتایج اینجا می‌آید.</div>'; const grp = f => { const m = {}; h.forEach(x => { const k = f(x); (m[k] = m[k] || []).push(x); }); return Object.entries(m).map(([k, v]) => ({ k, n: v.length, win: Math.round(v.filter(z => z.pnl > 0).length / v.length * 100), r: v.reduce((q, z) => q + (z.r || 0), 0) / v.length, pnl: v.reduce((q, z) => q + z.pnl, 0) })).sort((p, q) => q.n - p.n); };
      const tb = (title, rows) => `<div class="note" style="margin:8px 0 4px"><b>${title}</b></div><div class="tw"><table><thead><tr><th></th><th>تعداد</th><th>برد</th><th>میانگین R</th><th>مجموع</th></tr></thead><tbody>${rows.slice(0, 6).map(g => `<tr><td>${esc(g.k)}</td><td>${T.dg(g.n)}</td><td>${T.dg(g.win)}٪</td><td style="color:${pc(g.r)}">${T.dg(g.r.toFixed(2))}</td><td style="color:${pc(g.pnl)}">${T.usd(g.pnl)}</td></tr>`).join('')}</tbody></table></div>`;
      return tb('بر اساس سمت', grp(x => T.SIDE_FA[x.side] || x.side)) + tb('بر اساس دلیل خروج', grp(x => x.reason)) + tb('بر اساس ارز', grp(x => x.symbol.replace('USDT', ''))); })(), 'w2') +
    card('تاریخچه معاملات', 'chart', `<div class="tw"><table><thead><tr><th>ارز</th><th>سمت</th><th>سود</th><th>R</th><th>دلیل خروج</th></tr></thead><tbody>${hist || '<tr><td colspan="5" class="empty">هنوز معامله‌ای بسته نشده</td></tr>'}</tbody></table></div>`));
};

/* ═══════════ SETTINGS STUDIO (v2.2) ═══════════ */
const OPEN = ST.open = { theme: true, glass: true };
let built = false;
const fld = (l, c) => `<div class="fld"><label>${l}</label>${c}</div>`;
const rng = (p, mn, mx, st, v) => `<span class="row" style="flex-wrap:nowrap;justify-content:flex-end;flex:1"><input type="range" data-set="${p}" min="${mn}" max="${mx}" step="${st}" value="${v}"><b data-val="${p}" style="min-width:34px;text-align:center">${v}</b></span>`;
const sel = (p, opts, v) => `<select data-set="${p}">${opts.map(([k, n]) => `<option value="${k}" ${String(v) === String(k) ? 'selected' : ''}>${n}</option>`).join('')}</select>`;
const sw = (p, v) => `<button class="sw ${v ? 'on' : ''}" data-act="sw" data-path="${p}"></button>`;
const sec = (id, title, ic, body) => `<details class="set-sec" data-sec="${id}" ${OPEN[id] ? 'open' : ''}><summary>${ICON(ic)}${title}</summary><div>${body}</div></details>`;
const TH = {
  neon: '<div class="skth" style="background:linear-gradient(160deg,#05070f,#0b1226)"><i style="left:8%;top:12%;width:84%;height:26%;border:1px solid #00f0ff;border-radius:7px;background:rgba(0,240,255,.08);box-shadow:0 0 8px rgba(0,240,255,.5)"></i><i style="left:8%;top:44%;width:40%;height:24%;border:1px solid #8b5cf6;border-radius:7px"></i><i style="left:52%;top:44%;width:40%;height:24%;border:1px solid #ff2bd6;border-radius:7px"></i><i style="left:20%;bottom:5%;width:60%;height:11%;border-radius:9px;border:1px solid #00f0ff;background:rgba(0,0,0,.4)"></i></div>',
  terminal: '<div class="skth" style="background:#000"><i style="left:0;top:0;width:100%;height:9%;background:#ffb000;opacity:.85"></i>' + [20, 31, 42, 53, 64].map(y => `<i style="left:5%;top:${y}%;width:90%;height:5%;background:#ffb000;opacity:${y % 2 ? .35 : .6}"></i>`).join('') + '<i style="left:0;bottom:0;width:100%;height:11%;border-top:1px solid #ffb000"></i></div>',
  cockpit: '<div class="skth" style="background:#0e1116"><i style="right:0;top:0;width:11%;height:100%;background:#161b22;border-left:1px solid #30363d"></i><i style="left:4%;top:10%;width:26%;height:36%;border-top:2px solid #58a6ff;background:#161b22"></i><i style="left:33%;top:10%;width:26%;height:36%;border-top:2px solid #58a6ff;background:#161b22"></i><i style="left:62%;top:10%;width:26%;height:36%;border-top:2px solid #58a6ff;background:#161b22"></i><i style="left:4%;top:52%;width:55%;height:38%;border-top:2px solid #3fb950;background:#161b22"></i><i style="left:62%;top:52%;width:26%;height:38%;border-top:2px solid #f0883e;background:#161b22"></i></div>',
  paper: '<div class="skth" style="background:#f6f4ef"><i style="left:8%;top:12%;width:84%;height:30%;background:#fff;border-radius:8px;box-shadow:0 3px 9px rgba(20,30,60,.14)"></i><i style="left:8%;top:48%;width:84%;height:30%;background:#fff;border-radius:8px;box-shadow:0 3px 9px rgba(20,30,60,.14)"></i><i style="left:8%;top:18%;width:30%;height:3px;background:#1f6feb"></i><i style="left:20%;bottom:4%;width:60%;height:3px;background:#1d2433;opacity:.5"></i></div>',
  app: '<div class="skth" style="background:linear-gradient(160deg,#04121a,#0a2a3a 60%,#1b1646)">' + [8, 27, 46, 65].map((x, i) => `<i style="left:${x}%;top:8%;width:17%;height:26%;border-radius:50%;border:2px solid ${['#38ffb4', '#ff5d8f', '#4d7cff', '#d36bff'][i]}"></i>`).join('') + '<i style="left:6%;top:42%;width:88%;height:48%;border-radius:14px;background:rgba(255,255,255,.1)"></i></div>',
  chart: '<div class="skth" style="background:#0a0b0e"><i style="left:0;top:0;width:100%;height:8%;background:#14161c"></i>' + [12, 20, 28, 36, 44, 52, 60, 68, 76].map((x, i) => `<i style="left:${x}%;top:${[52, 44, 48, 36, 40, 28, 34, 24, 30][i]}%;width:5%;height:${[22, 28, 20, 30, 24, 32, 22, 30, 24][i]}%;background:${i % 3 === 1 ? '#fb7185' : '#5eead4'};border-radius:1px"></i>`).join('') + '<i style="left:0;bottom:0;width:100%;height:11%;background:#14161c"></i></div>',
};
Object.assign(TH, {
  prism: '<div class="skth" style="background:linear-gradient(160deg,#04061a,#0c1238 40%,#1a0a30)"><i style="left:12%;top:14%;width:34%;height:28%;border-radius:10px;border:1.5px solid transparent;background:linear-gradient(#0c1238,#0c1238) padding-box,linear-gradient(135deg,#22d3ee,#c084fc,#fb7185) border-box;opacity:.95"></i><i style="left:52%;top:18%;width:28%;height:22%;border-radius:8px;background:rgba(192,132,252,.2);border:1px solid #c084fc"></i><i style="left:18%;top:52%;width:64%;height:30%;border-radius:12px;background:rgba(34,211,238,.12);border:1px solid rgba(255,255,255,.2)"></i><i style="left:8%;bottom:8%;width:10px;height:10px;background:#22d3ee;transform:rotate(45deg);border-radius:1px"></i><i style="right:12%;bottom:14%;width:12px;height:12px;border:2px solid #fb7185;border-radius:50%"></i></div>',
  pulse: '<div class="skth" style="background:linear-gradient(160deg,#020617,#0c1a3a)"><i style="inset:20%;border:1px solid #22d3ee;border-radius:10px;background:rgba(34,211,238,.12)"></i></div>',
  forge: '<div class="skth" style="background:linear-gradient(160deg,#050508,#12121a)"><i style="inset:18%;border:1px solid #94a3b8;border-radius:4px;background:rgba(148,163,184,.1)"></i></div>',
  mica: '<div class="skth" style="background:linear-gradient(160deg,#0b0f1a,#16213a)"><i style="inset:18%;border:1px solid #60cdff;border-radius:8px;background:rgba(96,205,255,.12)"></i></div>',
  royal: '<div class="skth" style="background:linear-gradient(160deg,#0c0118,#1e0a3c)"><i style="inset:18%;border:1px solid #c084fc;border-radius:12px;background:rgba(192,132,252,.12)"></i></div>',
  ember: '<div class="skth" style="background:linear-gradient(160deg,#1a0505,#3b0a0a)"><i style="inset:18%;border:1px solid #fb923c;border-radius:8px;background:rgba(251,146,60,.12)"></i></div>'
});

R.set = function (force) {
  if (built && !force) return; built = true;
  const U = T.UI, P = T.palette(), y = $('#p-set').scrollTop, hex = v => /^#[0-9a-f]{6}$/i.test(v) ? v : '#888888', CL = U.chart.layers, CP = U.chart.panes;
  const pickers = [['a', 'رنگ اصلی (نئون ۱)'], ['b', 'رنگ دوم (نئون ۲)'], ['c', 'رنگ سوم (تاکید)'], ['up', 'رنگ صعود'], ['dn', 'رنگ نزول'], ['go', 'رنگ هشدار'], ['fu', 'کندل آینده صعودی'], ['fd', 'کندل آینده نزولی'], ['bg1', 'پس‌زمینه ۱'], ['bg2', 'پس‌زمینه ۲'], ['tx', 'رنگ متن']];
  const wl = ST.syms.map(s => `<span class="chip">${s.replace('USDT', '')} <b data-act="wl-del" data-s="${s}" style="cursor:pointer;color:var(--dn)">✕</b></span>`).join('');
  const hw = U.home.map((w, i) => `<div class="wrow"><span>${esc((T.WIDGETS.find(x => x.id === w.id) || {}).n)}</span><button class="btn ibtn" data-act="hw-wide" data-i="${i}" data-tip="عرض ویجت">${w.wide === 1 ? '▭▭' : w.wide === 0 ? '▭' : 'A'}</button><button class="btn ibtn" data-act="hw-up" data-i="${i}">▲</button><button class="btn ibtn" data-act="hw-dn" data-i="${i}">▼</button>${sw('home.' + i + '.on', w.on)}</div>`).join('');
  const profs = T.profiles().map(p => `<div class="prof"><b>${esc(p.name)}</b><span class="sp"></span><button class="btn" data-act="prof-apply" data-n="${esc(p.name)}">اعمال</button><button class="btn dn ibtn" data-act="prof-del" data-n="${esc(p.name)}">✕</button></div>`).join('') || '<div class="note">هنوز پروفایلی ذخیره نشده.</div>';
  const lay = [['ema', 'EMA 9/21/50'], ['e200', 'EMA 200'], ['bb', 'بولینگر'], ['vwap', 'VWAP'], ['ich', 'ایچیموکو'], ['st', 'سوپرترند'], ['sr', 'حمایت/مقاومت'], ['pv', 'پیوت'], ['fib', 'فیبوناچی'], ['vp', 'پروفایل حجم'], ['lv', 'ورود/SL/TP'], ['fc', 'کندل‌های آینده'], ['vol', 'حجم'], ['pat', 'الگوها']];
  $('#p-set').innerHTML =
    sec('theme', '۲۰ تم پریسم شیشه‌ای', 'pulse',
      `<div class="theme-grid">${(T.PRESETS || []).map(p => {
        const on = U.preset === p.id ? 'on' : '';
        return `<button type="button" class="theme-swatch ${on}" data-act="preset" data-id="${p.id}" style="background:linear-gradient(145deg,${p.bg1},${p.a  || p.m1 || '#38ffd4'})"><span>${esc(p.name)}</span></button>`;
      }).join('')}</div>
      <div class="note">تنها رابط: <b>پریسم شیشه‌ای</b>. با انتخاب هر تم، رنگ‌ها در کل داشبورد اعمال می‌شوند.</div>`) +
    sec('glass', 'شیشه و نور', 'bolt',
      fld('درخشش (Glow)', rng('glow', 0, 2.5, 0.05, U.glow)) +
      fld('محو شیشه (Blur px)', rng('blur', 0, 40, 1, U.blur)) +
      fld('شفافیت شیشه', rng('glassA', 0.15, 0.95, 0.01, U.glassA)) +
      fld('هایلایت لبه', rng('hls', 0, 1.2, 0.05, U.hls)) +
      fld('اشباع رنگ', rng('sat', 0.6, 2.4, 0.05, U.sat)) +
      fld('عمق سایه', rng('shd', 0, 2, 0.05, U.shd)) +
      fld('درخشش متن', rng('tglow', 0, 1.5, 0.05, U.tglow)) +
      fld('ضخامت لبه (px)', rng('bw', 0, 3, 0.5, U.bw)) +
      fld('درخشش پریسم', rng('prismShine', 0, 1.5, 0.05, U.prismShine ?? 0.7)) +
      fld('قدرت لبه پریسم', rng('prismBorder', 0.4, 2.5, 0.1, U.prismBorder ?? 1.2)) +
      fld('نویز فیلم (Grain)', sw('grain', !!U.grain))) +
    sec('layout', 'چیدمان داشبورد', 'flow',
      fld('تراکم', sel('density', [['compact', 'فشرده'], ['comfy', 'معمولی'], ['roomy', 'راحت']], U.density)) +
      fld('ستون‌های خانه', sel('cols', [['auto', 'خودکار'], ['1', '۱ ستون'], ['2', '۲ ستون'], ['3', '۳ ستون']], U.cols)) +
      fld('سبک کارت', sel('card', [['prism', 'پریسم شیشه‌ای'], ['glass', 'شیشه‌ای'], ['neon', 'نئونی']], U.card)) +
      fld('گردی گوشه‌ها (px)', rng('radius', 0, 36, 1, U.radius)) +
      fld('فاصله کارت‌ها', rng('gapScale', 0.6, 1.8, 0.1, U.gapScale ?? 1)) +
      fld('پدینگ کارت', rng('cardPad', 0.7, 1.6, 0.1, U.cardPad ?? 1)) +
      fld('مقیاس KPI', rng('kpiScale', 0.75, 1.4, 0.05, U.kpiScale ?? 1)) +
      fld('اندازه سلول حرارتی', rng('heatSize', 40, 72, 2, U.heatSize ?? 52)) +
      fld('حداکثر عرض صفحه', sel('maxw', [[900, '۹۰۰'], [1100, '۱۱۰۰'], [1320, '۱۳۲۰'], [1600, '۱۶۰۰'], [1920, '۱۹۲۰'], [3000, 'تمام‌عرض']], U.maxw)) +
      fld('تایم‌فریم پیش‌فرض', sel('defTf', ST.tfs.map(tf => [tf, tf]), U.defTf)) +
      `<div class="note" style="padding:8px 0 2px">ویجت‌های صفحه خانه:</div>${hw}`) +
    sec('bgmot', 'پس‌زمینه و حرکت', 'radar',
      fld('پس‌زمینه', sel('bg', [['shapes', 'اشکال هندسی'], ['mesh', 'مش رنگی'], ['aurora', 'شفق'], ['grid', 'شبکه'], ['none', 'ساده']], U.bg)) +
      fld('شفافیت پس‌زمینه', rng('bgop', 0.15, 1, 0.05, U.bgop)) +
      fld('تاریکی تصویر پس‌زمینه', rng('bgdim', 0.2, 0.9, 0.05, U.bgdim)) +
      fld('قدرت اشکال', rng('shapeOp', 0.15, 1, 0.05, U.shapeOp ?? 0.55)) +
      fld('سرعت اشکال', rng('shapeSpeed', 0.3, 2, 0.1, U.shapeSpeed ?? 1)) +
      fld('قدرت مش', rng('meshOp', 0.1, 1, 0.05, U.meshOp ?? 0.4)) +
      fld('حرکت', sel('motion', [['on', 'روشن'], ['off', 'خاموش'], ['auto', 'خودکار']], U.motion)) +
      fld('سرعت انیمیشن', rng('speed', 0.25, 3, 0.05, U.speed)) +
      fld('انتقال صفحات', sel('anim', [['fade', 'محو'], ['slide', 'لغزش'], ['zoom', 'بزرگ‌نمایی'], ['none', 'بدون']], U.anim)) +
      fld('خط اسکن', sw('scan', !!U.scan))) +
    sec('type', 'متن و کنترل‌ها', 'gear',
      fld('اندازه متن (px)', rng('fs', 12, 20, 1, U.fs)) +
      fld('فونت', sel('font', Object.keys(T.FONTS || {}).map(k => [k, k]), U.font)) +
      fld('وزن فونت', rng('weight', 300, 700, 50, U.weight || 400)) +
      fld('فاصله خطوط', sel('lh', [['tight', 'فشرده'], ['normal', 'معمولی'], ['loose', 'باز']], U.lh)) +
      fld('اندازه آیکون', sel('icons', [['small', 'کوچک'], ['normal', 'معمولی'], ['large', 'بزرگ']], U.icons)) +
      fld('برچسب ناوبری', sel('labels', [['on', 'نمایش'], ['off', 'مخفی']], U.labels)) +
      fld('ارقام هم‌عرض', sw('tnum', !!U.tnum)) +
      fld('ارقام', sel('digits', [['en', 'انگلیسی'], ['fa', 'فارسی']], U.digits)) +
      fld('سبک دکمه', sel('btn', [['solid', 'توپر'], ['glass', 'شیشه‌ای'], ['outline', 'خط‌دار'], ['neon', 'نئونی']], U.btn)) +
      fld('سبک چیپ', sel('chip', [['pill', 'کپسولی'], ['square', 'مربعی'], ['ghost', 'خط‌زیر']], U.chip)) +
      fld('ناوبری', sel('nav', [['bottom', 'پایین'], ['side', 'کناری']], U.nav)) +
      fld('سبک تب‌ها', sel('tabs', [['pill', 'کپسولی'], ['underline', 'خط‌زیر'], ['segment', 'سگمنت'], ['box', 'جعبه‌ای']], U.tabs)) +
      fld('هدر', sel('header', [['full', 'کامل'], ['compact', 'فشرده'], ['ticker', 'نوار قیمت'], ['minimal', 'حداقلی']], U.header)) +
      fld('اسکرول‌بار', sel('scroll', [['thin', 'نازک'], ['neon', 'نئونی'], ['hidden', 'مخفی']], U.scroll))) +
    sec('colors', 'رنگ‌های دستی (روی تم)', 'palette',
      pickers.map(([k, n]) => fld(n, `<input type="color" data-set="colors.${k}" value="${hex((U.colors && U.colors[k]) || P[k] || '#888888')}">`)).join('') +
      `<div class="row" style="margin-top:8px"><button class="btn" data-act="colors-reset">بازنشانی رنگ‌های دستی</button></div>`) +
    sec('chart', 'نمودار', 'chart',
      fld('ارتفاع نمودار', rng('chartH', 0.7, 1.6, 0.05, U.chartH ?? 1)) +
      fld('تعداد کندل', sel('chartN', [[0, 'خودکار'], [30, '۳۰'], [60, '۶۰'], [90, '۹۰'], [140, '۱۴۰']], U.chartN ?? 0)) +
      fld('نوع کندل', sel('candle', [['solid', 'توپر'], ['hollow', 'توخالی'], ['bars', 'میله'], ['line', 'خطی']], U.candle || 'solid')) +
      fld('شبکه', sw('grid', U.grid !== 0 && U.grid !== false)) +
      fld('ضخامت سایه', rng('wick', 0.8, 2.2, 0.1, U.wick ?? 1.4)) +
      fld('مخروط پیش‌بینی', sel('cone', [['fill', 'پر'], ['lines', 'خطوط'], ['none', 'بدون']], U.cone)) +
      fld('کراس‌هیر', sel('crossStyle', [['dash', 'خط‌چین'], ['solid', 'توپر'], ['dot', 'نقطه']], U.crossStyle)) +
      fld('نمودارک لیست‌ها', sel('homeMini', [['candles', 'کندل'], ['line', 'خطی']], U.homeMini)) +
      `<div class="note" style="padding:8px 0 2px">لایه‌های پیش‌فرض:</div>` + lay.map(([k, n]) => fld(n, sw('chart.layers.' + k, !!CL[k]))).join('') +
      `<div class="note" style="padding:8px 0 2px">پنل‌های زیر نمودار:</div>` + [['rsi', 'RSI'], ['macd', 'MACD'], ['srsi', 'StochRSI']].map(([k, n]) => fld(n, sw('chart.panes.' + k, !!CP[k]))).join('')) +
    sec('watch', 'واچ‌لیست و اسکن', 'radar',
      `<div class="chips">${wl || '<span class="note">خالی</span>'}</div>
      <div class="row" style="margin-top:8px"><input type="text" id="wl-add" placeholder="مثلاً SOL یا BTCUSDT" style="flex:1"><button class="btn pri" data-act="wl-add">افزودن</button></div>
      <div class="row" style="margin-top:8px"><label class="mu">بازه اسکن (ثانیه)</label><input type="number" id="scan-sec" min="30" max="600" value="${(ST.status && ST.status.scan_sec) || 90}" style="width:90px"><button class="btn" data-act="scan-sec">ثبت</button></div>
      <div class="note">حداکثر ۴۰ ارز. داده و حافظه فقط در پوشه VVV.</div>`) +
    sec('a11y', 'دسترسی‌پذیری', 'shield',
      fld('جابه‌جایی رنگ صعود/نزول', sw('swapUD', !!U.swapUD)) +
      fld('عملکرد', sel('perf', [['auto', 'خودکار'], ['high', 'کامل'], ['low', 'سبک']], U.perf || 'auto')) +
      fld('صدا هشدار', sw('alertSound', !!U.alertSound)) +
      fld('ویبره هشدار', sw('alertVib', !!U.alertVib)) +
      fld('اعلان مرورگر', sw('alertNotify', !!U.alertNotify))) +
    sec('prof', 'پروفایل‌های ذخیره‌شده', 'gear',
      `<div class="row"><input type="text" id="prof-name" placeholder="نام پروفایل (مثلاً «شب»)" style="flex:1"><button class="btn pri" data-act="prof-save">ذخیره ظاهر فعلی</button></div>
      <div style="margin-top:10px">${profs}</div>`) +
    sec('tools', 'پشتیبان و بازنشانی', 'gear',
      `<div class="row"><button class="btn" data-act="export">کپی تنظیمات</button><button class="btn" data-act="download">دانلود JSON</button><button class="btn dn" data-act="ui-reset">بازنشانی کامل ظاهر</button></div>
      <textarea id="imp" rows="4" placeholder="تنظیمات JSON را اینجا بچسبانید…" style="width:100%;margin-top:10px"></textarea>
      <button class="btn pri" data-act="import" style="margin-top:8px">اعمال تنظیمات واردشده</button>
      <div class="note" style="margin-top:8px">رابط فقط پریسم شیشه‌ای است · داده در UUU/VVV · AI فقط Gemini.</div>`);

  $('#p-set').scrollTop = y;
};
document.addEventListener('toggle', e => { const s = e.target.dataset && e.target.dataset.sec; if (s) OPEN[s] = e.target.open; }, true);

/* ═══════════ actions ═══════════ */
const A = T.acts, post = (u, b) => T.api(u, { method: 'POST', body: JSON.stringify(b || {}) });
Object.assign(A, {
  noop: () => { }, reload: () => T.loadCoin(ST.sel),
  dt: t => { ST.dtSel = ST.dtSel === t.dataset.k ? null : t.dataset.k; R.coin(); },
  fnode: t => { ST.flowSel = t.dataset.k; R.mkt(); },
  layer: t => { const L = T.UI.chart.layers, k = t.dataset.k; L[k] = L[k] ? 0 : 1; T.saveUI(); R.chart(); },
  pane: t => { const P = T.UI.chart.panes, k = t.dataset.k; P[k] = P[k] ? 0 : 1; T.saveUI(); chKey = ''; R.chart(); },
  zin: () => chart && chart.zoom(.8), zout: () => chart && chart.zoom(1.25), zr: () => chart && chart.reset(),
  fs: () => { const m = $('#ch-main'); m.classList.toggle('ch-full'); document.body.classList.toggle('noscroll', m.classList.contains('ch-full')); chKey = ''; R.chart(); },
  png: async () => { if (!chart) return; const b = await chart.png(); if (!b) return; const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = `${ST.sel}-${ST.tf}.png`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 3000); },
  scr: t => { ST.scr[t.dataset.k] = t.dataset.v; $('#p-mkt').dataset.tab = ''; R.mkt(); },
  'micro-reload': () => T.loadMicro(ST.sel, true), 'bt-run': () => T.loadBt(),
  'hw-wide': t => { const w = T.UI.home[+t.dataset.i]; w.wide = w.wide === undefined ? 1 : w.wide === 1 ? 0 : undefined; if (w.wide === undefined) delete w.wide; T.saveUI(); R.set(true); T.render(); },
  'bgimg-clear': () => { localStorage.removeItem('titan.bgimg'); T.applyUI(); T.toast('حذف شد'); },
  'candle-reset': () => { T.UI.candleUp = ''; T.UI.candleDn = ''; T.saveUI(); R.set(true); T.render(); },
  'auto-mode': async t => { await post('/api/auto/config', { mode: t.dataset.m }); T.loadAuto(); },
  'auto-resume': async () => { await post('/api/auto/resume', {}); T.loadAuto(); T.loadAcct(); },
  'order-cancel': async t => { await post('/api/order/cancel', { id: t.dataset.id }); T.loadAcct(); },
  'plan-side': t => { ST.planSide = t.dataset.v; T.render(); },
  'plan-reload': () => T.loadPlan(true),
  'plan-order': async t => { const L = ST.planLab; if (!L) return; const side = ST.planSide || (ST.deep && ST.deep.verdict && ST.deep.verdict !== 'WAIT' ? ST.deep.verdict : (L.verdict_side !== 'WAIT' ? L.verdict_side : 'LONG')), row = (side === 'LONG' ? L.long : L.short).rows[+t.dataset.i]; if (!row) return;
    const r = await post('/api/order', { symbol: ST.sel, side, mode: row.mode, price: row.p, stop: row.stop, tp1: row.tp1, tp2: row.tp2, tp3: row.tp3, risk_pct: 0.7, valid_h: +(($('#pl-valid') || {}).value || 8), plan: row.name, leverage: 10, deadline_h: 24 });
    T.toast(r.ok ? (row.mode === 'market' ? 'پوزیشن کاغذی باز شد' : 'سفارش معلق ثبت شد') : (r.error || 'ناموفق')); T.loadAcct(); },
  skin: t => T.applySkin(t.dataset.id),
  showpat: () => { T.UI.chart.layers.pat = 1; T.saveUI(); ST.tab.chart = 'main'; chKey = ''; T.go('chart'); T.render(); },
  'pat-reload': () => T.loadPat(ST.sel, true),
  hsel: t => T.loadCoin(t.dataset.s),
  goalerts: () => { if (!ST.sel && ST.syms.length) T.loadCoin(ST.syms[0]); ST.tab.coin = 'alerts'; T.go('coin'); },
  'al-fill': t => { const i = $('#al-price'); if (i) i.value = (+t.dataset.v).toPrecision(7).replace(/\.?0+$/, ''); },
  'al-add-price': async () => { const r = await post('/api/alerts', { type: 'price', symbol: ST.sel, op: $('#al-op').value, price: +$('#al-price').value }); if (r.error) return T.toast(r.error); T.toast('هشدار ثبت شد'); T.loadAlerts(); },
  'al-add-sig': async () => { const r = await post('/api/alerts', { type: 'signal', symbol: $('#al-scope').value, min_grade: $('#al-grade').value }); if (r.error) return T.toast(r.error); T.toast('هشدار سیگنال ثبت شد'); T.loadAlerts(); },
  'al-del': async t => { await T.api('/api/alerts/' + t.dataset.id, { method: 'DELETE' }); T.loadAlerts(); },
  'notif-perm': async () => { if (!window.Notification) return T.toast('مرورگر اعلان را پشتیبانی نمی‌کند'); const p = await Notification.requestPermission(); T.toast(p === 'granted' ? 'مجوز داده شد' : 'مجوز رد شد'); },
  'notif-test': () => T.notifyAlert('این یک هشدار آزمایشی است'),
  'prof-save': () => { const n = ($('#prof-name').value || '').trim(); if (!n) return T.toast('نام پروفایل را بنویسید'); T.saveProfile(n); T.toast('ذخیره شد'); R.set(true); },
  'prof-apply': t => { const p = T.profiles().find(x => x.name === t.dataset.n); if (p) { T.importUI(p.ui); R.set(true); T.toast('اعمال شد'); } },
  'prof-del': t => { T.delProfile(t.dataset.n); R.set(true); },
  ai: async () => { ST.aiBusy = true; R.coin(); ST.ai = await T.api(`/api/ai/${ST.sel}?tf=${ST.tf}`, { timeout: 40000 }); ST.aiBusy = false; if (ST.ai.error) { T.toast(ST.ai.error); ST.ai = null; } R.coin(); },
  open: async t => {
    const d = ST.deep, c = ST.coin; if (!c) return; const side = t.dataset.side; let p = c.signal.side === side ? c.signal : (d && d.signal && d.signal.side === side ? d.signal : null);
    if (!p) return T.toast('برای این سمت سطح معتبری وجود ندارد');
    const r = await post('/api/exchange/open', { symbol: ST.sel, side, entry: p.entry, stop: p.stop, tp1: p.tp1, tp2: p.tp2, tp3: p.tp3, leverage: +($('#lev') || {}).value || 10, score: p.score, regime: p.regime });
    T.toast(r.ok ? `پوزیشن ${T.SIDE_FA[side]} باز شد (اهرم ${r.leverage_used}×)` : (r.error || 'خطا')); if (r.ok) T.loadAcct();
  },
  close: async t => { const r = await post('/api/exchange/close', { id: t.dataset.id }); T.toast(r.ok ? 'بسته شد: ' + T.usd(r.pnl) : (r.error || 'خطا')); T.loadAcct(); },
  auto: async () => { const r = await post('/api/exchange/auto', { enabled: !(ST.acct && ST.acct.auto_trade) }); T.toast(r.auto_trade ? 'معامله خودکار روشن شد' : 'معامله خودکار خاموش شد'); T.loadAcct(); },
  reset: async () => { if (!confirm('حساب کاغذی به ۱۰٬۰۰۰ دلار بازنشانی شود؟')) return; await post('/api/exchange/reset'); T.toast('حساب بازنشانی شد'); T.loadAcct(); },
  preset: t => {
    const id = t.dataset.id; if (!id) return;
    if (T.applyThemeProfile) T.applyThemeProfile(id);
    const U = T.UI;
    const p = (T.PRESETS || []).find(x => x.id === id);
    // instant DOM theme class (works on mobile even if something else lags)
    try {
      const b = document.body;
      b.className = (b.className || '').split(/\s+/).filter(x => x && !x.startsWith('theme-')).concat(['theme-' + id]).join(' ');
      if (p) {
        b.style.background = 'linear-gradient(165deg,' + p.bg1 + ',' + p.bg2 + ')';
        b.style.color = p.dark ? '#e8f2ff' : '#0c2038';
        document.documentElement.style.setProperty('--bg1', p.bg1);
        document.documentElement.style.setProperty('--bg2', p.bg2);
        document.documentElement.style.setProperty('--a', p.a);
        document.documentElement.style.setProperty('--b', p.b);
        document.documentElement.style.setProperty('--c', p.c);
        document.documentElement.style.setProperty('--up', p.up);
        document.documentElement.style.setProperty('--dn', p.dn);
      }
    } catch (e) { console.error(e); }
    try { T.applyUI(); } catch (e) { console.error('applyUI', e); }
    try { T.saveUI(); } catch (e) { console.error('saveUI', e); }
    try { if (R.set) R.set(true); } catch (e) {}
    try { T.render(); } catch (e) {}
    T.toast && T.toast('تم: ' + ((p && p.name) || id));
  },
  'colors-reset': () => { T.UI.colors = {}; T.applyUI(); T.saveUI(); R.set(true); },
  sw: t => { const path = t.dataset.path, ks = path.split('.'); let o = T.UI; while (ks.length > 1) o = o[ks.shift()]; T.setUI(path, !o[ks[0]], true); R.set(true); },
  'hw-up': t => { const i = +t.dataset.i, h = T.UI.home; if (i > 0) { [h[i - 1], h[i]] = [h[i], h[i - 1]]; T.saveUI(); R.set(true); } },
  'hw-dn': t => { const i = +t.dataset.i, h = T.UI.home; if (i < h.length - 1) { [h[i + 1], h[i]] = [h[i], h[i + 1]]; T.saveUI(); R.set(true); } },
  'wl-add': async () => { const v = ($('#wl-add').value || '').trim(); if (!v) return; const r = await post('/api/settings', { watchlist: ST.syms.concat([v]) }); if (r.watchlist) { ST.syms = r.watchlist; T.toast('افزوده شد — اسکن شروع شد'); R.set(true); T.doScan(true); } else T.toast(r.error || 'نماد نامعتبر'); },
  'wl-del': async t => { const r = await post('/api/settings', { watchlist: ST.syms.filter(s => s !== t.dataset.s) }); if (r.watchlist) { ST.syms = r.watchlist; R.set(true); T.toast('حذف شد'); } else T.toast(r.error || 'حداقل یک ارز لازم است'); },
  'scan-sec': async () => { const r = await post('/api/settings', { scan_sec: +($('#scan-sec').value || 90) }); T.toast(r.scan_sec ? 'ثبت شد' : 'خطا'); },
  export: async () => { const s = JSON.stringify(T.UI); try { await navigator.clipboard.writeText(s); T.toast('کپی شد'); } catch (e) { $('#imp').value = s; T.toast('متن را دستی کپی کنید'); } },
  download: () => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(T.UI, null, 1)], { type: 'application/json' })); a.download = 'titan-theme.json'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); },
  import: () => { try { T.importUI(JSON.parse($('#imp').value)); R.set(true); T.toast('تنظیمات اعمال شد'); } catch (e) { T.toast('JSON نامعتبر'); } },
  'ui-reset': () => { if (confirm('همه تنظیمات ظاهری به پیش‌فرض برگردد؟')) { T.resetUI(); R.set(true); } },
});


document.addEventListener('change', e => { const f = e.target; if (f.id !== 'bg-file' || !f.files[0]) return; const rd = new FileReader();
  rd.onload = () => { const im = new Image(); im.onload = () => { const k = Math.min(1, 1400 / Math.max(im.width, im.height)), cv = document.createElement('canvas'); cv.width = im.width * k; cv.height = im.height * k; cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
    try { localStorage.setItem('titan.bgimg', cv.toDataURL('image/jpeg', .72)); T.applyUI(); T.toast('تصویر اعمال شد'); } catch (err) { T.toast('تصویر خیلی بزرگ است'); } }; im.src = rd.result; }; rd.readAsDataURL(f.files[0]); });
const onAcfg = async e => { const t = e.target, k = t.dataset && t.dataset.acfg; if (!k) return; const v = t.tagName === 'SELECT' ? t.value : +t.value; await post('/api/auto/config', { mode: (ST.autoCfg || {}).cfg ? ST.autoCfg.cfg.mode : 'safe', overrides: { [k]: v } }); T.toast('ذخیره شد'); T.loadAuto(); };
document.addEventListener('change', onAcfg);
const onScr = e => { const t = e.target; if (t.dataset && t.dataset.calc) { ST.calc[t.dataset.calc] = +t.value; T.updCalc(); }
  if (t.dataset && t.dataset.scr) { const k = t.dataset.scr; ST.scr[k] = t.tagName === 'SELECT' && !isNaN(+t.value) ? +t.value : t.value; put($('#scr-res'), scrResHtml()); } };
document.addEventListener('input', onScr); document.addEventListener('change', onScr);

T.V = { card, TAB, put, ICON, rowsOf, dot, gchip, pct, kvs, barSigned, sgn, W, hrs, tfChips, COIN_TABS, coinCtx, buildTape, patFor, storiesHtml, agoTxt, esc, $ };
R.all = function () { const p = ST.panel; if (p !== 'home') buildTape(rowsOf()); if (p === 'desk') { if (R.desk) R.desk(); return; } if (p === 'home') R.home(); else if (p === 'coin') R.coin(); else if (p === 'chart') R.chart(); else if (p === 'mkt') R.mkt(); else if (p === 'ex') R.ex(); else if (p === 'set') R.set(false); };
const _go = T.go; T.go = function (p) { if (p === 'set') built = false; _go(p); };
})();

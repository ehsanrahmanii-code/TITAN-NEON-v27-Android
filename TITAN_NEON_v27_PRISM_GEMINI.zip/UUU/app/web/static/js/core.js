/* TITAN PRO NEON — core: state, API, theme engine, personalization, polling */
(function () {
'use strict';
const T = window.T = { acts: {}, R: {} };
T.$ = (s, r = document) => r.querySelector(s);
T.$$ = (s, r = document) => [...r.querySelectorAll(s)];
T.esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ───────── state ───────── */
const ST = T.ST = { matrix: {}, tfs: ['15m', '1h', '4h', '1d'], sel: null, tf: '1h', panel: 'home', acct: null, status: null,
  coin: null, deep: null, ai: null, aiBusy: false, scanning: false, syms: [], at: 0, prog: { done: 0, total: 0 }, flowSel: 'engine', dtSel: null,
  tab: { coin: 'sum', chart: 'main', mkt: 'opp' }, pat: null, alerts: null, micro: null, microAt: 0, market: null, bt: null, btBusy: false, mtf: {}, calc: { cap: 0, risk: 1, lev: 10, side: '' }, scr: { side: 'all', grade: 'any', sort: 'cons', min: 0, rr: 0, q: '' } };

/* ───────── presets ───────── */
const P = (id, name, dark, bg1, bg2, a, b, c, up, dn, go, o = {}) => Object.assign({ id, name, dark, bg1, bg2, a, b, c, up, dn, go,
  pn: dark ? 'rgba(14,22,46,.62)' : 'rgba(255,255,255,.7)', pn2: dark ? '#0d1530' : '#ffffff', tx: dark ? '#e6f3ff' : '#0b1b33', mu: dark ? '#8296b8' : '#5a6b86',
  ln: `color-mix(in srgb,${a} ${dark ? 24 : 32}%,transparent)` }, o);
const G = (id, name, dark, bg1, bg2, a, b, c, up, dn, go, m, o = {}) => P(id, name, dark, bg1, bg2, a, b, c, up, dn, go, Object.assign({ glass: 1, m1: m[0], m2: m[1], m3: m[2], hlc: dark ? '#ffffff' : '#ffffff', shc: dark ? '#000000' : '#46608f',
  pn2: dark ? `color-mix(in srgb,${bg2} 78%,${a} 7%)` : '#ffffff' }, o));
T.PRESETS = [
  /* 20 Prism-Glass themes only — professional / neon / light / dark / luminous / vivid */
  G('g-aurora', 'شفق پریسم', 1, '#04060f', '#0a1230', '#38ffd4', '#7c6bff', '#ff5fd2', '#35ffb0', '#ff5577', '#ffd25a', ['#00ffc8', '#6a5cff', '#ff4fd8']),
  G('g-cyber', 'سایبر نئون', 1, '#05070f', '#0b1226', '#00f0ff', '#8b5cf6', '#ff2bd6', '#19ffa3', '#ff4b6e', '#ffd25a', ['#00f0ff', '#8b5cf6', '#ff2bd6']),
  G('g-ocean', 'اقیانوس بلور', 1, '#02111f', '#04243f', '#29d8ff', '#2f7bff', '#20ffc4', '#27ffb8', '#ff5a7a', '#ffd25a', ['#00b7ff', '#2f5bff', '#00ffc8']),
  G('g-ruby', 'یاقوت نئونی', 1, '#14030a', '#2a0612', '#ff3b66', '#ff8a3d', '#ffd166', '#34f5a0', '#ff3b66', '#ffd166', ['#ff2d55', '#ff7a1a', '#b0004a']),
  G('g-emerald', 'زمرد شیشه‌ای', 1, '#021410', '#032a22', '#2dffb2', '#00c8ff', '#c6ff3d', '#2dffb2', '#ff5a6e', '#e8ff5a', ['#00ff9d', '#00b7ff', '#a5ff2d']),
  G('g-galaxy', 'کهکشان بنفش', 1, '#0a0420', '#1b0b45', '#b88bff', '#5b7bff', '#ff5de8', '#38ffc0', '#ff5d8a', '#ffd25a', ['#8a4dff', '#3d5bff', '#ff4fd8']),
  G('g-gold', 'طلای شب', 1, '#0a0804', '#1c1407', '#ffd24d', '#ff9a1f', '#fff0b0', '#4dffb8', '#ff5d5d', '#ffd24d', ['#ffc800', '#ff8c00', '#ffe9a0']),
  G('g-ice', 'یخ الماس (روشن)', 0, '#e8f4ff', '#cfe6ff', '#0a8cff', '#6a5bff', '#ff4fa8', '#08a36b', '#e0324d', '#c47a00', ['#5cc8ff', '#9a8cff', '#ffb3e1'], { pn: 'rgba(255,255,255,.55)', tx: '#0c2038', mu: '#587090', ln: 'rgba(10,60,120,.18)' }),
  G('g-sakura', 'شکوفه شیشه (روشن)', 0, '#fff0f6', '#ffdbe9', '#ff3d8b', '#a24bff', '#ff9a3d', '#0f9d6b', '#d6264a', '#b9740a', ['#ff8fbf', '#c79bff', '#ffc58f'], { pn: 'rgba(255,255,255,.55)', tx: '#3a1028', mu: '#8a5a72', ln: 'rgba(160,30,90,.2)' }),
  G('g-matrix', 'ماتریکس شیشه‌ای', 1, '#000a04', '#001a0a', '#00ff6a', '#00d0ff', '#b8ff00', '#00ff6a', '#ff3b3b', '#d8ff3a', ['#00ff6a', '#00aa55', '#00ffd0']),
  G('g-tokyo', 'توکیو شب', 1, '#0b0c1e', '#16182f', '#7aa2f7', '#bb9af7', '#f7768e', '#9ece6a', '#f7768e', '#e0af68', ['#7aa2f7', '#bb9af7', '#ff9e64']),
  G('g-plasma', 'پلاسما نورانی', 1, '#0c0218', '#1c0430', '#ff2bd6', '#00e5ff', '#ffe14d', '#2bffb0', '#ff4d6d', '#ffe14d', ['#ff2bd6', '#00e5ff', '#7b2cff']),
  G('g-obsidian', 'ابسیدین حرفه‌ای', 1, '#07080c', '#12141c', '#6ee7ff', '#a78bfa', '#fb7185', '#34d399', '#fb7185', '#fbbf24', ['#6ee7ff', '#a78bfa', '#f472b6']),
  G('g-mica', 'میکا نرم (روشن)', 0, '#f3f6fb', '#e4ecf8', '#0067c0', '#7a5af8', '#00b7c3', '#0f9d6b', '#d63b55', '#c47a00', ['#0067c0', '#7a5af8', '#00b7c3'], { pn: 'rgba(255,255,255,.78)', tx: '#152033', mu: '#5a6b86', ln: 'rgba(0,103,192,.16)' }),
  G('g-royal', 'سلطنتی بنفش', 1, '#0c0418', '#1a0a32', '#c084fc', '#818cf8', '#f472b6', '#4ade80', '#f43f5e', '#fbbf24', ['#c084fc', '#818cf8', '#f472b6']),
  G('g-ember', 'آتش شیشه‌ای', 1, '#120806', '#2a1008', '#ff6b2d', '#ff3d5a', '#ffd166', '#3dffb0', '#ff3d5a', '#ffd166', ['#ff6b2d', '#ff3d5a', '#ffb020']),
  G('g-north', 'شفق قطبی', 1, '#020b12', '#041824', '#22d3ee', '#34d399', '#a78bfa', '#34d399', '#fb7185', '#fde047', ['#22d3ee', '#34d399', '#a78bfa']),
  G('g-midnight', 'نیمه‌شب بلور', 1, '#020617', '#0f172a', '#38bdf8', '#818cf8', '#e879f9', '#4ade80', '#f43f5e', '#facc15', ['#38bdf8', '#818cf8', '#e879f9']),
  G('g-rainbow', 'پریسم رنگین‌کمان', 1, '#0a0614', '#160c28', '#ff6bcb', '#7c6bff', '#00e5ff', '#35ffb0', '#ff5577', '#ffd25a', ['#ff6bcb', '#7c6bff', '#00e5ff']),
  G('g-lumen', 'لومن متحرک', 1, '#050510', '#101028', '#5eead4', '#c4b5fd', '#fda4af', '#6ee7b7', '#fb7185', '#fde68a', ['#5eead4', '#c4b5fd', '#fda4af']),
];
/* unique glass panel tint per theme so themes are visibly different */
T.PRESETS.forEach(p => {
  if (!p) return;
  if (p.dark) {
    p.pn = `color-mix(in srgb, ${p.bg2} 55%, ${p.a} 12%)`;
    p.pn2 = `color-mix(in srgb, ${p.bg2} 82%, ${p.a} 8%)`;
    p.ln = `color-mix(in srgb, ${p.a} 32%, transparent)`;
  } else {
    p.pn = `rgba(255,255,255,.72)`;
    p.pn2 = `#ffffff`;
    p.ln = `color-mix(in srgb, ${p.a} 28%, transparent)`;
  }
});
T.THEME_PROFILES = {
  'g-aurora': { style:'glass', bg:'aurora', glow:1.4, blur:22, radius:20, sat:1.6, shine:0.9, border:1.3, dens:'comfy' },
  'g-cyber': { style:'neon', bg:'grid', glow:1.8, blur:14, radius:10, sat:1.8, shine:1.1, border:1.5, dens:'compact' },
  'g-ocean': { style:'glass', bg:'mesh', glow:1.2, blur:24, radius:22, sat:1.4, shine:0.7, border:1.1, dens:'comfy' },
  'g-ruby': { style:'neon', bg:'shapes', glow:1.6, blur:16, radius:14, sat:1.7, shine:1.0, border:1.4, dens:'comfy' },
  'g-emerald': { style:'glass', bg:'shapes', glow:1.3, blur:20, radius:18, sat:1.5, shine:0.8, border:1.2, dens:'comfy' },
  'g-galaxy': { style:'glass', bg:'aurora', glow:1.5, blur:26, radius:24, sat:1.6, shine:1.0, border:1.3, dens:'roomy' },
  'g-gold': { style:'neon', bg:'mesh', glow:1.5, blur:18, radius:16, sat:1.5, shine:0.95, border:1.3, dens:'comfy' },
  'g-ice': { style:'glass', bg:'mesh', glow:0.9, blur:28, radius:20, sat:1.2, shine:0.6, border:1.0, dens:'comfy' },
  'g-sakura': { style:'glass', bg:'aurora', glow:1.1, blur:24, radius:22, sat:1.4, shine:0.75, border:1.1, dens:'comfy' },
  'g-matrix': { style:'neon', bg:'grid', glow:2.0, blur:10, radius:6, sat:2.0, shine:1.3, border:1.8, dens:'compact' },
  'g-tokyo': { style:'neon', bg:'shapes', glow:1.7, blur:14, radius:12, sat:1.7, shine:1.1, border:1.5, dens:'compact' },
  'g-plasma': { style:'neon', bg:'aurora', glow:1.9, blur:18, radius:16, sat:1.9, shine:1.2, border:1.6, dens:'comfy' },
  'g-obsidian': { style:'solid', bg:'none', glow:0.8, blur:8, radius:8, sat:1.1, shine:0.4, border:0.8, dens:'compact' },
  'g-mica': { style:'glass', bg:'none', glow:0.7, blur:20, radius:14, sat:1.1, shine:0.5, border:0.9, dens:'comfy' },
  'g-royal': { style:'glass', bg:'shapes', glow:1.4, blur:22, radius:20, sat:1.5, shine:0.9, border:1.3, dens:'roomy' },
  'g-ember': { style:'neon', bg:'mesh', glow:1.6, blur:16, radius:14, sat:1.6, shine:1.0, border:1.4, dens:'comfy' },
  'g-north': { style:'glass', bg:'aurora', glow:1.3, blur:24, radius:18, sat:1.4, shine:0.8, border:1.2, dens:'comfy' },
  'g-midnight': { style:'glass', bg:'shapes', glow:1.2, blur:20, radius:16, sat:1.3, shine:0.7, border:1.1, dens:'comfy' },
  'g-rainbow': { style:'neon', bg:'aurora', glow:1.8, blur:20, radius:18, sat:2.0, shine:1.2, border:1.5, dens:'comfy' },
  'g-lumen': { style:'glass', bg:'aurora', glow:1.5, blur:26, radius:22, sat:1.6, shine:1.0, border:1.3, dens:'roomy' },
};


T.FONTS = { system: '"Vazirmatn","Vazir","IRANSans","Segoe UI",Tahoma,system-ui,sans-serif', mono: '"JetBrains Mono","Cascadia Code",Consolas,"Courier New",monospace', tahoma: 'Tahoma,"Segoe UI",sans-serif', serif: '"Noto Naskh Arabic",Georgia,"Times New Roman",serif' };
T.WIDGETS = [
  { id: 'kpi', n: 'شاخص‌های کلیدی', w: 1 }, { id: 'circuit', n: 'برد مدار بازار (شماتیک)', w: 1 }, { id: 'gauge', n: 'سنجه جهت بازار', w: 0 },
  { id: 'tfcons', n: 'اجماع تایم‌فریم‌ها', w: 0 }, { id: 'scatter', n: 'نقشه حبابی سیگنال‌ها', w: 0 }, { id: 'top', n: 'برترین سیگنال‌ها + مخروط پیش‌بینی', w: 1 },
  { id: 'setups', n: 'بهترین ستاپ‌ها (درجه‌بندی A–D)', w: 1 }, { id: 'alerts', n: 'هشدارهای من', w: 1 }, { id: 'mood', n: 'حال‌وهوای بازار', w: 1 },
  { id: 'heat', n: 'نقشه حرارتی فشرده ۲۴س', w: 1 }, { id: 'heatcons', n: 'نقشه حرارتی اجماع', w: 1 },
  { id: 'leaders', n: 'رهبران خرید/فروش', w: 1 }, { id: 'volrank', n: 'رتبه حجم', w: 0 }, { id: 'squeeze', n: 'فشردگی / آماده حرکت', w: 0 },
  { id: 'gradeboard', n: 'تابلوی درجه A–D', w: 1 }, { id: 'momentum', n: 'شتاب ۲۴ ساعته', w: 1 },
  { id: 'session', n: 'جلسه معاملاتی UTC', w: 0 }, { id: 'riskmap', n: 'نقشه ریسک/کیفیت', w: 1 },
  { id: 'align', n: 'هم‌جهتی چندتایم‌فریم', w: 0 }, { id: 'breadth', n: 'عرض بازار (Breadth)', w: 0 },
  { id: 'watch', n: 'واچ‌لیست پیشنهادی', w: 1 }, { id: 'corrbtc', n: 'همبستگی با BTC', w: 1 },
  { id: 'matrix', n: 'ماتریس کامل', w: 1 },
];
T.SKINS = [
  { id: 'prism', name: 'پریسم شیشه‌ای', desc: 'تنها رابط رسمی · شیشه رنگارنگ · ۲۰ تم شیشه‌ای · اشکال هندسی', b: { radius: 22, blur: 22, glow: 1.25, card: 'prism', nav: 'bottom', density: 'comfy', font: 'system', fs: 15, bg: 'shapes', tabs: 'pill', header: 'full', labels: 'on', icons: 'normal', skin: 'prism', shell: 'panels' } },
];
const DEF_UI = () => ({
  /* theme */
  preset: 'g-aurora', colors: {}, skin: 'prism', card: 'prism',
  /* glass & light */
  glow: 1.25, blur: 22, radius: 22, glassA: .55, hls: .55, sat: 1.5, shd: 1, bw: 1, tglow: .4, grain: 0,
  prismShine: .7, prismBorder: 1.2, shapeOp: .55, shapeSpeed: 1, meshOp: .4,
  /* type & density */
  fs: 15, font: 'system', weight: 400, lh: 'normal', density: 'comfy', icons: 'normal', labels: 'on', tnum: 1, digits: 'en',
  /* layout */
  maxw: 1320, cols: 'auto', nav: 'bottom', tabs: 'pill', header: 'full', btn: 'solid', chip: 'pill', scroll: 'thin',
  kpiScale: 1, heatSize: 52, cardPad: 1, gapScale: 1,
  /* background & motion */
  bg: 'shapes', bgop: .7, bgdim: .5, motion: 'on', speed: 1, anim: 'fade', scan: false, perf: 'auto',
  /* chart */
  candleUp: '', candleDn: '', chartH: 1, crossStyle: 'dash', chartBg: 'none', candle: 'solid', grid: 1, wick: 1.4, cone: 'fill', homeMini: 'candles', chartN: 0,
  /* shell */
  shell: 'panels', desk: null, deskTpl: 'trader', termTab: 'plan', wallSec: 12,
  /* alerts / misc */
  alertSound: 1, alertVib: 1, alertNotify: 0, swapUD: false, defTf: '1h',
  home: T.WIDGETS.map(w => ({ id: w.id, on: true })), _ts: 0,
  chart: { layers: { pat: 1, ema: 1, bb: 0, lv: 1, fc: 1, vol: 1, sr: 1, e200: 0, vwap: 0, ich: 0, st: 0, vp: 0, fib: 0, pv: 0 }, panes: { rsi: 0, macd: 0, srsi: 0 } }
});
let UI = T.UI = DEF_UI();

function mergeUI(src) {
  const d = DEF_UI(); const o = Object.assign(d, src && typeof src === 'object' ? src : {});
  o.skin = 'prism'; o.card = o.card === 'solid' || o.card === 'outline' ? 'prism' : (o.card || 'prism');
  if (!T.PRESETS.find(p => p.id === o.preset)) o.preset = 'g-aurora';
  const known = new Set(T.WIDGETS.map(w => w.id)); const seen = new Set();
  o.home = (Array.isArray(o.home) ? o.home : []).filter(w => w && known.has(w.id) && !seen.has(w.id) && seen.add(w.id));
  T.WIDGETS.forEach(w => { if (!seen.has(w.id)) o.home.push({ id: w.id, on: true }); });
  if (!T.PRESETS.some(p => p.id === o.preset)) o.preset = (T.PRESETS[0] && T.PRESETS[0].id) || 'g-aurora';
  o.shell = 'panels'; o.skin = 'prism';
  o.desk = null;
  o.colors = o.colors && typeof o.colors === 'object' ? o.colors : {};
  const dc = d.chart, sc = (src && src.chart) || {};
  o.chart = { layers: Object.assign({}, dc.layers, sc.layers || {}), panes: Object.assign({}, dc.panes, sc.panes || {}) };
  return o;
}
function readLocal() { try { return JSON.parse(localStorage.getItem('titan.ui') || 'null'); } catch (e) { return null; } }
UI = T.UI = mergeUI(readLocal());


T.applyThemeProfile = function (id) {
  const U = T.UI = (T.UI || {});
  const pr = (T.THEME_PROFILES || {})[id];
  const p = (T.PRESETS || []).find(x => x.id === id);
  if (!pr && !p) return;
  U.preset = id;
  U.colors = {};
  U.skin = 'prism';
  if (pr) {
    U.glow = pr.glow; U.blur = pr.blur; U.radius = pr.radius; U.sat = pr.sat;
    U.prismShine = pr.shine; U.prismBorder = pr.border;
    U.density = pr.dens; U.bg = pr.bg;
    U.card = pr.style === 'neon' ? 'neon' : (pr.style === 'solid' ? 'solid' : 'prism');
    U.glassA = pr.style === 'solid' ? 0.95 : 0.55;
  } else if (p) {
    U.bg = p.dark ? 'shapes' : 'mesh';
  }
};

T.palette = () => { const U = T.UI || UI || {}; return Object.assign({}, (T.PRESETS || []).find(p => p.id === U.preset) || (T.PRESETS || [])[0] || {}, U.colors || {}); };
T.applyUI = function () {
  // ALWAYS read/write T.UI so theme + personalization stay in sync
  const U = T.UI = (T.UI || UI || {});
  if (typeof UI !== 'undefined') { try { UI = U; } catch (e) {} }
  const c = T.palette();
  if (!c || !c.bg1) { console.warn('palette empty', U.preset); return; }
  const root = document.documentElement;
  const body = document.body;
  if (!root || !body) return;
  const set = (k, v) => {
    if (v == null || v === '') return;
    root.style.setProperty(k, String(v));
  };
  // colors
  set('--bg1', c.bg1); set('--bg2', c.bg2);
  set('--pn', c.pn); set('--pn2', c.pn2); set('--ln', c.ln);
  set('--tx', c.tx); set('--mu', c.mu);
  set('--a', c.a); set('--b', c.b); set('--c', c.c); set('--go', c.go);
  set('--up', U.swapUD ? c.dn : c.up);
  set('--dn', U.swapUD ? c.up : c.dn);
  set('--fu', c.fu || c.a); set('--fd', c.fd || c.c);
  set('--m1', c.m1 || c.a); set('--m2', c.m2 || c.b); set('--m3', c.m3 || c.c);
  set('--hlc', c.hlc || '#ffffff');
  set('--shc', c.shc || (c.dark ? '#000000' : '#46608f'));
  // personalization numbers
  set('--ga', U.glassA != null ? U.glassA : 0.55);
  set('--hls', U.hls != null ? U.hls : 0.55);
  set('--sat', U.sat != null ? U.sat : 1.5);
  set('--shd', U.shd != null ? U.shd : 1);
  set('--bw', (U.bw != null ? U.bw : 1) + 'px');
  set('--tglow', U.tglow != null ? U.tglow : 0.4);
  set('--maxw', (U.maxw >= 3000) ? '100%' : ((U.maxw || 1320) + 'px'));
  set('--glow', U.glow != null ? U.glow : 1);
  set('--bl', (U.blur != null ? U.blur : 14) + 'px');
  set('--r', (U.radius != null ? U.radius : 16) + 'px');
  set('--fs', (U.fs != null ? U.fs : 15) + 'px');
  set('--ff', (T.FONTS && T.FONTS[U.font]) || (T.FONTS && T.FONTS.system) || 'system-ui,sans-serif');
  set('--dur', U.speed != null ? U.speed : 1);
  set('--bgop', U.bgop != null ? U.bgop : 0.55);
  set('--bgdim', U.bgdim != null ? U.bgdim : 0.5);
  const dens = U.density || 'comfy';
  const basePad = dens === 'compact' ? 9 : dens === 'roomy' ? 20 : 14;
  const baseGap = dens === 'compact' ? 8 : dens === 'roomy' ? 16 : 12;
  set('--pad', (basePad * (Number(U.cardPad) || 1)).toFixed(1) + 'px');
  set('--gap', (baseGap * (Number(U.gapScale) || 1)).toFixed(1) + 'px');
  set('--kpi-scale', String(U.kpiScale != null ? U.kpiScale : 1));
  set('--heat-size', (U.heatSize != null ? U.heatSize : 52) + 'px');
  set('--prism-shine', String(U.prismShine != null ? U.prismShine : 0.7));
  set('--prism-border', String(U.prismBorder != null ? U.prismBorder : 1.2));
  set('--shape-op', String(U.shapeOp != null ? U.shapeOp : 0.55));
  set('--shape-speed', String(U.shapeSpeed != null ? U.shapeSpeed : 1));
  set('--mesh-op', String(U.meshOp != null ? U.meshOp : 0.4));
  try {
    const bgimg = localStorage.getItem('titan.bgimg');
    set('--bgimg', bgimg ? ('url(' + bgimg + ')') : 'none');
  } catch (e) { set('--bgimg', 'none'); }
  // theme class (mobile-reliable) + simple solid gradient (no color-mix for old WebKit)
  try {
    const classes = (body.className || '').split(/\s+/).filter(x => x && !x.startsWith('theme-'));
    classes.push('theme-' + (U.preset || 'g-aurora'));
    body.className = classes.join(' ');
  } catch (e) {}
  body.style.background = 'linear-gradient(165deg, ' + c.bg1 + ' 0%, ' + c.bg2 + ' 100%)';
  body.style.backgroundAttachment = 'fixed';
  body.style.color = c.tx || '';
  body.style.fontWeight = U.weight || 400;
  body.style.fontSize = (U.fs != null ? U.fs : 15) + 'px';
  if (T.FONTS && T.FONTS[U.font]) body.style.fontFamily = T.FONTS[U.font];
  // personalization live on cards via CSS vars already set
  body.style.setProperty('--bl', (U.blur != null ? U.blur : 14) + 'px');
  body.style.setProperty('--r', (U.radius != null ? U.radius : 16) + 'px');
  body.style.setProperty('--glow', String(U.glow != null ? U.glow : 1));
  body.style.setProperty('--fs', (U.fs != null ? U.fs : 15) + 'px');
  // data attributes
  const ds = body.dataset;
  ds.skin = 'prism'; ds.shell = 'panels'; ds.glass = 'on';
  ds.theme = U.preset || 'g-aurora';
  ds.scheme = c.dark ? 'dark' : 'light';
  ds.bg = U.bg || 'shapes';
  ds.card = U.card || 'prism';
  ds.density = dens;
  ds.cols = String(U.cols || 'auto');
  ds.nav = U.nav || 'bottom';
  ds.tabs = U.tabs || 'pill';
  ds.header = U.header || 'full';
  ds.btn = U.btn || 'solid';
  ds.chip = U.chip || 'pill';
  ds.anim = U.anim || 'fade';
  ds.scroll = U.scroll || 'thin';
  ds.motion = U.motion || 'on';
  ds.lh = U.lh || 'normal';
  ds.icons = U.icons || 'normal';
  ds.labels = U.labels || 'on';
  ds.grain = U.grain ? 'on' : 'off';
  ds.tnum = U.tnum ? 'on' : 'off';
  ds.scan = U.scan ? 'on' : 'off';
  ds.perf = U.perf === 'auto' ? ((T.ST && T.ST.perfLow) ? 'low' : 'high') : (U.perf || 'auto');
  const app = document.querySelector('.app');
  if (app) app.style.maxWidth = U.maxw >= 3000 ? '100%' : ((U.maxw || 1320) + 'px');
  const meta = document.querySelector('meta[name=theme-color]');
  if (meta) meta.content = c.bg1 || '#05070f';
  root.style.colorScheme = c.dark ? 'dark' : 'light';
  // chart colors
  T.C = { a: c.a, b: c.b, c: c.c, up: U.swapUD ? c.dn : c.up, dn: U.swapUD ? c.up : c.dn,
    go: c.go, tx: c.tx, mu: c.mu, ln: c.ln, fu: c.fu || c.a, fd: c.fd || c.c, bg1: c.bg1, bg2: c.bg2, dark: !!c.dark };
  // mark live
  body.dataset.uiApplied = String(Date.now());
};

let saveTimer;
T.saveUI = function () {
  const U = T.UI = (T.UI || UI || {});
  try { UI = U; } catch (e) {}
  U._ts = Date.now();
  try { localStorage.setItem('titan.ui', JSON.stringify(U)); } catch (e) { /* private mode */ }
  try {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      try { if (T.api) T.api('/api/settings', { method: 'POST', body: JSON.stringify({ ui: UI }) }); } catch (e2) { /* offline */ }
    }, 800);
  } catch (e) { /* noop */ }
};
T.setUI = function (path, val, rerender) {
  const U = T.UI = (T.UI || UI || {});
  try { UI = U; } catch (e) {}
  const ks = path.split('.'); let o = U;
  while (ks.length > 1) { const k = ks.shift(); o = o[k] = (o[k] && typeof o[k] === 'object') ? o[k] : {}; }
  o[ks[0]] = val;
  if (path === 'preset') { U.colors = {}; U.skin = 'prism'; }
  try { T.applyUI(); } catch (e) { console.error('applyUI', e); }
  try { T.saveUI(); } catch (e) { console.error('saveUI', e); }
  try { T.$$(`[data-val="${path}"]`).forEach(e => e.textContent = typeof val === 'number' ? (Math.round(val * 100) / 100) : val); } catch (e) {}
  // keys that change layout / labels / structure → full re-render so dashboard stays unified
  const STRUCT = new Set(['swapUD','digits','preset','density','cols','card','nav','bg','skin','tabs','header',
    'labels','icons','lh','font','maxw','defTf','homeMini','candle','cone','grid','motion','scan','shell','perf',
    'btn','chip','anim','scroll','grain','tnum','digits']);
  // visual-only keys (glow/blur/radius/…) update CSS live via applyUI without full DOM rebuild
  const LAYOUT = new Set(['kpiScale','heatSize','cardPad','gapScale','fs','weight']);
  const root = path.split('.')[0];
  if (STRUCT.has(path) || STRUCT.has(root) || path.startsWith('home.') || path.startsWith('chart.') || rerender) {
    if (T.R && T.R.set && (path.startsWith('home') || path === 'cols' || path === 'density' || path === 'card' || path === 'preset')) {
      try { T.R.set(true); } catch (e) { /* noop */ }
    }
    T.render();
  } else if (LAYOUT.has(path) || LAYOUT.has(root)) {
    if (T.ST.panel === 'home') T.render();
  } else if (T.ST.panel === 'chart' && T.R && T.R.redrawChart) {
    T.R.redrawChart();
  }
};
T.applySkin = function (id) {
  const sk = (T.SKINS || []).find(x => x.id === id);
  if (!sk) { T.toast && T.toast('رابط یافت نشد'); return; }
  Object.assign(UI, sk.b || {}, { skin: id, colors: {} });
  if (sk.b && sk.b.preset) UI.preset = sk.b.preset;
  if (sk.b && sk.b.card) UI.card = sk.b.card;
  if (sk.b && sk.b.bg) UI.bg = sk.b.bg;
  if (sk.b && sk.b.nav) UI.nav = sk.b.nav;
  if (sk.b && sk.b.density) UI.density = sk.b.density;
  T.UI = UI;
  T.applyUI(); T.saveUI();
  if (sk.b && sk.b.shell && typeof T.applyShell === 'function') {
    try { T.applyShell(sk.b.shell); } catch (e) {}
  }
  if (T.R && T.R.set) try { T.R.set(true); } catch (e) {}
  T.render();
  T.toast && T.toast('رابط: ' + sk.name);
};
T.profiles = () => { try { return JSON.parse(localStorage.getItem('titan.profiles') || '[]'); } catch (e) { return []; } };
T.saveProfile = name => { const p = T.profiles().filter(x => x.name !== name); p.push({ name, ui: JSON.parse(JSON.stringify(UI)) }); localStorage.setItem('titan.profiles', JSON.stringify(p.slice(-12))); };
T.delProfile = name => localStorage.setItem('titan.profiles', JSON.stringify(T.profiles().filter(x => x.name !== name)));
T.resetUI = () => { UI = T.UI = DEF_UI(); T.applyUI(); T.saveUI(); T.render(); };
T.importUI = obj => { UI = T.UI = mergeUI(obj); T.applyUI(); T.saveUI(); T.render(); };

T.isPhone = () => innerWidth < 640;
T.tabs = (panel, list) => `<div class="tabs" role="tablist">${list.map(([k, n]) => `<button role="tab" class="tab ${ST.tab[panel] === k ? 'on' : ''}" data-act="tab" data-pn="${panel}" data-k="${k}">${n}</button>`).join('')}</div>`;

/* ───────── formatting ───────── */
const FA = '۰۱۲۳۴۵۶۷۸۹';
T.dg = s => UI.digits === 'fa' ? String(s).replace(/[0-9]/g, d => FA[d]) : String(s);
T.fp = p => {
  p = Number(p); if (!isFinite(p) || p === 0) return '—';
  const a = Math.abs(p); let s;
  if (a >= 1000) s = p.toLocaleString('en', { maximumFractionDigits: 2 });
  else if (a >= 1) s = p.toFixed(a >= 100 ? 2 : 4).replace(/\.?0+$/, '');
  else s = p.toFixed(Math.min(12, Math.max(4, 3 - Math.floor(Math.log10(a))))).replace(/0+$/, '');
  return T.dg(s);
};
T.fpct = (v, d = 2) => { v = Number(v); if (!isFinite(v)) return '—'; return '\u2066' + T.dg((v > 0 ? '+' : '') + v.toFixed(d) + '٪') + '\u2069'; };
T.fnum = (v, d = 0) => { v = Number(v); return isFinite(v) ? T.dg(v.toLocaleString('en', { maximumFractionDigits: d, minimumFractionDigits: d })) : '—'; };
T.usd = v => { v = Number(v); return isFinite(v) ? T.dg((v < 0 ? '-' : '') + '$' + Math.abs(v).toLocaleString('en', { maximumFractionDigits: 2, minimumFractionDigits: 2 })) : '—'; };
T.ago = s => s == null ? '—' : T.dg(s < 90 ? s + ' ثانیه' : s < 5400 ? Math.round(s / 60) + ' دقیقه' : Math.round(s / 3600) + ' ساعت') + ' پیش';
T.SIDE_FA = { LONG: 'خرید', SHORT: 'فروش', WAIT: 'انتظار' };
T.col = s => s === 'LONG' ? 'var(--up)' : s === 'SHORT' ? 'var(--dn)' : 'var(--mu)';
T.scol = v => v >= 30 ? 'var(--up)' : v <= -30 ? 'var(--dn)' : v > 8 ? 'color-mix(in srgb,var(--up) 55%,var(--mu))' : v < -8 ? 'color-mix(in srgb,var(--dn) 55%,var(--mu))' : 'var(--mu)';
T.badge = s => `<span class="badge ${s}">${T.SIDE_FA[s] || s}</span>`;
T.REGIME_FA = { trend: 'روندی', range: 'رنج', neutral: 'گذار', unknown: '—' };

/* ───────── network ───────── */
T.api = async function (path, opt = {}) {
  const ctl = new AbortController(), to = setTimeout(() => ctl.abort(), opt.timeout || 25000);
  try {
    const r = await fetch(path, Object.assign({ signal: ctl.signal, headers: { 'Content-Type': 'application/json' } }, opt));
    const j = await r.json().catch(() => ({ error: 'پاسخ نامعتبر' }));
    if (!r.ok && !j.error) j.error = 'HTTP ' + r.status;
    return j;
  } catch (e) { return { error: e.name === 'AbortError' ? 'زمان درخواست تمام شد' : 'اتصال به سرور برقرار نشد' }; }
  finally { clearTimeout(to); }
};
T.toast = function (msg) {
  const box = T.$('#toast'), d = document.createElement('div'); d.textContent = msg; box.appendChild(d);
  setTimeout(() => d.remove(), 3200);
};

/* ───────── tooltip ───────── */
(function () {
  const tip = () => T.$('#tip'); let cur = null;
  const show = (el, x, y) => {
    const t = tip(), h = el.getAttribute('data-tip'); if (!h) return;
    if (cur !== el) { t.innerHTML = h; cur = el; }
    t.style.opacity = 1;
    const w = t.offsetWidth, hh = t.offsetHeight;
    t.style.left = Math.max(6, Math.min(innerWidth - w - 6, x + 14)) + 'px';
    t.style.top = Math.max(6, Math.min(innerHeight - hh - 6, y + 16)) + 'px';
  };
  document.addEventListener('pointermove', e => { const el = e.target.closest && e.target.closest('[data-tip]'); if (el) show(el, e.clientX, e.clientY); else { tip().style.opacity = 0; cur = null; } });
  document.addEventListener('pointerdown', e => { const el = e.target.closest && e.target.closest('[data-tip]'); if (el && e.pointerType === 'touch') show(el, e.clientX, e.clientY); else { tip().style.opacity = 0; cur = null; } });
  document.addEventListener('scroll', () => { tip().style.opacity = 0; cur = null; }, true);
})();

/* ───────── data loaders ───────── */
T.render = () => { try { T.R.all && T.R.all(); } catch (e) { console.error(e); } };
let tok = 0;
T.loadCoin = async function (sym, keep) {
  if (!sym) return; const my = ++tok; ST.sel = sym;
  if (!keep) { ST.coin = null; ST.deep = null; ST.ai = null; ST.micro = null; ST.bt = null; ST.mtf = {}; ST.pat = null; ST.planLab = null; ST.planSide = null; }
  T.render();
  const c = T.api(`/api/coin/${sym}?tf=${ST.tf}`), d = T.api(`/api/deep/${sym}?tf=${ST.tf}`);
  c.then(r => { if (my !== tok) return; ST.coin = r; T.render(); T.loadPat(sym, true); });
  d.then(r => { if (my !== tok) return; ST.deep = r; T.render(); });
  // Warm micro so summary/checklist see funding + depth without waiting for the micro tab
  T.loadMicro(sym, !keep);
};
T.loadPat = async function (sym, force) {
  sym = sym || ST.sel; if (!sym) return; if (!force && ST.pat && ST.pat.symbol === sym && ST.pat.tf === ST.tf && Date.now() - (ST.patAt || 0) < 45000) return;
  const my = ++ptok; const r = await T.api(`/api/patterns/${sym}?tf=${ST.tf}`, { timeout: 25000 }); if (my !== ptok || r.error) return; ST.pat = r; ST.patAt = Date.now();
  if (['coin', 'chart', 'desk', 'home'].includes(ST.panel) || ST.sheet) T.render();
};
let ptok = 0;
T.loadAlerts = async function () {
  const r = await T.api('/api/alerts'); if (r.error || !r.alerts) return; const first = !ST.alerts; ST.alerts = r.alerts; ST.seen = ST.seen || new Set(JSON.parse(localStorage.getItem('titan.seen') || '[]'));
  r.alerts.filter(a => a.fired && !ST.seen.has(a.id + ':' + a.fired.t)).forEach(a => { ST.seen.add(a.id + ':' + a.fired.t); if (!first || Date.now() / 1000 - a.fired.t < 120) T.notifyAlert(a.fired.msg); });
  localStorage.setItem('titan.seen', JSON.stringify([...ST.seen].slice(-80)));
  if (['home', 'coin', 'desk'].includes(ST.panel)) T.render();
};
T.beep = () => { try { const c = new (window.AudioContext || window.webkitAudioContext)(), o = c.createOscillator(), g = c.createGain(); o.connect(g); g.connect(c.destination); o.frequency.value = 880; g.gain.setValueAtTime(.15, c.currentTime); g.gain.exponentialRampToValueAtTime(.001, c.currentTime + .5); o.start(); o.stop(c.currentTime + .5); } catch (e) { /* no audio */ } };
T.notifyAlert = msg => { T.toast('🔔 ' + msg); if (UI.alertSound) T.beep(); if (UI.alertVib && navigator.vibrate) navigator.vibrate([120, 60, 120]); if (UI.alertNotify && window.Notification && Notification.permission === 'granted') { try { new Notification('TITAN PRO', { body: msg }); } catch (e) { /* ignore */ } } };
T.selectCoin = function (sym, panel) { ST.dtSel = null; T.loadCoin(sym); T.go(panel || (ST.panel === 'chart' ? 'chart' : 'coin')); };
T.loadMarket = async function () { const m = await T.api('/api/market'); if (!m.error) { ST.market = m; if (['mkt', 'desk', 'home'].includes(ST.panel) || ST.sheet) T.render(); } };
T.loadMicro = async function (sym, force) {
  sym = sym || ST.sel; if (!sym) return; if (!force && ST.micro && ST.micro.symbol === sym && Date.now() - ST.microAt < 12000) return;
  const my = ++mtok; const m = await T.api(`/api/micro/${sym}`, { timeout: 20000 }); if (my !== mtok) return; ST.micro = m; ST.microAt = Date.now(); if ((ST.panel === 'coin' && ST.tab.coin === 'micro') || ST.panel === 'desk' || ST.sheet) T.render();
};
let mtok = 0, btok = 0;
T.loadBt = async function () {
  if (!ST.sel || ST.btBusy) return; const my = ++btok; ST.btBusy = true; ST.bt = null; T.render();
  const r = await T.api(`/api/backtest/${ST.sel}?tf=${ST.tf}`, { timeout: 60000 }); if (my !== btok) return; ST.btBusy = false; ST.bt = r; T.render();
};
T.loadMtf = async function () {
  const sym = ST.sel; if (!sym) return; const my = ++tok2;
  await Promise.all(ST.tfs.map(async tf => { const r = await T.api(`/api/coin/${sym}?tf=${tf}`); if (my === tok2 && !r.error) ST.mtf[tf] = Object.assign({ sym }, r); }));
  if (my === tok2) T.render();
};
let tok2 = 0;
T.loadAuto = async function () { const [c, e] = await Promise.all([T.api('/api/auto/config'), T.api('/api/evidence')]); if (!c.error) ST.autoCfg = c; if (!e.error) ST.evid = e; if (ST.panel === 'ex') T.render(); };
T.loadAcct = async function () { const a = await T.api('/api/exchange'); if (!a.error) { ST.acct = a; if (['ex', 'home', 'desk'].includes(ST.panel) || ST.sheet) T.render(); } return a; };
T.loadMatrix = async function () {
  const m = await T.api('/api/matrix'); if (m.error) return;
  ST.matrix = m.matrix || {}; ST.tfs = m.timeframes || ST.tfs; ST.at = m.at; ST.scanning = m.scanning; ST.prog = m.progress || ST.prog;
  if (!ST.sel) { const k = Object.keys(ST.matrix); if (k.length) { ST.sel = k.includes('BTCUSDT') ? 'BTCUSDT' : k[0]; T.loadCoin(ST.sel); } }
};
T.loadStatus = async function () {
  const s = await T.api('/api/status'); if (s.error) { ST.status = null; renderHead(); return; }
  ST.status = s; if (s.threshold) T.TH = s.threshold; ST.syms = s.symbols || []; ST.scanning = s.scanning; ST.prog = s.progress || ST.prog; renderHead();
};
function renderHead() {
  const s = ST.status, led = T.$('#status .led'), txt = T.$('#st-txt'), lbl = T.$('#scan-lbl'), btn = T.$('#btn-scan');
  if (!s) { led.className = 'led bad'; txt.textContent = 'قطع ارتباط'; return; }
  const src = Object.values(s.sources || {}), okc = src.filter(x => !x.cooling && x.ok > 0).length;
  led.className = 'led ' + (ST.scanning ? 'busy' : okc ? 'ok' : 'bad');
  txt.textContent = ST.scanning ? T.dg(`اسکن ${ST.prog.done}/${ST.prog.total}`) : s.last_scan ? T.dg(`${okc}/${src.length} منبع · ${T.ago(Math.round(Date.now() / 1000 - s.last_scan))}`) : 'در انتظار اولین اسکن';
  lbl.textContent = ST.scanning ? T.dg(Math.round(ST.prog.done / Math.max(1, ST.prog.total) * 100) + '٪') : 'اسکن';
  btn.disabled = false;
}
T.doScan = async function (full = true) {
  const r = await T.api('/api/scan' + (full ? '?full=1' : '?tf=1h'), { method: 'POST' });
  if (r.status === 'busy') T.toast('اسکن در حال اجراست…'); else if (r.error) T.toast(r.error); else { ST.scanning = true; T.toast('اسکن شروع شد'); }
  schedule(600);
};
let timer, tickN = 0;
function schedule(ms) { clearTimeout(timer); timer = setTimeout(tick, ms); }
async function tick() {
  tickN++;
  await Promise.all([T.loadStatus(), T.loadMatrix()]);
  if (tickN % 3 === 0 || ST.panel === 'ex') T.loadAcct();
  if (ST.panel === 'ex' && tickN % 4 === 0) T.loadAuto();
  if (ST.panel === 'mkt' && (tickN % 2 === 0 || !ST.market)) T.loadMarket();
  if (tickN % 2 === 1 || ST.panel === 'home' && !ST.market) { T.loadAlerts(); if (!ST.market) T.loadMarket(); }
  if (ST.panel === 'home' && tickN % 4 === 0) T.loadMarket();
  if (ST.panel === 'coin' && ST.tab.coin === 'micro') T.loadMicro(ST.sel);
  if (ST.panel === 'coin' && ST.tab.coin === 'plan') T.loadPlan();
  T.render(); renderHead();
  if (ST.sel && !ST.scanning && tickN % 4 === 0) { const [c, d] = await Promise.all([T.api(`/api/coin/${ST.sel}?tf=${ST.tf}`), T.api(`/api/deep/${ST.sel}?tf=${ST.tf}`)]); if (!c.error) ST.coin = c; if (!d.error) ST.deep = d; T.render(); }
  schedule(ST.scanning ? 2200 : 15000);
}

/* ───────── navigation + actions ───────── */
T.go = function (p) {
  if (!T.$('#p-' + p)) p = 'home';
  ST.panel = p;
  T.$$('.panel').forEach(e => e.classList.toggle('on', e.id === 'p-' + p));
  T.$$('#nav button').forEach(b => b.classList.toggle('on', b.dataset.p === p));
  if (location.hash !== '#' + p) history.replaceState(null, '', '#' + p);
  if (p === 'ex') { T.loadAcct(); T.loadAuto(); }
  if (p === 'mkt') T.loadMarket();
  if ((p === 'coin' || p === 'chart') && ST.sel && !ST.coin) T.loadCoin(ST.sel, true);
  T.render(); scrollTo({ top: 0 });
};
let rzT, lastPhone = innerWidth < 640;
window.addEventListener('resize', () => { clearTimeout(rzT); rzT = setTimeout(() => { const ph = innerWidth < 640; if (ph !== lastPhone) { lastPhone = ph; T.render(); } }, 200); });
window.addEventListener('hashchange', () => { const p = location.hash.slice(1); if (p && p !== ST.panel) T.go(p); });
Object.assign(T.acts, {
  nav: t => T.go(t.dataset.p),
  scan: () => T.doScan(true),
  sel: t => T.selectCoin(t.dataset.sym),
  tf: t => { ST.tf = t.dataset.tf; ST.bt = null; ST.pat = null; T.loadCoin(ST.sel, true); },
  tab: t => { const pn = t.dataset.pn, k = t.dataset.k; ST.tab[pn] = k; if (pn === 'coin' && k === 'micro') T.loadMicro(ST.sel, true); if (pn === 'coin' && k === 'plan') T.loadPlan(true); if (pn === 'chart' && k === 'mtf') T.loadMtf(); T.render(); scrollTo({ top: 0 }); },
  'theme-cycle': () => {
    const list = T.PRESETS || [];
    if (!list.length) return;
    let i = list.findIndex(p => p.id === UI.preset);
    if (i < 0) i = 0;
    const next = list[(i + 1) % list.length];
    T.acts.preset({ dataset: { id: next.id } });
  },
  preset: t => {
    const id = t.dataset.id || t.value; if (!id) return;
    T.applyThemeProfile(id);
    const U = T.UI = (T.UI || UI || {});
    try { UI = U; } catch (e) {}
    const p = (T.PRESETS || []).find(x => x.id === id);
    try {
      const b = document.body;
      b.className = (b.className || '').split(/\s+/).filter(x => x && !x.startsWith('theme-')).concat(['theme-' + id]).join(' ');
      if (p) {
        b.style.background = 'linear-gradient(165deg,' + p.bg1 + ',' + p.bg2 + ')';
        b.style.color = p.dark ? '#e8f2ff' : '#0c2038';
        const r = document.documentElement.style;
        r.setProperty('--bg1', p.bg1); r.setProperty('--bg2', p.bg2);
        r.setProperty('--a', p.a); r.setProperty('--b', p.b); r.setProperty('--c', p.c);
        r.setProperty('--up', p.up); r.setProperty('--dn', p.dn); r.setProperty('--go', p.go);
      }
    } catch (e) {}
    try { T.applyUI(); } catch (e) {}
    try { T.saveUI(); } catch (e) {}
    if (T.R) {
      try { if (T.R.set) T.R.set(true); } catch (e) {}
      try { T.render(); } catch (e) {}
    }
    T.toast && T.toast('تم: ' + ((p && p.name) || id));
  },
  skin: t => { T.applySkin(t.dataset.id); },
  'adv-set': () => T.openAdv(),
  'adv-close': () => T.closeAdv(),
  'adv-apply': () => { T.saveUI(); T.closeAdv(); T.toast('اعمال شد'); },

});
function handleAct(e) {
  const t = e.target.closest && e.target.closest('[data-act]');
  if (t) {
    const f = T.acts[t.dataset.act];
    if (f) { e.preventDefault && e.preventDefault(); f(t, e); return true; }
  }
  const s = e.target.closest && e.target.closest('[data-sym]');
  if (s) { T.selectCoin(s.dataset.sym); return true; }
  return false;
}
document.addEventListener('click', e => { handleAct(e); });
document.addEventListener('pointerup', e => {
  // mobile: ensure theme/skin taps register
  const t = e.target.closest && e.target.closest('[data-act]');
  if (t && (t.dataset.act === 'preset' || t.dataset.act === 'skin')) handleAct(e);
});
const parse = t => t.type === 'range' || t.type === 'number' ? Number(t.value) : t.value;
document.addEventListener('input', e => {
  const el = e.target;
  if (el && el.dataset && el.dataset.set) {
    const parse = t => t.type === 'range' || t.type === 'number' ? Number(t.value) : (t.type === 'checkbox' ? t.checked : t.value);
    T.setUI(el.dataset.set, parse(el));
  }
});
document.addEventListener('change', e => {
  const el = e.target;
  if (!el || !el.dataset || !el.dataset.set) return;
  if (el.tagName === 'SELECT' || el.type === 'color') {
    T.setUI(el.dataset.set, el.value);
  }
});

/* ───────── boot ───────── */
T.boot = async function () {
  T.applyUI(); ST.tf = UI.defTf || '1h';
  const p = location.hash.slice(1); if (p) ST.panel = T.$('#p-' + p) ? p : 'home';
  T.go(ST.panel);
  const s = await T.api('/api/settings');
  if (s && s.ui && s.ui._ts > (UI._ts || 0)) { UI = T.UI = mergeUI(s.ui); T.applyUI(); try { localStorage.setItem('titan.ui', JSON.stringify(UI)); } catch (e) { /* noop */ } }
  ST.syms = s.watchlist || []; T.render();
  tick(); T.loadAcct();
};
window.addEventListener('DOMContentLoaded', () => { if (T.R.all) T.boot(); });

/* ── quick personalize sheet ── */
T.openUISheet = function () {
  const sk = document.getElementById('qs-skin');
  const th = document.getElementById('qs-theme');
  if (sk) {
    sk.innerHTML = (T.SKINS || []).slice(0, 8).map(s =>
      `<button type="button" class="${T.UI.skin === s.id ? 'on' : ''}" data-act="skin" data-id="${s.id}">${s.name}</button>`
    ).join('');
  }
  if (th) {
    const picks = (T.PRESETS || []).slice(0, 20);
    th.innerHTML = picks.map(p =>
      `<button type="button" class="${T.UI.preset === p.id ? 'on' : ''}" data-act="preset" data-id="${p.id}" style="background:linear-gradient(145deg,${p.bg1},${p.bg2})">${p.name}</button>`
    ).join('');
  }
  const g = document.getElementById('qs-glow'); if (g) g.value = T.UI.glow;
  const b = document.getElementById('qs-blur'); if (b) b.value = T.UI.blur;
  const r = document.getElementById('qs-radius'); if (r) r.value = T.UI.radius;
  const f = document.getElementById('qs-fs'); if (f) f.value = T.UI.fs;
  document.getElementById('ui-backdrop')?.classList.add('on');
  document.getElementById('ui-sheet')?.classList.add('open');
};
T.closeUISheet = function () {
  document.getElementById('ui-backdrop')?.classList.remove('on');
  document.getElementById('ui-sheet')?.classList.remove('open');
};
function bindUISheet() {
  document.getElementById('fab-ui')?.addEventListener('click', () => T.openUISheet());
  document.getElementById('ui-backdrop')?.addEventListener('click', () => T.closeUISheet());
  document.getElementById('qs-close')?.addEventListener('click', () => T.closeUISheet());
  ['qs-glow', 'qs-blur', 'qs-radius', 'qs-fs'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input', () => {
      const map = { 'qs-glow': 'glow', 'qs-blur': 'blur', 'qs-radius': 'radius', 'qs-fs': 'fs' };
      T.setUI(map[id], +el.value); T.applyUI(); T.saveUI();
    });
  });
  document.querySelectorAll('#ui-sheet [data-den]').forEach(btn => {
    btn.addEventListener('click', () => {
      T.setUI('density', btn.dataset.den); T.applyUI(); T.saveUI();
      document.body.dataset.density = btn.dataset.den;
    });
  });
}


function _bindExtras() {
  try { bindUISheet(); } catch (e) { console.warn('ui sheet', e); }
  try { bindAdv(); } catch (e) { console.warn('adv', e); }
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _bindExtras);
else _bindExtras();


/* ── advanced settings window ── */
T._advTab = 'ui';
T.openAdv = function () {
  const bd = document.getElementById('adv-backdrop');
  const win = document.getElementById('adv-win');
  if (!win) return;
  bd && bd.removeAttribute('hidden');
  win.removeAttribute('hidden');
  T.renderAdv();
};
T.closeAdv = function () {
  document.getElementById('adv-backdrop')?.setAttribute('hidden', '');
  document.getElementById('adv-win')?.setAttribute('hidden', '');
};
T.renderAdv = function () {
  const body = document.getElementById('adv-body');
  if (!body) return;
  const U = T.UI || {};
  const tab = T._advTab || 'ui';
  document.querySelectorAll('#adv-tabs button').forEach(b => b.classList.toggle('on', b.dataset.advTab === tab));
  const sw = (key, on) => `<span class="adv-sw ${on ? 'on' : ''}" data-adv-sw="${key}"></span>`;
  const rng = (key, min, max, step, val) =>
    `<input type="range" data-adv-rng="${key}" min="${min}" max="${max}" step="${step}" value="${val}"> <small class="mu">${val}</small>`;
  const num = (key, val, min, max) =>
    `<input type="number" data-adv-num="${key}" value="${val}" min="${min}" max="${max}">`;
  const sel = (key, opts, cur) =>
    `<select data-adv-sel="${key}">${opts.map(([v, n]) => `<option value="${v}" ${String(v) === String(cur) ? 'selected' : ''}>${n}</option>`).join('')}</select>`;

  let html = '';
  if (tab === 'ui') {
    html = `<h5>پریسم · تم و شیشه</h5>
      <div class="fld"><label>تم شیشه‌ای (۲۰ تم)</label>${sel('preset', (T.PRESETS || []).map(p => [p.id, p.name]), U.preset)}</div>
      <div class="fld"><label>سبک کارت</label>${sel('card', [['prism','پریسم'],['glass','شیشه'],['neon','نئون']], U.card)}</div>
      <div class="fld"><label>درخشش</label>${rng('glow', 0, 2.5, 0.05, U.glow ?? 1)}</div>
      <div class="fld"><label>محو شیشه</label>${rng('blur', 0, 40, 1, U.blur ?? 14)}</div>
      <div class="fld"><label>شفافیت شیشه</label>${rng('glassA', 0.15, 0.9, 0.05, U.glassA ?? 0.55)}</div>
      <div class="fld"><label>هایلایت / اشباع / سایه</label>${rng('hls', 0, 1.2, 0.05, U.hls ?? 0.55)} ${rng('sat', 0.6, 2.2, 0.05, U.sat ?? 1.5)} ${rng('shd', 0, 2, 0.1, U.shd ?? 1)}</div>
      <div class="fld"><label>درخشش پریسم / لبه</label>${rng('prismShine', 0, 1.5, 0.05, U.prismShine ?? 0.7)} ${rng('prismBorder', 0.4, 2.5, 0.1, U.prismBorder ?? 1.2)}</div>
      <div class="fld"><label>گردی / ضخامت لبه</label>${rng('radius', 0, 36, 1, U.radius ?? 16)} ${rng('bw', 0, 3, 0.5, U.bw ?? 1)}</div>
      <div class="fld"><label>تراکم / ستون</label>${sel('density', [['compact','فشرده'],['comfy','معمولی'],['roomy','راحت']], U.density)} ${sel('cols', [['auto','خودکار'],['1','۱'],['2','۲'],['3','۳']], U.cols)}</div>
      <div class="fld"><label>مقیاس KPI / سلول حرارتی</label>${rng('kpiScale', 0.75, 1.4, 0.05, U.kpiScale ?? 1)} ${rng('heatSize', 40, 72, 2, U.heatSize ?? 52)}</div>
      <div class="fld"><label>پس‌زمینه</label>${sel('bg', [['shapes','اشکال'],['mesh','مش'],['aurora','شفق'],['grid','شبکه'],['none','ساده']], U.bg)}</div>
      <div class="fld"><label>قدرت/سرعت اشکال</label>${rng('shapeOp', 0.15, 1, 0.05, U.shapeOp ?? 0.55)} ${rng('shapeSpeed', 0.3, 2, 0.1, U.shapeSpeed ?? 1)}</div>
      <div class="fld"><label>اندازه متن / وزن</label>${rng('fs', 12, 20, 1, U.fs ?? 15)} ${rng('weight', 300, 700, 50, U.weight ?? 400)}</div>
      <div class="fld"><label>حرکت</label>${sel('motion', [['on','روشن'],['off','خاموش'],['auto','خودکار']], U.motion)} ${rng('speed', 0.4, 2, 0.1, U.speed ?? 1)}</div>
      <div class="fld"><label>عرض صفحه</label>${sel('maxw', [[1100,'۱۱۰۰'],[1320,'۱۳۲۰'],[1600,'۱۶۰۰'],[1920,'۱۹۲۰'],[3000,'تمام']], U.maxw)}</div>
      <div class="note">همه کنترل‌ها زنده به داشبورد پریسم متصل‌اند.</div>`;
  } else if (tab === 'data') {
    html = `<h5>داده و نمودار</h5>
      <div class="fld"><label>تعداد کندل</label>${sel('chartN', [[0, 'خودکار'], [30, '۳۰'], [60, '۶۰'], [90, '۹۰'], [140, '۱۴۰']], U.chartN ?? 0)}</div>
      <div class="fld"><label>ارتفاع نمودار</label>${rng('chartH', 0.7, 1.6, 0.05, U.chartH ?? 1)}</div>
      <div class="fld"><label>نوع کندل</label>${sel('candle', [['solid', 'توپر'], ['hollow', 'توخالی'], ['bars', 'میله'], ['line', 'خطی']], U.candle || 'solid')}</div>
      <div class="fld"><label>شبکه نمودار</label>${sw('grid', U.grid !== 0 && U.grid !== false)}</div>
      <div class="fld"><label>ارقام</label>${sel('digits', [['en', 'انگلیسی'], ['fa', 'فارسی']], U.digits || 'en')}</div>`;
  } else {
    html = `<h5>سیستم</h5>
      <div class="fld"><label>عملکرد</label>${sel('perf', [['auto', 'خودکار'], ['high', 'کامل'], ['low', 'سبک']], U.perf || 'auto')}</div>
      <div class="fld"><label>خروجی JSON ظاهر</label><button type="button" class="btn" data-act="adv-export">کپی</button></div>
      <div class="fld"><label>بازنشانی ظاهر</label><button type="button" class="btn" data-act="adv-reset">ریست</button></div>
      <div class="note">داده و حافظه فقط داخل پوشه UUU/VVV ذخیره می‌شود.</div>`;
  }
  body.innerHTML = html;

  body.querySelectorAll('[data-adv-rng]').forEach(el => {
    el.addEventListener('input', () => {
      const k = el.dataset.advRng;
      const v = +el.value;
      const sm = el.parentElement.querySelector('small');
      if (sm) sm.textContent = v;
      T.setUI(k, v); T.applyUI();
    });
  });
  body.querySelectorAll('[data-adv-sel]').forEach(el => {
    el.addEventListener('change', () => {
      const k = el.dataset.advSel;
      if (k === 'skin') { T.applySkin?.(el.value); }
      else { T.setUI(k, el.value); if (k === 'preset') T.setUI('colors', {}); }
      T.applyUI();
    });
  });
  body.querySelectorAll('[data-adv-sw]').forEach(el => {
    el.addEventListener('click', () => {
      const k = el.dataset.advSw;
      el.classList.toggle('on');
      const on = el.classList.contains('on');
      if (k === 'cardGlass') T.setUI('card', on ? 'glass' : 'solid');
      else T.setUI(k, on);
      T.applyUI();
    });
  });
};

function bindAdv() {
  document.getElementById('btn-adv-set')?.addEventListener('click', e => { e.preventDefault(); T.openAdv(); });
  document.getElementById('adv-close')?.addEventListener('click', () => T.closeAdv());
  document.getElementById('adv-backdrop')?.addEventListener('click', () => T.closeAdv());
  document.getElementById('adv-apply')?.addEventListener('click', () => { T.saveUI(); T.closeAdv(); T.toast?.('تنظیمات پیشرفته اعمال شد'); });
  document.querySelectorAll('#adv-tabs button').forEach(b => {
    b.addEventListener('click', () => { T._advTab = b.dataset.advTab; T.renderAdv(); });
  });
  document.addEventListener('click', e => {
    const t = e.target.closest('[data-act]');
    if (!t) return;
    if (t.dataset.act === 'adv-set') { e.preventDefault(); T.openAdv(); }
    if (t.dataset.act === 'adv-close') T.closeAdv();
    if (t.dataset.act === 'adv-apply') { T.saveUI(); T.closeAdv(); T.toast?.('اعمال شد'); }
    if (t.dataset.act === 'adv-export') {
      try {
        navigator.clipboard.writeText(JSON.stringify(T.UI, null, 2));
        T.toast?.('JSON کپی شد');
      } catch (err) { T.toast?.('کپی ناموفق'); }
    }
    if (t.dataset.act === 'adv-reset') {
      if (confirm('بازنشانی تنظیمات ظاهری؟')) { T.resetUI?.(); T.renderAdv(); T.toast?.('ریست شد'); }
    }
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') T.closeAdv(); });
}
/* bindAdv via _bindExtras */

})();

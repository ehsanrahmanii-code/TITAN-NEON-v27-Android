/* TITAN Prism shell — panels only */
(function () {
'use strict';
const T = window.T, ST = T.ST, $ = T.$, $$ = T.$$;

const NAV = {
  panels: [
    ['home', 'home', 'خانه'],
    ['coin', 'target', 'تحلیل'],
    ['chart', 'chart', 'نمودار'],
    ['mkt', 'radar', 'بازار'],
    ['ex', 'wallet', 'صرافی'],
    ['set', 'gear', 'تنظیمات'],
  ],
};

function buildNav() {
  const nav = $('#nav');
  if (!nav) return;
  const items = NAV.panels;
  nav.dataset.shell = 'panels';
  nav.innerHTML = items.map(([p, ic, n]) =>
    `<button data-act="nav" data-p="${p}" class="${p === (ST && ST.panel) ? 'on' : ''}"><svg><use href="#i-${ic}"/></svg>${n}</button>`
  ).join('');
}

const _go = T.go;
T.go = function (p) {
  if (p === 'desk' || p === 'wall' || p === 'terminal') p = 'home';
  if (_go) return _go.call(this, p);
};

const _applyUI = T.applyUI;
T.applyUI = function () {
  if (T.UI) { T.UI.shell = 'panels'; T.UI.skin = 'prism'; }
  if (_applyUI) _applyUI.apply(this, arguments);
  if (document.body) {
    document.body.dataset.shell = 'panels';
    document.body.dataset.skin = 'prism';
  }
  try { buildNav(); } catch (e) {}
};

T.applyShell = function () {
  if (T.UI) T.UI.shell = 'panels';
  T.applyUI && T.applyUI();
  T.saveUI && T.saveUI();
  buildNav();
  T.render && T.render();
};

T.shellGallery = function () {
  return '<div class="note">رابط فقط <b>پریسم شیشه‌ای</b> است.</div>';
};

T.R = T.R || {};
T.R.desk = function () {
  if (ST) ST.panel = 'home';
  if (T.R.home) T.R.home();
};

if (T.acts) {
  T.acts['shell-cycle'] = () => T.toast && T.toast('فقط رابط پریسم');
  T.acts.shell = () => T.toast && T.toast('فقط رابط پریسم');
}

try { buildNav(); } catch (e) {}
})();

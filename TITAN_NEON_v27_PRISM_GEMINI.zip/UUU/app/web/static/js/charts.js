/* TITAN PRO NEON — graphics library: gauges, schematics, radar, ladder, canvas candle chart (zero dependencies) */
(function () {
'use strict';
const T = window.T, esc = T.esc, ch = T.ch = {};
let _u = 0; const uid = () => 'g' + (++_u);
const W_TF = { '15m': .15, '1h': .25, '4h': .30, '1d': .30 };
T.cons = function (row) {
  let s = 0, w = 0; for (const tf in row.tfs || {}) { const x = W_TF[tf] || .2; s += x * row.tfs[tf].score; w += x; }
  return w ? s / w : 0;
};
T.TH = 36;
T.consSide = v => v >= T.TH ? 'LONG' : v <= -T.TH ? 'SHORT' : 'WAIT';
const sgn = v => '\u200E' + (v > 0 ? '+' : '') + Math.round(v) + '\u200E';
const pol = (cx, cy, r, deg) => [cx + r * Math.cos(deg * Math.PI / 180), cy + r * Math.sin(deg * Math.PI / 180)];
const arc = (cx, cy, r, a0, a1) => { const [x0, y0] = pol(cx, cy, r, a0), [x1, y1] = pol(cx, cy, r, a1); return `M${x0.toFixed(1)} ${y0.toFixed(1)}A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1.toFixed(1)} ${y1.toFixed(1)}`; };
const lerp = (a, b, t) => a + (b - a) * t;

/* ── semicircle gauge (-100..100) ── */
ch.gauge = function (v, label, sub) {
  v = Math.max(-100, Math.min(100, Number(v) || 0)); const cx = 130, cy = 120, r = 92, ang = 180 + (v + 100) / 200 * 180;
  const segs = [[180, 234, 'var(--dn)'], [234, 306, 'var(--mu)'], [306, 360, 'var(--up)']];
  let ticks = ''; for (let i = 0; i <= 20; i++) { const a = 180 + i * 9, [x0, y0] = pol(cx, cy, r + 5, a), [x1, y1] = pol(cx, cy, r + (i % 5 ? 9 : 14), a); ticks += `<path d="M${x0} ${y0}L${x1} ${y1}" stroke="var(--mu)" stroke-width="${i % 5 ? 1 : 2}" opacity=".7"/>`; }
  const [nx, ny] = pol(cx, cy, r - 14, ang), col = T.scol(v);
  return `<svg viewBox="0 0 260 170" role="img"><defs><filter id="gg"><feGaussianBlur stdDeviation="3"/></filter></defs>
  ${segs.map(s => `<path d="${arc(cx, cy, r, s[0], s[1])}" stroke="${s[2]}" stroke-width="12" fill="none" opacity=".28" stroke-linecap="round"/>`).join('')}
  <path d="${arc(cx, cy, r, 180, ang)}" stroke="${col}" stroke-width="12" fill="none" stroke-linecap="round" style="filter:drop-shadow(0 0 calc(var(--glow)*7px) ${col})"/>
  ${ticks}<path d="M${cx} ${cy}L${nx.toFixed(1)} ${ny.toFixed(1)}" stroke="var(--tx)" stroke-width="3" stroke-linecap="round"/><circle cx="${cx}" cy="${cy}" r="8" fill="var(--pn2)" stroke="${col}" stroke-width="3"/>
  <text x="${cx}" y="${cy - 34}" text-anchor="middle" font-size="30" font-weight="800" fill="${col}">${T.dg(sgn(v))}</text>
  <text x="${cx}" y="${cy + 24}" text-anchor="middle" font-size="12" fill="var(--tx)" font-weight="700">${esc(label || '')}</text>
  <text x="${cx}" y="${cy + 40}" text-anchor="middle" font-size="10" fill="var(--mu)">${esc(sub || '')}</text></svg>`;
};

/* ── donut ── */
ch.donut = function (parts, top, sub) {
  const R = 54, C = 2 * Math.PI * R, tot = parts.reduce((a, p) => a + p.v, 0) || 1; let off = 0, s = '';
  parts.forEach(p => { const len = p.v / tot * C; s += `<circle cx="70" cy="70" r="${R}" fill="none" stroke="${p.c}" stroke-width="14" stroke-dasharray="${Math.max(0, len - 3).toFixed(1)} ${C.toFixed(1)}" stroke-dashoffset="${(-off).toFixed(1)}" transform="rotate(-90 70 70)" data-tip="${esc(p.l)}: ${T.dg(p.v)}" style="filter:drop-shadow(0 0 calc(var(--glow)*4px) ${p.c})"/>`; off += len; });
  return `<svg viewBox="0 0 140 140"><circle cx="70" cy="70" r="${R}" fill="none" stroke="var(--ln)" stroke-width="14" opacity=".5"/>${s}<text x="70" y="72" text-anchor="middle" font-size="26" font-weight="800" fill="var(--tx)">${T.dg(top)}</text><text x="70" y="90" text-anchor="middle" font-size="9.5" fill="var(--mu)">${esc(sub || '')}</text></svg>`;
};

/* ── sparkline with optional forecast cone ── */
ch.spark = function (arr, w, h, col, fc) {
  if (!arr || arr.length < 3) return '';
  const past = arr, n = past.length; let all = past.slice();
  if (fc && fc.p50 && fc.p50.length) all = all.concat(fc.p10, fc.p90);
  let lo = Math.min(...all), hi = Math.max(...all); if (hi === lo) { hi += 1; lo -= 1; }
  const m = fc && fc.p50 ? fc.p50.length : 0, tot = n + m, X = i => 2 + i / (tot - 1) * (w - 4), Y = v => 3 + (1 - (v - lo) / (hi - lo)) * (h - 6);
  const line = past.map((v, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)} ${Y(v).toFixed(1)}`).join('');
  const id = uid(); let cone = '', mid = '';
  if (m) {
    const up = [[X(n - 1), Y(past[n - 1])]].concat(fc.p90.map((v, i) => [X(n + i), Y(v)])), dn = [[X(n - 1), Y(past[n - 1])]].concat(fc.p10.map((v, i) => [X(n + i), Y(v)])).reverse();
    cone = `<path d="M${up.concat(dn).map(p => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join('L')}Z" fill="${col}" opacity=".18"/>`;
    mid = `<path d="M${X(n - 1).toFixed(1)} ${Y(past[n - 1]).toFixed(1)}${fc.p50.map((v, i) => `L${X(n + i).toFixed(1)} ${Y(v).toFixed(1)}`).join('')}" stroke="${col}" stroke-width="1.6" stroke-dasharray="3 3" fill="none"/>`;
  }
  return `<svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" preserveAspectRatio="none"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".35"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs>
  <path d="${line}L${X(n - 1).toFixed(1)} ${h}L2 ${h}Z" fill="url(#${id})"/>${cone}<path d="${line}" stroke="${col}" stroke-width="1.6" fill="none" stroke-linejoin="round"/>${mid}</svg>`;
};

/* ── radar of component groups ── */
ch.radar = function (axes) {
  const S = 220, c = S / 2, R = 78, n = axes.length; const P = (i, k) => pol(c, c, R * k, -90 + 360 * i / n);
  let g = ''; [.25, .5, .75, 1].forEach(k => g += `<polygon points="${axes.map((_, i) => P(i, k).map(x => x.toFixed(1)).join(',')).join(' ')}" fill="none" stroke="var(--ln)" stroke-dasharray="${k === .5 ? '0' : '2 3'}"/>`);
  const pts = axes.map((a, i) => P(i, (Math.max(-1, Math.min(1, a.v)) + 1) / 2));
  const tot = axes.reduce((s, a) => s + a.v, 0), col = tot > 0.4 ? 'var(--up)' : tot < -0.4 ? 'var(--dn)' : 'var(--a)';
  return `<svg viewBox="0 0 ${S} ${S}">${g}${axes.map((a, i) => { const [x, y] = P(i, 1); return `<path d="M${c} ${c}L${x.toFixed(1)} ${y.toFixed(1)}" stroke="var(--ln)"/>`; }).join('')}
  <polygon points="${pts.map(p => p.map(x => x.toFixed(1)).join(',')).join(' ')}" fill="${col}" fill-opacity=".22" stroke="${col}" stroke-width="2" style="filter:drop-shadow(0 0 calc(var(--glow)*6px) ${col})"/>
  ${axes.map((a, i) => { const [x, y] = P(i, 1.2), [px, py] = pts[i]; return `<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="4" fill="${col}" data-tip="${esc(a.n)}: ${T.dg(sgn(a.v * 100))}"/><text x="${x.toFixed(1)}" y="${(y + 3).toFixed(1)}" text-anchor="middle" font-size="10" fill="var(--mu)">${esc(a.n)}</text>`; }).join('')}</svg>`;
};

/* ── price ladder: entry / SL / TPs on a vertical rail ── */
ch.ladder = function (s, price) {
  if (!s || s.side === 'WAIT') return `<div class="empty">برای سیگنال «انتظار» نردبان قیمتی ساخته نمی‌شود.<br><span class="note">در صورت تمایل با دکمه‌های باز کردن پوزیشن، سمت را دستی انتخاب کنید.</span></div>`;
  const lv = [['TP3', s.tp3, 'var(--up)'], ['TP2', s.tp2, 'var(--up)'], ['TP1', s.tp1, 'var(--up)'], ['ورود', s.entry, 'var(--a)'], ['حدضرر', s.stop, 'var(--dn)']];
  const vals = lv.map(l => l[1]).concat(price ? [price] : []); let hi = Math.max(...vals), lo = Math.min(...vals); const pad = (hi - lo) * .08 || hi * .01; hi += pad; lo -= pad;
  const H = 300, Y = v => 10 + (hi - v) / (hi - lo) * (H - 20), X0 = 118, ye = Y(s.entry), ys = Y(s.stop), yt = Y(s.tp3), id = uid();
  const pct = v => ((v - s.entry) / s.entry * 100);
  return `<svg viewBox="0 0 330 ${H}"><defs><linearGradient id="${id}r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--dn)" stop-opacity=".05"/><stop offset="1" stop-color="var(--dn)" stop-opacity=".4"/></linearGradient>
  <linearGradient id="${id}g" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="var(--up)" stop-opacity=".05"/><stop offset="1" stop-color="var(--up)" stop-opacity=".4"/></linearGradient></defs>
  <rect x="${X0 - 9}" y="${Math.min(ye, ys)}" width="18" height="${Math.abs(ys - ye)}" fill="url(#${id}r)" rx="4"/><rect x="${X0 - 9}" y="${Math.min(ye, yt)}" width="18" height="${Math.abs(yt - ye)}" fill="url(#${id}g)" rx="4"/>
  <path d="M${X0} 6V${H - 6}" stroke="var(--ln)" stroke-width="2"/>
  ${lv.map(l => { const y = Y(l[1]); return `<g data-tip="${l[0]}: ${T.fp(l[1])} (${T.fpct(pct(l[1]))})"><path d="M${X0 - 20} ${y}H${X0 + 20}" stroke="${l[2]}" stroke-width="2.4" style="filter:drop-shadow(0 0 calc(var(--glow)*5px) ${l[2]})"/><circle cx="${X0}" cy="${y}" r="4.5" fill="var(--pn2)" stroke="${l[2]}" stroke-width="2"/>
    <text x="${X0 - 28}" y="${y + 4}" text-anchor="end" font-size="11" fill="${l[2]}" font-weight="700">${l[0]}</text><text x="${X0 + 28}" y="${y - 1}" font-size="11.5" fill="var(--tx)" font-weight="700">${T.fp(l[1])}</text><text x="${X0 + 28}" y="${y + 11}" font-size="9.5" fill="var(--mu)">${T.fpct(pct(l[1]))}</text></g>`; }).join('')}
  ${price ? (() => { const y = Y(price); return `<path d="M${X0 + 112} ${y - 6}L${X0 + 102} ${y}L${X0 + 112} ${y + 6}Z" fill="var(--go)"/><path d="M${X0 + 20} ${y}H${X0 + 102}" stroke="var(--go)" stroke-width="1" stroke-dasharray="2 3" opacity=".7"/><text x="${X0 + 116}" y="${y + 4}" font-size="10" fill="var(--go)">اکنون</text>`; })() : ''}</svg>`;
};

/* ── indicator decision-tree schematic ── */
ch.tree = function (s, selK) {
  const cs = (s.components || []).slice().sort((a, b) => Math.abs(b.s * b.w) - Math.abs(a.s * a.w)), n = cs.length, rh = 25, H = n * rh + 24, cy = H / 2, nx = 520, nw = 236;
  let wires = '', nodes = '';
  cs.forEach((c, i) => {
    const y = 14 + i * rh + 9, col = c.s > .05 ? 'var(--up)' : c.s < -.05 ? 'var(--dn)' : 'var(--mu)', a = Math.abs(c.s), sel = c.k === selK;
    wires += `<path d="M${nx} ${y}C440 ${y},420 ${cy},362 ${cy}" fill="none" stroke="${col}" stroke-width="${(.8 + a * c.w * 2.2).toFixed(2)}" opacity="${(.22 + a * .7).toFixed(2)}" ${a > .3 ? 'class="flow" style="stroke-dasharray:6 8"' : ''}/>`;
    nodes += `<g class="node ${sel ? 'sel' : ''}" data-act="dt" data-k="${c.k}" data-tip="<b>${esc(c.n)}</b><br>${esc(c.t)}<br>وزن ${T.dg(c.w)} · گروه ${esc(c.g)}">
      <rect x="${nx}" y="${y - 10}" width="${nw}" height="20" rx="6" fill="color-mix(in srgb,${col} ${8 + a * 18}%,var(--pn2))" stroke="${col}" stroke-width="${sel ? 2.4 : 1}"/>
      <rect x="${nx + 6}" y="${y - 3}" width="${(a * 52).toFixed(1)}" height="6" rx="3" fill="${col}"/>
      <text x="${nx + nw - 8}" y="${y + 4}" text-anchor="end" font-size="11" fill="var(--tx)">${esc(c.n)}</text><text x="${nx + 64}" y="${y + 4}" font-size="9.5" fill="${col}">${T.dg(sgn(c.s * 100))}</text></g>`;
  });
  const col = T.col(s.side), scol = T.scol(s.score);
  return `<svg viewBox="0 0 770 ${H}" style="direction:ltr">${wires}${nodes}
  <circle cx="336" cy="${cy}" r="27" fill="var(--pn2)" stroke="${scol}" stroke-width="2.6" style="filter:drop-shadow(0 0 calc(var(--glow)*8px) ${scol})"/><text x="336" y="${cy - 2}" text-anchor="middle" font-size="19" fill="${scol}" font-weight="800">Σ</text><text x="336" y="${cy + 13}" text-anchor="middle" font-size="11" fill="var(--tx)">${T.dg(sgn(s.score))}</text>
  <path d="M309 ${cy}H196" stroke="${col}" stroke-width="3" class="flow"/><path d="M204 ${cy - 6}L194 ${cy}L204 ${cy + 6}" fill="none" stroke="${col}" stroke-width="2.4"/>
  <g class="${s.side !== 'WAIT' ? 'pulse' : ''}"><rect x="20" y="${cy - 30}" width="170" height="60" rx="14" fill="color-mix(in srgb,${col} 14%,var(--pn2))" stroke="${col}" stroke-width="2.4" style="filter:drop-shadow(0 0 calc(var(--glow)*10px) ${col})"/>
  <text x="105" y="${cy - 4}" text-anchor="middle" font-size="20" font-weight="800" fill="${col}">${T.SIDE_FA[s.side]}</text><text x="105" y="${cy + 16}" text-anchor="middle" font-size="11" fill="var(--mu)">اطمینان ${T.dg(Math.round(s.confidence * 100))}٪ · هم‌سویی ${T.dg(Math.round((s.agree || 0) * 100))}٪</text></g></svg>`;
};

/* ── signature schematic: market circuit board ── */
ch.circuit = function (rows, sel, motion) {
  const Wd = 900, Hd = 560, cx = 450, cy = 280, n = rows.length; if (!n) return '';
  const data = rows.map(r => ({ r, c: T.cons(r) })).sort((a, b) => b.c - a.c);
  const inner = n > 10 ? 8 : Math.ceil(n / 2), pos = [];
  data.forEach((d, i) => {
    const ring = i < inner ? 0 : 1, k = ring ? i - inner : i, m = ring ? n - inner : inner, ang = -90 + 360 * (k + (ring ? .5 : 0)) / m;
    const [x, y] = pol(cx, cy, 1, ang), rx = ring ? 372 : 178, ry = ring ? 226 : 108; pos.push({ d, x: cx + rx * Math.cos(ang * Math.PI / 180), y: cy + ry * Math.sin(ang * Math.PI / 180) });
  });
  const L = pos.filter(p => p.x < cx).sort((a, b) => a.y - b.y), R = pos.filter(p => p.x >= cx).sort((a, b) => a.y - b.y);
  const lane = (arr, p) => { const i = arr.indexOf(p); return arr.length < 2 ? cy : cy - 30 + 60 * i / (arr.length - 1); };
  let tr = '', nodes = '', parts = '', cnt = 0, up = 0, dn = 0, wt = 0;
  pos.forEach(p => {
    const { r, c } = p.d, side = T.consSide(c), col = T.col(side), left = p.x < cx, sx = left ? cx - 66 : cx + 66, sy = lane(left ? L : R, p), tx = left ? p.x + 36 : p.x - 36, ty = p.y;
    const dx = Math.abs(tx - sx), dy = Math.abs(ty - sy), hx = dx > dy ? sx + (left ? -1 : 1) * (dx - dy) : sx;
    const pts = [[sx, sy], [hx, sy], [tx, ty]], act = side !== 'WAIT', rev = side === 'LONG', pp = (rev ? pts.slice().reverse() : pts), d = 'M' + pp.map(q => q[0].toFixed(1) + ' ' + q[1].toFixed(1)).join('L');
    tr += `<path d="${d}" fill="none" stroke="${act ? col : 'var(--ln)'}" stroke-width="${act ? 1.8 : 1.2}" opacity="${act ? .9 : .7}" ${act ? 'class="flow"' : ''}/><circle cx="${sx}" cy="${sy}" r="2.4" fill="${act ? col : 'var(--mu)'}"/>`;
    if (motion && Math.abs(c) >= 45 && cnt < 10) { cnt++; parts += `<circle r="3" fill="${col}" style="filter:drop-shadow(0 0 5px ${col})"><animateMotion dur="${(2.2 + (cnt % 4) * .45).toFixed(1)}s" repeatCount="indefinite" path="${d}"/></circle>`; }
    if (side === 'LONG') up++; else if (side === 'SHORT') dn++; wt += c;
    const isSel = r.symbol === sel, t = r.ticker || {}, tips = Object.entries(r.tfs).map(([tf, v]) => `${tf}: ${T.SIDE_FA[v.side]} ${T.dg(sgn(v.score))}`).join('<br>');
    nodes += `<g class="chip-node ${act ? 'pulse' : ''}" data-sym="${r.symbol}" data-tip="<b>${esc(r.base)}</b> · ${T.fp(t.price)} (${T.fpct(t.change_pct, 1)})<br>اجماع: ${T.dg(sgn(c))} → ${T.SIDE_FA[side]}<br>${tips}">
      <rect x="${p.x - 36}" y="${p.y - 18}" width="72" height="36" rx="8" fill="color-mix(in srgb,${col} ${act ? 14 : 4}%,var(--pn2))" stroke="${isSel ? 'var(--a)' : col}" stroke-width="${isSel ? 2.8 : 1.5}" style="${act || isSel ? `filter:drop-shadow(0 0 calc(var(--glow)*7px) ${isSel ? 'var(--a)' : col})` : ''}"/>
      <path d="M${p.x - 36} ${p.y - 7}h-4M${p.x - 36} ${p.y + 7}h-4M${p.x + 36} ${p.y - 7}h4M${p.x + 36} ${p.y + 7}h4" stroke="${col}" stroke-width="1.4"/>
      <text x="${p.x}" y="${p.y - 2}" text-anchor="middle" font-size="12" font-weight="800" fill="var(--tx)">${esc(r.base)}</text><text x="${p.x}" y="${p.y + 12}" text-anchor="middle" font-size="9.5" fill="${col}">${T.dg(sgn(c))}</text></g>`;
  });
  const avg = wt / n, bc = T.scol(avg);
  const pins = Array.from({ length: 9 }, (_, i) => `<path d="M${cx - 56 + i * 14} 236v-8M${cx - 56 + i * 14} 324v8" stroke="var(--a)" stroke-width="1.6"/>`).join('');
  return `<svg viewBox="0 0 ${Wd} ${Hd}" style="direction:ltr">${tr}${pins}
  <g data-tip="<b>TITAN CORE</b><br>میانگین اجماع بازار: ${T.dg(sgn(avg))}<br>خرید ${T.dg(up)} · فروش ${T.dg(dn)} · انتظار ${T.dg(n - up - dn)}"><rect x="${cx - 66}" y="236" width="132" height="88" rx="14" fill="var(--pn2)" stroke="${bc}" stroke-width="2.6" class="pulse" style="filter:drop-shadow(0 0 calc(var(--glow)*12px) ${bc})"/>
  <rect x="${cx - 54}" y="246" width="108" height="68" rx="9" fill="none" stroke="var(--ln)" stroke-dasharray="3 4"/>
  <text x="${cx}" y="274" text-anchor="middle" font-size="21" font-weight="900" fill="var(--a)" letter-spacing="3">TITAN</text><text x="${cx}" y="293" text-anchor="middle" font-size="11" fill="${bc}">${T.dg(sgn(avg))} · ${T.consSide(avg) === 'WAIT' ? 'خنثی' : T.SIDE_FA[T.consSide(avg)]}</text>
  <text x="${cx}" y="309" text-anchor="middle" font-size="10" fill="var(--mu)">▲${T.dg(up)}  ▼${T.dg(dn)}  ●${T.dg(n - up - dn)}</text></g>${motion ? parts : ''}${nodes}</svg>`;
};

/* ── score × confidence bubble map ── */
ch.scatter = function (rows, sel) {
  const W = 560, H = 300, L = 34, B = 26, X = v => L + (v + 100) / 200 * (W - L - 10), Y = c => 10 + (1 - c) * (H - 10 - B);
  let dots = '';
  rows.forEach(r => {
    const t = r.tfs['1h'] || Object.values(r.tfs)[0]; if (!t) return; const c = T.cons(r), side = T.consSide(c), col = T.col(side), rad = 6 + Math.min(9, Math.abs((r.ticker || {}).change_pct || 0) * 1.2);
    const lab = (r.base || '').slice(0, 4);
    dots += `<g class="chip-node" data-sym="${r.symbol}" data-tip="<b>${esc(r.base)}</b><br>اجماع ${T.dg(sgn(c))} · اطمینان ${T.dg(Math.round(t.confidence * 100))}٪<br>تغییر ۲۴س ${T.fpct((r.ticker || {}).change_pct, 1)}"><circle cx="${X(c).toFixed(1)}" cy="${Y(t.confidence).toFixed(1)}" r="${Math.max(rad, 11).toFixed(1)}" fill="${col}" fill-opacity=".28" stroke="${r.symbol === sel ? 'var(--a)' : col}" stroke-width="${r.symbol === sel ? 2.8 : 1.6}"/><text x="${X(c).toFixed(1)}" y="${(Y(t.confidence) + 3.2).toFixed(1)}" text-anchor="middle" font-size="7.5" fill="var(--tx)" font-weight="700">${esc(lab)}</text></g>`;
  });
  return `<svg viewBox="0 0 ${W} ${H}" style="direction:ltr"><rect x="${X(30)}" y="10" width="${X(100) - X(30)}" height="${H - 10 - B}" fill="var(--up)" opacity=".07"/><rect x="${X(-100)}" y="10" width="${X(-30) - X(-100)}" height="${H - 10 - B}" fill="var(--dn)" opacity=".07"/>
  ${[0, .25, .5, .75, 1].map(c => `<path d="M${L} ${Y(c)}H${W - 10}" stroke="var(--ln)" stroke-dasharray="2 4"/><text x="${L - 5}" y="${Y(c) + 3}" text-anchor="end" font-size="9" fill="var(--mu)">${T.dg(Math.round(c * 100))}</text>`).join('')}
  <path d="M${X(0)} 10V${H - B}" stroke="var(--ln)"/>${[-100, -50, 0, 50, 100].map(v => `<text x="${X(v)}" y="${H - 9}" text-anchor="middle" font-size="9" fill="var(--mu)">${T.dg(v)}</text>`).join('')}
  <text x="${W - 12}" y="22" text-anchor="end" font-size="10" fill="var(--up)">ناحیه خرید</text><text x="${L + 6}" y="22" font-size="10" fill="var(--dn)">ناحیه فروش</text>${dots}</svg>`;
};

/* ── system pipeline schematic ── */
ch.pipeline = function (nodes, edges, sel, motion) {
  const byId = Object.fromEntries(nodes.map(n => [n.id, n])); let es = '', ps = '', ns = '', k = 0;
  edges.forEach(([a, b]) => {
    const A = byId[a], B = byId[b], x0 = A.x + A.w, y0 = A.y + A.h / 2, x1 = B.x, y1 = B.y + B.h / 2, mx = (x0 + x1) / 2, d = `M${x0} ${y0}C${mx} ${y0},${mx} ${y1},${x1} ${y1}`, col = A.bad ? 'var(--dn)' : 'var(--a)';
    es += `<path d="${d}" fill="none" stroke="var(--ln)" stroke-width="2.4"/><path d="${d}" class="flow" fill="none" stroke="${col}" stroke-width="2" opacity="${A.bad ? .35 : .95}"/>`;
    if (motion && !A.bad && k++ % 2 === 0) ps += `<circle r="3.4" fill="var(--c)" style="filter:drop-shadow(0 0 5px var(--c))"><animateMotion dur="${(2.4 + k % 3 * .5).toFixed(1)}s" repeatCount="indefinite" path="${d}"/></circle>`;
  });
  nodes.forEach(n => {
    const col = n.bad ? 'var(--dn)' : n.col || 'var(--a)', s = n.id === sel;
    ns += `<g class="node ${s ? 'sel' : ''}" data-act="fnode" data-k="${n.id}" data-tip="${esc(n.tip || n.t)}"><rect x="${n.x}" y="${n.y}" width="${n.w}" height="${n.h}" rx="12" fill="color-mix(in srgb,${col} ${s ? 20 : 9}%,var(--pn2))" stroke="${col}" stroke-width="${s ? 2.6 : 1.5}"/>
    <circle cx="${n.x + 14}" cy="${n.y + 14}" r="4.5" fill="${n.bad ? 'var(--dn)' : n.busy ? 'var(--go)' : 'var(--up)'}" style="filter:drop-shadow(0 0 4px ${n.bad ? 'var(--dn)' : 'var(--up)'})"/>
    <text x="${n.x + n.w / 2}" y="${n.y + n.h / 2 + 1}" text-anchor="middle" font-size="12.5" font-weight="700" fill="var(--tx)">${esc(n.t)}</text><text x="${n.x + n.w / 2}" y="${n.y + n.h / 2 + 16}" text-anchor="middle" font-size="9.5" fill="var(--mu)">${esc(n.s || '')}</text></g>`;
  });
  return `<svg viewBox="0 0 940 360" style="direction:ltr">${es}${motion ? ps : ''}${ns}</svg>`;
};

/* ══════════ extra graphics (v2.1) ══════════ */
const num = (v, d = 2) => { v = Number(v); return isFinite(v) ? v.toFixed(d) : '—'; };

/* terminal-distribution histogram (% move after N candles) + level markers */
ch.hist = function (h, marks) {
  if (!h || !h.counts || !h.counts.length) return '';
  const W = 340, H = 150, L = 6, B = 22, n = h.counts.length, mx = Math.max(...h.counts) || 1, e = h.edges, lo = e[0], hi = e[e.length - 1];
  const X = v => L + (v - lo) / (hi - lo) * (W - 2 * L), bw = (W - 2 * L) / n;
  const bars = h.counts.map((c, i) => { const mid = (e[i] + e[i + 1]) / 2, hh = c / mx * (H - B - 14), col = mid >= 0 ? 'var(--up)' : 'var(--dn)';
    return `<rect x="${(L + i * bw + 1).toFixed(1)}" y="${(H - B - hh).toFixed(1)}" width="${(bw - 2).toFixed(1)}" height="${hh.toFixed(1)}" rx="2" fill="${col}" fill-opacity=".55" data-tip="${T.fpct(mid, 1)}: ${T.dg(Math.round(c / (h.counts.reduce((a, b) => a + b, 0)) * 100))}٪"/>`; }).join('');
  const mk = (marks || []).filter(m => m.v > lo && m.v < hi).map((m, i) => `<path d="M${X(m.v).toFixed(1)} 6V${H - B}" stroke="${m.c}" stroke-dasharray="3 3" stroke-width="1.6"/><text x="${X(m.v).toFixed(1)}" y="${i % 2 ? 16 : 9}" text-anchor="middle" font-size="9.5" fill="${m.c}">${esc(m.l)}</text>`).join('');
  return `<svg viewBox="0 0 ${W} ${H}" style="direction:ltr"><path d="M${X(0)} 4V${H - B}" stroke="var(--mu)" stroke-width="1.4"/>${bars}${mk}
  <text x="${L}" y="${H - 6}" font-size="10" fill="var(--mu)">${T.fpct(lo, 1)}</text><text x="${X(0)}" y="${H - 6}" text-anchor="middle" font-size="10" fill="var(--tx)">۰</text><text x="${W - L}" y="${H - 6}" text-anchor="end" font-size="10" fill="var(--mu)">${T.fpct(hi, 1)}</text></svg>`;
};

/* probability-of-being-above-now per future candle */
ch.stepProb = function (arr) {
  if (!arr || arr.length < 3) return '';
  const W = 340, H = 120, L = 28, R = 8, T0 = 8, B = 20, n = arr.length, X = i => L + i / (n - 1) * (W - L - R), Y = p => T0 + (1 - p) * (H - T0 - B);
  const d = arr.map((p, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)} ${Y(p).toFixed(1)}`).join(''), end = arr[n - 1], col = end >= .5 ? 'var(--up)' : 'var(--dn)', id = uid();
  return `<svg viewBox="0 0 ${W} ${H}" style="direction:ltr"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".35"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs>
  ${[0, .25, .5, .75, 1].map(p => `<path d="M${L} ${Y(p)}H${W - R}" stroke="var(--ln)" stroke-dasharray="${p === .5 ? '0' : '2 4'}"/><text x="${L - 4}" y="${Y(p) + 3}" text-anchor="end" font-size="9" fill="var(--mu)">${T.dg(Math.round(p * 100))}</text>`).join('')}
  <path d="${d}L${X(n - 1)} ${Y(.5)}L${X(0)} ${Y(.5)}Z" fill="url(#${id})"/><path d="${d}" fill="none" stroke="${col}" stroke-width="2.2" style="filter:drop-shadow(0 0 calc(var(--glow)*5px) ${col})"/>
  ${[0, 7, 15, 23, n - 1].filter((v, i, a) => a.indexOf(v) === i && v < n).map(i => `<text x="${X(i)}" y="${H - 6}" text-anchor="middle" font-size="9.5" fill="var(--mu)">+${T.dg(i + 1)}</text>`).join('')}</svg>`;
};

/* order-book cumulative depth */
ch.depth = function (d) {
  if (!d || !d.ok || !d.bid_curve || !d.ask_curve) return '';
  const W = 340, H = 150, B = 20, bc = d.bid_curve, ac = d.ask_curve, mx = Math.max(bc[bc.length - 1][1], ac[ac.length - 1][1]) || 1;
  const lo = bc[bc.length - 1][0], hi = ac[ac.length - 1][0], X = p => 4 + (p - lo) / (hi - lo) * (W - 8), Y = v => 6 + (1 - v / mx) * (H - B - 6);
  const area = (c, col) => { const pts = c.map(q => `${X(q[0]).toFixed(1)} ${Y(q[1]).toFixed(1)}`); return `<path d="M${pts.join('L')}L${X(c[c.length - 1][0]).toFixed(1)} ${H - B}L${X(c[0][0]).toFixed(1)} ${H - B}Z" fill="${col}" fill-opacity=".25"/><path d="M${pts.join('L')}" fill="none" stroke="${col}" stroke-width="2" style="filter:drop-shadow(0 0 calc(var(--glow)*4px) ${col})"/>`; };
  return `<svg viewBox="0 0 ${W} ${H}" style="direction:ltr">${area(bc.slice().reverse(), 'var(--up)')}${area(ac, 'var(--dn)')}<path d="M${X(d.mid)} 4V${H - B}" stroke="var(--go)" stroke-dasharray="3 3"/>
  <text x="4" y="${H - 6}" font-size="9.5" fill="var(--mu)">${T.fp(lo)}</text><text x="${X(d.mid)}" y="${H - 6}" text-anchor="middle" font-size="9.5" fill="var(--go)">${T.fp(d.mid)}</text><text x="${W - 4}" y="${H - 6}" text-anchor="end" font-size="9.5" fill="var(--mu)">${T.fp(hi)}</text></svg>`;
};

/* cumulative-R equity curve (back-test) */
ch.equityR = function (arr) {
  if (!arr || arr.length < 2) return '<div class="empty">معامله کافی برای رسم منحنی نیست.</div>';
  const W = 340, H = 140, L = 30, R = 6, v = [0].concat(arr), lo = Math.min(...v), hi = Math.max(...v), X = i => L + i / (v.length - 1) * (W - L - R), Y = e => 8 + (1 - (e - lo) / ((hi - lo) || 1)) * (H - 24), end = v[v.length - 1], col = end >= 0 ? 'var(--up)' : 'var(--dn)', id = uid();
  const d = v.map((e, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)} ${Y(e).toFixed(1)}`).join('');
  return `<svg viewBox="0 0 ${W} ${H}" style="direction:ltr"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".4"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs>
  <path d="M${L} ${Y(0)}H${W - R}" stroke="var(--mu)" stroke-dasharray="4 4"/><text x="${L - 4}" y="${Y(0) + 3}" text-anchor="end" font-size="9" fill="var(--mu)">0R</text><text x="${L - 4}" y="${Y(hi) + 3}" text-anchor="end" font-size="9" fill="${col}">${T.dg(num(hi, 1))}</text><text x="${L - 4}" y="${Y(lo) + 3}" text-anchor="end" font-size="9" fill="var(--mu)">${T.dg(num(lo, 1))}</text>
  <path d="${d}L${X(v.length - 1)} ${H - 16}L${L} ${H - 16}Z" fill="url(#${id})"/><path d="${d}" fill="none" stroke="${col}" stroke-width="2.2" style="filter:drop-shadow(0 0 calc(var(--glow)*5px) ${col})"/></svg>`;
};

/* volume profile (horizontal bars) with POC / value area */
ch.vprofile = function (vp, price) {
  if (!vp || !vp.bins) return '';
  const W = 340, rh = 7, bins = vp.bins.slice().reverse(), H = bins.length * rh + 6, lo = vp.bins[0].p, hi = vp.bins[vp.bins.length - 1].p;
  const rows = bins.map((b, i) => { const inVA = b.p >= vp.val && b.p <= vp.vah, poc = Math.abs(b.p - vp.poc) < 1e-12 * vp.poc + 1e-18 || b.p === vp.poc;
    return `<rect x="70" y="${3 + i * rh}" width="${Math.max(1, b.v * 250).toFixed(1)}" height="${rh - 1.5}" rx="2" fill="${poc ? 'var(--go)' : inVA ? 'var(--a)' : 'var(--mu)'}" fill-opacity="${poc ? .9 : inVA ? .5 : .28}" data-tip="${T.fp(b.p)}"/>${i % 6 === 0 ? `<text x="64" y="${3 + i * rh + 6}" text-anchor="end" font-size="9" fill="var(--mu)">${T.fp(b.p)}</text>` : ''}`; }).join('');
  const py = price && price >= lo && price <= hi ? 3 + (1 - (price - lo) / (hi - lo)) * (bins.length - 1) * rh + rh / 2 : null;
  return `<svg viewBox="0 0 ${W} ${H}" style="direction:ltr">${rows}${py != null ? `<path d="M68 ${py.toFixed(1)}H${W - 4}" stroke="var(--tx)" stroke-dasharray="3 3"/><text x="${W - 4}" y="${(py - 3).toFixed(1)}" text-anchor="end" font-size="9.5" fill="var(--tx)">اکنون</text>` : ''}</svg>`;
};

/* component list (HTML, phone friendly) grouped by family */
ch.compList = function (comps, selK) {
  const G = { trend: 'روند', momentum: 'مومنتوم', revert: 'بازگشت', volume: 'حجم و پول', structure: 'ساختار', pattern: 'الگو' };
  return Object.keys(G).map(g => { const cs = (comps || []).filter(c => c.g === g); if (!cs.length) return '';
    const tot = cs.reduce((a, c) => a + c.s * c.w, 0) / (cs.reduce((a, c) => a + c.w, 0) || 1);
    return `<div class="cg"><div class="row sb" style="margin:8px 0 2px"><b style="color:var(--a)">${G[g]}</b><span style="color:${T.scol(tot * 100)};font-size:.85em">${T.dg(sgn(tot * 100))}</span></div>${cs.map(c => { const a = Math.abs(c.s), col = c.s > .05 ? 'var(--up)' : c.s < -.05 ? 'var(--dn)' : 'var(--mu)';
      return `<div class="cmp ${c.k === selK ? 'sel' : ''}" data-act="dt" data-k="${c.k}"><span class="cn">${esc(c.n)}</span><span class="cb"><i style="${c.s >= 0 ? 'left' : 'right'}:50%;width:${(a * 50).toFixed(0)}%;background:${col}"></i><u></u></span><span class="cv" style="color:${col}">${T.dg(sgn(c.s * 100))}</span><span class="ct">${esc(c.t)}</span></div>`; }).join('')}</div>`; }).join('');
};

/* component x timeframe heat grid */
ch.heatgrid = function (allTf, tfs) {
  const keys = []; tfs.forEach(tf => ((allTf[tf] || {}).components || []).forEach(c => { if (!keys.find(k => k.k === c.k)) keys.push({ k: c.k, n: c.n }); }));
  const cell = (tf, k) => { const c = ((allTf[tf] || {}).components || []).find(x => x.k === k); if (!c) return '<td class="mu">·</td>'; const col = c.s >= 0 ? 'var(--up)' : 'var(--dn)', a = Math.round(Math.abs(c.s) * 62);
    return `<td style="background:color-mix(in srgb,${col} ${a}%,transparent)" data-tip="${esc(c.n)} ${tf}: ${esc(c.t)}">${T.dg(sgn(c.s * 100))}</td>`; };
  return `<div class="tw"><table class="hg"><thead><tr><th>مولفه</th>${tfs.map(t => `<th>${t}</th>`).join('')}</tr></thead><tbody>${keys.map(k => `<tr><td>${esc(k.n)}</td>${tfs.map(t => cell(t, k.k)).join('')}</tr>`).join('')}</tbody></table></div>`;
};

/* correlation heat-map */
ch.corrmap = function (names, m) {
  if (!names || !names.length) return '<div class="empty">داده همبستگی هنوز آماده نیست.</div>';
  return `<div class="tw"><table class="hg"><thead><tr><th></th>${names.map(n => `<th>${esc(n)}</th>`).join('')}</tr></thead><tbody>${m.map((row, i) => `<tr><td><b>${esc(names[i])}</b></td>${row.map((v, j) => { const col = v >= 0 ? 'var(--a)' : 'var(--c)'; return `<td style="background:color-mix(in srgb,${col} ${Math.round(Math.abs(v) * (i === j ? 20 : 70))}%,transparent)">${T.dg(num(v, 2).replace('0.', '.').replace('-.', '-.'))}</td>`; }).join('')}</tr>`).join('')}</tbody></table></div>`;
};

/* phone-friendly "market board": tiles instead of the wide circuit schematic */
ch.board = function (rows, sel) {
  const data = rows.map(r => ({ r, c: T.cons(r) })).sort((a, b) => Math.abs(b.c) - Math.abs(a.c));
  return `<div class="board">${data.map(({ r, c }) => { const sd = T.consSide(c), col = T.col(sd), t = r.ticker || {}, nm = (r.base || r.symbol || '').replace('USDT', '');
    return `<div class="tile ${r.symbol === sel ? 'sel' : ''}" data-sym="${r.symbol}" style="--tc:${col}" title="${esc(nm)}"><div class="row sb" style="gap:6px;flex-wrap:nowrap;align-items:center"><b dir="ltr">${esc(nm.slice(0, 8))}</b>${r.grade && r.grade !== '—' ? `<span class="gr g${r.grade}">${r.grade}</span>` : ''}</div>
    <div class="ltr tp">${T.fp(t.price)}</div><div class="row sb" style="gap:6px;flex-wrap:nowrap;align-items:center"><span class="${(t.change_pct || 0) >= 0 ? 'up' : 'dn'}" style="font-size:.78em;white-space:nowrap">${T.fpct(t.change_pct, 1)}</span><span style="color:${col};font-weight:800;font-size:.85em;white-space:nowrap">${T.dg(sgn(c))}</span></div></div>`; }).join('')}</div>`;
};

/* ══════════ canvas candle chart v2.1 ══════════ */
const IVMS = { '15m': 900e3, '1h': 3600e3, '4h': 14400e3, '1d': 86400e3 };
const emaA = (a, n) => { const k = 2 / (n + 1), o = []; let e = a[0]; for (let i = 0; i < a.length; i++) { e = i ? a[i] * k + e * (1 - k) : a[0]; o.push(e); } return o; };
const smaA = (a, n) => a.map((_, i) => { if (i < n - 1) return null; let m = 0; for (let j = i - n + 1; j <= i; j++) m += a[j]; return m / n; });
const bbands = (a, n = 20) => a.map((_, i) => { if (i < n - 1) return null; let m = 0; for (let j = i - n + 1; j <= i; j++) m += a[j]; m /= n; let v = 0; for (let j = i - n + 1; j <= i; j++) v += (a[j] - m) ** 2; const sd = Math.sqrt(v / n); return [m - 2 * sd, m, m + 2 * sd]; });
const rsiA = (c, n = 14) => { const o = new Array(c.length).fill(null); let ag = 0, al = 0; for (let i = 1; i < c.length; i++) { const d = c[i] - c[i - 1], g = Math.max(d, 0), l = Math.max(-d, 0); if (i <= n) { ag += g / n; al += l / n; if (i === n) o[i] = 100 - 100 / (1 + ag / (al || 1e-12)); } else { ag = (ag * (n - 1) + g) / n; al = (al * (n - 1) + l) / n; o[i] = 100 - 100 / (1 + ag / (al || 1e-12)); } } return o; };
const macdA = c => { const f = emaA(c, 12), s = emaA(c, 26), l = c.map((_, i) => f[i] - s[i]), g = emaA(l, 9); return { l, g, h: l.map((v, i) => v - g[i]) }; };
function stochRsi(r) { const k = r.map((_, i) => { if (i < 28 || r[i] == null) return null; const w = r.slice(i - 13, i + 1).filter(x => x != null); if (w.length < 14) return null; const lo = Math.min(...w), hi = Math.max(...w); return (r[i] - lo) / ((hi - lo) || 1) * 100; }); const ks = smaA(k.map(v => v == null ? 50 : v), 3).map((v, i) => k[i] == null ? null : v); const ds = smaA(ks.map(v => v == null ? 50 : v), 3).map((v, i) => ks[i] == null ? null : v); return { k: ks, d: ds }; }
function supertrend(k, n = 10, m = 3) { const N = k.length, tr = k.map((x, i) => i ? Math.max(x.h - x.l, Math.abs(x.h - k[i - 1].c), Math.abs(x.l - k[i - 1].c)) : x.h - x.l), atr = emaA(tr, n * 2 - 1); const out = new Array(N).fill(null), dir = new Array(N).fill(1); let fu = 0, fl = 0;
  for (let i = 0; i < N; i++) { const hl = (k[i].h + k[i].l) / 2, ub = hl + m * atr[i], lb = hl - m * atr[i]; if (i === 0) { fu = ub; fl = lb; continue; } fu = (ub < fu || k[i - 1].c > fu) ? ub : fu; fl = (lb > fl || k[i - 1].c < fl) ? lb : fl; dir[i] = dir[i - 1]; if (dir[i - 1] === 1 && k[i].c < fl) dir[i] = -1; else if (dir[i - 1] === -1 && k[i].c > fu) dir[i] = 1; out[i] = i > n ? (dir[i] === 1 ? fl : fu) : null; } return { v: out, d: dir }; }
function ichimoku(k) { const N = k.length, hh = (i, n) => { let m = -1e99; for (let j = Math.max(0, i - n + 1); j <= i; j++) m = Math.max(m, k[j].h); return m; }, ll = (i, n) => { let m = 1e99; for (let j = Math.max(0, i - n + 1); j <= i; j++) m = Math.min(m, k[j].l); return m; };
  const t = [], kj = [], a = [], b = []; for (let i = 0; i < N; i++) { const ok9 = i >= 8, ok26 = i >= 25, ok52 = i >= 51; t.push(ok9 ? (hh(i, 9) + ll(i, 9)) / 2 : null); kj.push(ok26 ? (hh(i, 26) + ll(i, 26)) / 2 : null); a.push(ok26 ? (t[i] + kj[i]) / 2 : null); b.push(ok52 ? (hh(i, 52) + ll(i, 52)) / 2 : null); } return { t, kj, a, b }; }
function vwapA(k, n = 48) { return k.map((_, i) => { if (i < n - 1) return null; let pv = 0, v = 0; for (let j = i - n + 1; j <= i; j++) { pv += (k[j].h + k[j].l + k[j].c) / 3 * k[j].v; v += k[j].v; } return v ? pv / v : null; }); }

function haSeries(k) { const o = []; let po = null, pc = null; k.forEach(x => { const c = (x.o + x.h + x.l + x.c) / 4, op = po == null ? (x.o + x.c) / 2 : (po + pc) / 2; o.push({ t: x.t, v: x.v, o: op, c, h: Math.max(x.h, op, c), l: Math.min(x.l, op, c) }); po = op; pc = c; }); return o; }
class CandleChart {
  constructor(host, opt = {}) {
    this.host = host; this.opt = opt; this.mini = !!opt.mini; this.cv = document.createElement('canvas'); this.cv.className = 'cv'; host.appendChild(this.cv); this.x = this.cv.getContext('2d');
    this.k = []; this.ov = {}; this.view = { n: 0, off: 0 }; this.cross = null; this.ptrs = new Map(); this.pinch = null; this.drag = null; this.raf = 0;
    this.ro = new ResizeObserver(() => this.resize()); this.ro.observe(host);
    const c = this.cv, rel = e => { const r = c.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; };
    if (this.mini) { c.style.touchAction = 'auto'; c.addEventListener('click', () => opt.onTap && opt.onTap()); return; }
    c.style.touchAction = 'pan-y';
    c.addEventListener('pointerdown', e => { c.setPointerCapture(e.pointerId); this.ptrs.set(e.pointerId, rel(e)); this.moved = false;
      if (this.ptrs.size === 1) this.drag = { x: e.clientX, off: this.view.off, t: Date.now(), tap: rel(e) };
      if (this.ptrs.size === 2) { const [a, b] = [...this.ptrs.values()]; this.pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), n: this.view.n }; this.drag = null; } });
    c.addEventListener('pointermove', e => {
      if (this.ptrs.has(e.pointerId)) this.ptrs.set(e.pointerId, rel(e));
      if (this.pinch && this.ptrs.size >= 2) { const [a, b] = [...this.ptrs.values()], d = Math.hypot(a.x - b.x, a.y - b.y); this.setN(this.pinch.n * this.pinch.d / Math.max(20, d)); this.moved = true; this.cross = null; this.sched(); return; }
      if (this.drag && e.buttons !== 0 || (this.drag && e.pointerType === 'touch')) { const dx = e.clientX - this.drag.x; if (Math.abs(dx) > 5) { this.moved = true; this.cross = null; this.view.off = Math.max(0, Math.min(this.k.length - 20, this.drag.off + Math.round(dx / (this.cw || 8)))); this.sched(); return; } }
      if (e.pointerType === 'mouse') { this.cross = rel(e); this.sched(); } });
    const up = e => { if (this.drag && !this.moved && Date.now() - this.drag.t < 450 && e.type === 'pointerup') { const p = this.drag.tap, now = Date.now();
        if (this.lastTap && now - this.lastTap < 320) { this.view.n = this.defN(); this.view.off = 0; this.cross = null; this.lastTap = 0; } else { this.lastTap = now; this.cross = (this.cross && Math.abs(this.cross.x - p.x) < 6) ? null : p; } this.sched(); }
      this.ptrs.delete(e.pointerId); if (this.ptrs.size < 2) this.pinch = null; if (!this.ptrs.size) this.drag = null; };
    c.addEventListener('pointerup', up); c.addEventListener('pointercancel', up);
    c.addEventListener('pointerleave', e => { if (e.pointerType === 'mouse') { this.cross = null; this.sched(); } });
    c.addEventListener('wheel', e => { e.preventDefault(); this.setN(this.view.n * (e.deltaY > 0 ? 1.12 : .89)); this.sched(); }, { passive: false });
  }
  defN() { const u = (T.UI && T.UI.chartN) || 0; return this.mini ? 40 : u ? u : (this.W || 400) < 520 ? 34 : 80; }
  setN(n) { this.view.n = Math.max(18, Math.min(this.k.length || 200, Math.round(n))); }
  zoom(f) { this.setN(this.view.n * f); this.sched(); }
  reset() { this.view = { n: this.defN(), off: 0 }; this.cross = null; this.sched(); }
  png() { return new Promise(r => this.cv.toBlob(r, 'image/png')); }
  destroy() { cancelAnimationFrame(this.raf); this.ro.disconnect(); this.cv.remove(); }
  sched() { if (this.raf) return; this.raf = requestAnimationFrame(() => { this.raf = 0; this.draw(); }); }
  panes() { const p = (this.ov.panes) || {}; return this.mini ? [] : ['rsi', 'macd', 'srsi'].filter(k => p[k]); }
  resize() {
    const w = this.host.clientWidth || 320, np = this.panes().length, full = this.host.dataset.full === '1';
    const mainH = this.mini ? Math.max(170, Math.min(230, Math.round(w * .6))) : full ? Math.max(260, (this.host.clientHeight || 500) - np * 74 - 26) : Math.round(Math.max(300, Math.min(520, Math.round(w * (w < 600 ? .98 : .5)))) * (T.UI.chartH || 1));
    const h = mainH + np * 74 + 26, d = Math.min(3, devicePixelRatio || 1);
    this.W = w; this.H = h; this.mainH = mainH; this.cv.width = Math.round(w * d); this.cv.height = Math.round(h * d); this.cv.style.height = h + 'px'; this.x.setTransform(d, 0, 0, d, 0, 0);
    if (!this.view.n) this.view.n = this.defN(); this.draw();
  }
  set(klines, ov) {
    this.k = klines || []; this.ov = ov || {}; this.hk = haSeries(this.k); const k = this.k, c = k.map(x => x.c);
    this.e = { 9: emaA(c, 9), 21: emaA(c, 21), 50: emaA(c, 50), 200: emaA(c, 200) }; this.bb = bbands(c); this.rsi = rsiA(c); this.macd = macdA(c); this.srsi = stochRsi(this.rsi);
    this.st = supertrend(k); this.ich = ichimoku(k); this.vw = vwapA(k);
    if (!this.view.n) this.view.n = this.defN(); this.view.n = Math.min(this.view.n, Math.max(18, k.length)); this.resize();
  }
  draw() {
    const x = this.x, W = this.W, H = this.H, C = Object.assign({}, T.C || {}, T.UI.candleUp ? { up: T.UI.candleUp } : {}, T.UI.candleDn ? { dn: T.UI.candleDn } : {}), ly = this.ov.layers || {}, k = this.k, mini = this.mini; if (!W) return;
    x.clearRect(0, 0, W, H);
    if (!mini && T.UI.chartBg !== 'none') { x.fillStyle = T.UI.chartBg === 'solid' ? 'rgba(4,8,18,.92)' : 'rgba(0,0,0,.28)'; x.fillRect(0, 0, W, H); }
    if (!k.length) { x.fillStyle = C.mu; x.font = '14px sans-serif'; x.textAlign = 'center'; x.fillText('داده‌ای برای نمایش نیست', W / 2, H / 2); return; }
    const fu = C.fu || C.a, fd = C.fd || C.c, ivms = IVMS[this.ov.tf] || 3600e3, fc = this.ov.forecast, sig = this.ov.signal, ex = (sig && sig.extras) || {}, lvs = (sig && sig.levels) || {};
    const padR = mini ? 50 : W < 480 ? 58 : 72, padT = 8, axisH = 22, pk = this.panes(), paneH = 74, mainH = this.mainH, plotW = W - padR - 4;
    const end = k.length - this.view.off, start = Math.max(0, end - this.view.n), real = k.slice(start, end), data = ((T.UI.candle === 'ha' && !mini) ? this.hk : k).slice(start, end), nF = (ly.fc && this.view.off === 0 && fc && fc.candles && fc.candles.length) ? fc.candles.length : 0;
    const slots = data.length + nF + (nF ? 1 : 0), cw = plotW / slots; this.cw = cw; this.slots = slots;
    const X = i => 4 + (i + .5) * cw, i0 = data.length - 1, volH = ly.vol && !mini ? mainH * .13 : 0, chH = mainH - padT - volH - 4;
    let lo = Math.min(...data.map(d => d.l)), hi = Math.max(...data.map(d => d.h));
    if (nF && fc.bands) { lo = Math.min(lo, ...fc.bands.p10); hi = Math.max(hi, ...fc.bands.p90); }
    if (ly.lv && sig && sig.side !== 'WAIT' && !mini) [sig.entry, sig.stop, sig.tp1, sig.tp2].forEach(v => { if (v > 0) { lo = Math.min(lo, v); hi = Math.max(hi, v); } });
    const mg = (hi - lo) * .07 || hi * .01; lo -= mg; hi += mg; const Y = p => padT + (1 - (p - lo) / (hi - lo)) * chH, yOK = p => { const y = Y(p); return y > padT - 2 && y < padT + chH + 2; };
    x.font = `${mini ? 9.5 : 10.5}px "Segoe UI",Tahoma,sans-serif`; x.textBaseline = 'middle';
    const hline = (p, col, w, dash, a = 1, x0 = 0, x1 = W - padR) => { if (!yOK(p)) return; x.save(); x.globalAlpha = a; x.strokeStyle = col; x.lineWidth = w; x.setLineDash(dash || []); x.beginPath(); x.moveTo(x0, Y(p)); x.lineTo(x1, Y(p)); x.stroke(); x.restore(); };
    const tag = (p, col, txt, fg = '#000') => { if (!yOK(p)) return; const y = Y(p); x.fillStyle = col; x.fillRect(W - padR + 1, y - 8, padR - 2, 16); x.fillStyle = fg; x.textAlign = 'left'; x.fillText(txt, W - padR + 4, y); };
    const poly = (arr, col, w, dash) => { x.beginPath(); let f = true; data.forEach((d, i) => { const v = arr[start + i]; if (v != null) { x[f ? 'moveTo' : 'lineTo'](X(i), Y(v)); f = false; } }); x.strokeStyle = col; x.lineWidth = w; x.setLineDash(dash || []); x.stroke(); x.setLineDash([]); };
    // future zone backdrop
    if (nF) { const fx = X(i0) + cw / 2; const g = x.createLinearGradient(0, 0, 0, mainH + pk.length * paneH); g.addColorStop(0, fu); g.addColorStop(1, fd); x.save(); x.globalAlpha = .07; x.fillStyle = g; x.fillRect(fx, 0, W - padR - fx, mainH + pk.length * paneH); x.restore();
      x.save(); x.strokeStyle = C.go; x.globalAlpha = .75; x.setLineDash([4, 4]); x.beginPath(); x.moveTo(fx, 0); x.lineTo(fx, mainH + pk.length * paneH); x.stroke(); x.restore(); }
    // grid + labels
    const gl = mini ? 3 : 5; for (let i = 0; i <= gl; i++) { const p = lo + (hi - lo) * i / gl; if (T.UI.grid !== 0) hline(p, C.ln, 1, [2, 4], .55); x.fillStyle = C.mu; x.textAlign = 'left'; x.fillText(T.fp(p), W - padR + 5, Y(p)); }
    const tbase = data[data.length - 1].t, every = Math.max(1, Math.round(slots / (mini ? 4 : W < 480 ? 5 : 8))), lblY = mainH + pk.length * paneH + 12; x.fillStyle = C.mu; x.textAlign = 'center';
    for (let i = 0; i < slots; i += every) { const t = i < data.length ? data[i].t : tbase + (i - i0) * ivms, d = new Date(t); x.fillStyle = i < data.length ? C.mu : fu; x.fillText(this.ov.tf === '1d' ? `${d.getMonth() + 1}/${d.getDate()}` : `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`, X(i), lblY); }
    // volume bars (outside the clipped price area)
    if (volH) { const mv = Math.max(...data.map(d => d.v)) || 1; data.forEach((d, i) => { const bw = Math.max(1.4, cw * .68), vh = d.v / mv * volH; x.globalAlpha = .3; x.fillStyle = d.c >= d.o ? C.up : C.dn; x.fillRect(X(i) - bw / 2, padT + chH + volH + 2 - vh, bw, vh); x.globalAlpha = 1; }); }
    let clipped = true; const unclip = () => { if (clipped) { x.restore(); clipped = false; } }; x.save(); x.beginPath(); x.rect(0, 0, W - padR, padT + chH + 1); x.clip();
    // ichimoku cloud (+26 projected into the future zone)
    if (ly.ich && !mini) { const A = this.ich.a, B = this.ich.b; for (let i = 0; i < slots - 1; i++) { const gi = start + i - 26, gj = gi + 1; if (gi < 0 || gj >= k.length || A[gi] == null || B[gi] == null || A[gj] == null || B[gj] == null || i > data.length - 1 + Math.min(nF, 26)) continue;
        x.beginPath(); x.moveTo(X(i), Y(A[gi])); x.lineTo(X(i + 1), Y(A[gj])); x.lineTo(X(i + 1), Y(B[gj])); x.lineTo(X(i), Y(B[gi])); x.closePath(); x.fillStyle = A[gi] >= B[gi] ? C.up : C.dn; x.globalAlpha = .12; x.fill(); x.globalAlpha = 1; }
      const T0 = this.ich.t, K0 = this.ich.kj; poly(T0, C.a, 1, [2, 2]); poly(K0, C.dn, 1, [2, 2]); }
    // bollinger
    if (ly.bb) { x.beginPath(); let f = true; data.forEach((d, i) => { const b = this.bb[start + i]; if (b) { x[f ? 'moveTo' : 'lineTo'](X(i), Y(b[2])); f = false; } }); for (let i = data.length - 1; i >= 0; i--) { const b = this.bb[start + i]; if (b) x.lineTo(X(i), Y(b[0])); } x.closePath(); x.fillStyle = C.b; x.globalAlpha = .1; x.fill(); x.globalAlpha = 1; }
    // volume profile (right side of the plot)
    if (ly.vp && !mini && ex.vp && ex.vp.bins) { const bn = ex.vp.bins, bh = Math.abs(Y(bn[0].p) - Y(bn[1].p)); bn.forEach(b => { if (!yOK(b.p)) return; x.fillStyle = Math.abs(b.p - ex.vp.poc) < 1e-9 * b.p ? C.go : (b.p >= ex.vp.val && b.p <= ex.vp.vah ? C.a : C.mu); x.globalAlpha = .22; x.fillRect(W - padR - b.v * plotW * .22, Y(b.p) - bh / 2, b.v * plotW * .22, bh * .88); }); x.globalAlpha = 1; hline(ex.vp.poc, C.go, 1, [6, 3], .8); }
    // structure lines: zones, pivots, fib
    if (ly.sr && !mini && lvs.zones) lvs.zones.forEach(z => { const col = z.kind === 'R' ? C.dn : C.up; hline(z.p, col, 1 + Math.min(2, z.n * .4), [], .38 + Math.min(.4, z.n * .1)); if (yOK(z.p)) { x.fillStyle = col; x.textAlign = 'left'; x.fillText(`${z.kind}${z.n > 1 ? '×' + z.n : ''}`, 6, Y(z.p) - 7); } });
    if (ly.pv && !mini && ex.pivots) [['p', 'P', C.go], ['r1', 'R1', C.dn], ['r2', 'R2', C.dn], ['s1', 'S1', C.up], ['s2', 'S2', C.up]].forEach(([kk, n, col]) => { const v = ex.pivots[kk]; hline(v, col, 1, [1, 4], .8); if (yOK(v)) { x.fillStyle = col; x.textAlign = 'right'; x.fillText(n, W - padR - 4, Y(v) - 7); } });
    if (ly.fib && !mini && ex.fib && ex.fib.levels) { ex.fib.levels.concat(ex.fib.ext || []).forEach(l => { hline(l.p, C.b, 1, [7, 4], .75); if (yOK(l.p)) { x.fillStyle = C.b; x.textAlign = 'left'; x.fillText(`${l.r}`, 6, Y(l.p) - 7); } }); }
    // volume bars
    const maxV = Math.max(...data.map(d => d.v)) || 1;
    // candles (style: solid · hollow · bars · line · area · ha)
    const stl = mini ? 'solid' : (T.UI.candle || 'solid'), wk = Math.max(1, Math.min(T.UI.wick || 1.4, cw * .3));
    if (stl === 'line' || stl === 'area') {
      x.beginPath(); data.forEach((d, i) => x[i ? 'lineTo' : 'moveTo'](X(i), Y(d.c))); x.strokeStyle = C.a; x.lineWidth = 2; x.shadowColor = C.a; x.shadowBlur = (T.UI.glow || 0) * 5; x.stroke(); x.shadowBlur = 0;
      if (stl === 'area') { x.lineTo(X(data.length - 1), padT + chH); x.lineTo(X(0), padT + chH); x.closePath(); const g = x.createLinearGradient(0, padT, 0, padT + chH); g.addColorStop(0, C.a); g.addColorStop(1, 'transparent'); x.globalAlpha = .28; x.fillStyle = g; x.fill(); x.globalAlpha = 1; }
    } else data.forEach((d, i) => { const up = d.c >= d.o, col = up ? C.up : C.dn, cx = X(i), bw = Math.max(1.4, cw * .68);
      x.strokeStyle = col; x.fillStyle = col; x.lineWidth = wk; x.beginPath(); x.moveTo(cx, Y(d.h)); x.lineTo(cx, Y(d.l)); x.stroke();
      if (stl === 'bars') { x.beginPath(); x.moveTo(cx - bw / 2, Y(d.o)); x.lineTo(cx, Y(d.o)); x.moveTo(cx, Y(d.c)); x.lineTo(cx + bw / 2, Y(d.c)); x.stroke(); return; }
      x.shadowColor = col; x.shadowBlur = mini ? 0 : (T.UI.glow || 0) * 3; const y0 = Y(Math.max(d.o, d.c)), bh = Math.max(1.2, Math.abs(Y(d.o) - Y(d.c)));
      if (stl === 'hollow' && up && bw > 3) { x.lineWidth = 1.2; x.strokeRect(cx - bw / 2 + .6, y0 + .6, bw - 1.2, Math.max(1, bh - 1.2)); } else x.fillRect(cx - bw / 2, y0, bw, bh); x.shadowBlur = 0; });
    // chart patterns: candle markers + structural trend-lines (layer "pat")
    const PT = this.ov.pat; if (ly.pat && !mini && PT && PT.symbol) {
      const tIdx = new Map(real.map((d, i) => [d.t, i])), gl2 = (bias) => bias > 0 ? C.up : bias < 0 ? C.dn : C.go; x.font = '10px "Segoe UI",Tahoma,sans-serif'; x.textAlign = 'center';
      (PT.recent || []).forEach((r, n) => { const i = tIdx.get(r.t); if (i == null) return; const col = gl2(r.bias), cx = X(i), up = r.bias > 0, y = up ? Y(r.lo) + 9 : Y(r.hi) - 9;
        if (!yOK(r.bias > 0 ? r.lo : r.hi)) return; x.fillStyle = col; x.globalAlpha = .45 + .5 * r.strength; x.beginPath();
        if (r.bias > 0) { x.moveTo(cx, y - 4); x.lineTo(cx - 4, y + 3); x.lineTo(cx + 4, y + 3); } else if (r.bias < 0) { x.moveTo(cx, y + 4); x.lineTo(cx - 4, y - 3); x.lineTo(cx + 4, y - 3); } else x.arc(cx, y, 3, 0, 7); x.fill(); x.globalAlpha = 1;
        if (r.ago <= 2 && n < 6) { x.fillStyle = col; x.fillText(r.fa, cx, up ? y + 15 : y - 9); } });
      const off = k.length - PT.n; (PT.structs || []).forEach(st => { const col = gl2(st.bias); x.save(); x.strokeStyle = col; x.lineWidth = 1.6; x.setLineDash([7, 4]); x.globalAlpha = .9;
        st.lines.forEach(([a, p0, b, p1]) => { const s0 = a + off - start, s1 = b + off - start; x.beginPath(); x.moveTo(X(Math.max(-1, s0)), Y(p0 + (s0 < -1 ? (p1 - p0) * (-1 - s0) / (s1 - s0) : 0))); x.lineTo(X(s1), Y(p1)); x.stroke(); });
        x.restore(); const l = st.lines[0]; if (l) { const sx = Math.min(slots - 1, Math.max(0, l[2] + off - start)); x.fillStyle = col; x.textAlign = 'right'; x.fillText(`${st.fa} ${Math.round(st.conf * 100)}٪`, Math.min(W - padR - 4, X(sx) - 4), Math.max(padT + 10, Math.min(padT + chH - 4, Y(l[3]) - 8))); }
        [[st.break_up, C.up], [st.break_dn, C.dn], [st.target, C.go]].forEach(([v, c2], q) => { if (v) hline(v, c2, 1, q === 2 ? [2, 4] : [8, 4], .55); }); });
    }
    // overlays
    if (ly.ema) { poly(this.e[9], C.go, 1.1); poly(this.e[21], C.a, 1.5); poly(this.e[50], C.c, 1.5); }
    if (ly.e200 && !mini) poly(this.e[200], C.tx, 1.6, [6, 3]);
    if (ly.vwap && !mini) poly(this.vw, C.go, 1.3, [2, 3]);
    if (ly.st && !mini) { let seg = [], dirp = 0; const flush = () => { if (seg.length > 1) { x.beginPath(); seg.forEach((p, j) => x[j ? 'lineTo' : 'moveTo'](p[0], p[1])); x.strokeStyle = dirp > 0 ? C.up : C.dn; x.lineWidth = 1.8; x.stroke(); } seg = []; };
      data.forEach((d, i) => { const v = this.st.v[start + i], dd = this.st.d[start + i]; if (v == null) return; if (dd !== dirp) { flush(); dirp = dd; } seg.push([X(i), Y(v)]); }); flush(); }
    if (ly.bb) poly(this.bb.map(b => b && b[1]), C.b, 1);
    // ─── forecast: cone, typical-path candles, markers ───
    if (nF) {
      const b = fc.bands, last = data[i0].c, band = (u, dn, al) => { x.beginPath(); x.moveTo(X(i0), Y(last)); u.forEach((v, j) => x.lineTo(X(i0 + 1 + j), Y(v))); for (let j = dn.length - 1; j >= 0; j--) x.lineTo(X(i0 + 1 + j), Y(dn[j])); x.closePath(); x.fillStyle = C.b; x.globalAlpha = al; x.fill(); x.globalAlpha = 1; };
      const cst = T.UI.cone || 'fill'; if (cst === 'fill') { if (b.p95) band(b.p95, b.p5, .07); band(b.p90, b.p10, .1); band(b.p75, b.p25, .16); }
      const up = b.p50[nF - 1] >= last, mc = up ? fu : fd;
      [b.p90, b.p10].forEach(arr => { x.beginPath(); x.moveTo(X(i0), Y(last)); arr.forEach((v, j) => x.lineTo(X(i0 + 1 + j), Y(v))); x.strokeStyle = C.b; x.globalAlpha = .55; x.lineWidth = 1; x.setLineDash([2, 3]); x.stroke(); x.setLineDash([]); x.globalAlpha = 1; });
      x.beginPath(); x.moveTo(X(i0), Y(last)); b.p50.forEach((v, j) => x.lineTo(X(i0 + 1 + j), Y(v))); x.setLineDash([6, 4]); x.strokeStyle = mc; x.lineWidth = 1.8; x.shadowColor = mc; x.shadowBlur = (T.UI.glow || 0) * 5; x.stroke(); x.shadowBlur = 0; x.setLineDash([]);
      if (fc.range && !mini) { const fx = X(i0 + 1); hline(fc.range.hi, fu, 1, [3, 3], .65, fx, W - padR); hline(fc.range.lo, fd, 1, [3, 3], .65, fx, W - padR); if (yOK(fc.range.hi)) { x.fillStyle = fu; x.textAlign = 'left'; x.fillText('سقف انتظاری', fx + 4, Y(fc.range.hi) - 7); } if (yOK(fc.range.lo)) { x.fillStyle = fd; x.textAlign = 'left'; x.fillText('کف انتظاری', fx + 4, Y(fc.range.lo) + 8); } }
      // entry→TP shading in the future zone
      if (ly.lv && sig && sig.side !== 'WAIT' && !mini) { const fx = X(i0 + 1) - cw / 2; x.save(); x.globalAlpha = .07; x.fillStyle = C.up; x.fillRect(fx, Math.min(Y(sig.entry), Y(sig.tp3)), W - padR - fx, Math.abs(Y(sig.tp3) - Y(sig.entry))); x.fillStyle = C.dn; x.fillRect(fx, Math.min(Y(sig.entry), Y(sig.stop)), W - padR - fx, Math.abs(Y(sig.stop) - Y(sig.entry))); x.restore(); }
      fc.candles.forEach((d, j) => { const cx = X(i0 + 1 + j), upc = d.close >= d.open, col = upc ? fu : fd, bw = Math.max(1.6, cw * .66), y0 = Y(Math.max(d.open, d.close)), bh = Math.max(1.5, Math.abs(Y(d.open) - Y(d.close)));
        x.strokeStyle = col; x.lineWidth = Math.max(1, Math.min(1.6, cw * .18)); x.beginPath(); x.moveTo(cx, Y(d.high)); x.lineTo(cx, Y(d.low)); x.stroke();
        x.globalAlpha = .62; x.fillStyle = col; x.fillRect(cx - bw / 2, y0, bw, bh); x.globalAlpha = 1; x.lineWidth = 1.2; x.strokeStyle = col; x.strokeRect(cx - bw / 2 + .5, y0 + .5, Math.max(1, bw - 1), Math.max(1, bh - 1)); });
      unclip();
      // step markers + probability of being above "now"
      if (!mini) { const stepEvery = W < 480 ? 8 : 4; fc.candles.forEach((d, j) => { const n = j + 1; if (n % stepEvery) return; const cx = X(i0 + 1 + j); x.save(); x.globalAlpha = .22; x.strokeStyle = C.tx; x.setLineDash([1, 4]); x.beginPath(); x.moveTo(cx, padT); x.lineTo(cx, padT + chH); x.stroke(); x.restore();
          const p = fc.step_prob && fc.step_prob[j]; x.textAlign = 'center'; x.font = '9.5px "Segoe UI",Tahoma,sans-serif'; x.fillStyle = C.mu; x.fillText('+' + n, cx, mainH - 20); if (p != null) { x.fillStyle = p >= .5 ? C.up : C.dn; x.fillText(Math.round(p * 100) + '٪', cx, mainH - 8); } x.font = '10.5px "Segoe UI",Tahoma,sans-serif'; }); }
      // end-of-horizon tags
      if (!mini) { const ex2 = W - padR - 3, tg = (arr, col, dy, nm) => { const v = arr[nF - 1], y = Y(v) + dy; if (y < padT || y > padT + chH) return; const t = `${nm} ${T.fpct((v / last - 1) * 100, 1)}`; x.font = 'bold 10px "Segoe UI",Tahoma,sans-serif'; const tw = x.measureText(t).width + 8; x.fillStyle = col; x.globalAlpha = .88; x.fillRect(ex2 - tw, y - 8, tw, 15); x.globalAlpha = 1; x.fillStyle = '#000'; x.textAlign = 'right'; x.fillText(t, ex2 - 4, y); x.font = '10.5px "Segoe UI",Tahoma,sans-serif'; };
        tg(b.p90, fu, -9, '۹۰٪'); tg(b.p50, mc, 0, '۵۰٪'); tg(b.p10, fd, 9, '۱۰٪'); }
      // where the typical path first meets TP1 / SL
      if (ly.lv && sig && sig.side !== 'WAIT' && !mini) { const hit = (lvl, col, nm) => { const j = fc.candles.findIndex(d => sig.side === 'LONG' ? (nm === 'SL' ? d.low <= lvl : d.high >= lvl) : (nm === 'SL' ? d.high >= lvl : d.low <= lvl)); if (j < 0) return; const cx = X(i0 + 1 + j), cy = Y(lvl); x.fillStyle = col; x.beginPath(); x.moveTo(cx, cy - 6); x.lineTo(cx + 6, cy); x.lineTo(cx, cy + 6); x.lineTo(cx - 6, cy); x.closePath(); x.fill(); x.fillStyle = C.tx; x.textAlign = 'center'; x.font = '9.5px "Segoe UI",Tahoma,sans-serif'; x.fillText(`${nm}·${j + 1}`, cx, nm === 'SL' ? cy + 14 : cy - 12); x.font = '10.5px "Segoe UI",Tahoma,sans-serif'; };
        hit(sig.tp1, C.up, 'TP1'); hit(sig.stop, C.dn, 'SL'); }
      // legend
      if (!mini && W >= 600) { const lx = X(i0 + 1) + 2, ly0 = padT + chH - 34; x.font = '10px "Segoe UI",Tahoma,sans-serif'; x.textAlign = 'left'; x.fillStyle = fu; x.fillRect(lx, ly0 - 4, 8, 8); x.fillStyle = C.tx; x.globalAlpha = .85; x.fillText('آینده ▲', lx + 11, ly0); x.globalAlpha = 1; x.fillStyle = fd; x.fillRect(lx, ly0 + 9, 8, 8); x.fillStyle = C.tx; x.globalAlpha = .85; x.fillText('آینده ▼', lx + 11, ly0 + 13); x.globalAlpha = 1; x.font = '10.5px "Segoe UI",Tahoma,sans-serif'; }
      else if (mini) { x.fillStyle = mc; x.textAlign = 'center'; x.fillText('پیش‌بینی ◂', X(i0 + 1 + nF / 2), padT + 8); }
    }
    unclip();
    // signal levels
    if (ly.lv && sig && sig.side !== 'WAIT' && !mini) { [[sig.entry, C.a, 'ورود'], [sig.stop, C.dn, 'SL'], [sig.tp1, C.up, 'TP1'], [sig.tp2, C.up, 'TP2'], [sig.tp3, C.up, 'TP3']].forEach(([p, col, t]) => { hline(p, col, 1.2, [6, 4], .9); tag(p, col, t); }); }
    const lp = k[k.length - 1].c; if (this.view.off === 0) { hline(lp, C.go, 1, [1, 3], .7); tag(lp, C.go, T.fp(lp)); }
    // ─── sub panes ───
    pk.forEach((kind, pi) => { const y0 = mainH + pi * paneH + 6, hh = paneH - 10; x.save(); x.strokeStyle = C.ln; x.globalAlpha = .6; x.strokeRect(4, y0, plotW, hh); x.restore();
      const val = (arr, lo2, hi2) => v => y0 + (1 - (v - lo2) / (hi2 - lo2)) * hh, name = { rsi: 'RSI 14', macd: 'MACD', srsi: 'StochRSI' }[kind];
      x.fillStyle = C.mu; x.textAlign = 'left'; x.fillText(name, 8, y0 + 9);
      const line = (arr, f, col, w) => { x.beginPath(); let fi = true; data.forEach((d, i) => { const v = arr[start + i]; if (v != null) { x[fi ? 'moveTo' : 'lineTo'](X(i), f(v)); fi = false; } }); x.strokeStyle = col; x.lineWidth = w; x.stroke(); };
      if (kind === 'rsi' || kind === 'srsi') { const f = val(null, 0, 100); [20, 50, 80].forEach(v => { x.save(); x.globalAlpha = .45; x.strokeStyle = v === 50 ? C.mu : v === 80 ? C.dn : C.up; x.setLineDash([3, 4]); x.beginPath(); x.moveTo(4, f(v)); x.lineTo(4 + plotW, f(v)); x.stroke(); x.restore(); });
        if (kind === 'rsi') { line(this.rsi, f, C.a, 1.5); const v = this.rsi[end - 1]; if (v != null) { x.fillStyle = v > 70 ? C.dn : v < 30 ? C.up : C.tx; x.textAlign = 'right'; x.fillText(T.dg(v.toFixed(0)), W - padR - 4, y0 + 9); } }
        else { line(this.srsi.k, f, C.a, 1.4); line(this.srsi.d, f, C.c, 1.2); const v = this.srsi.k[end - 1]; if (v != null) { x.fillStyle = C.tx; x.textAlign = 'right'; x.fillText(T.dg(v.toFixed(0)), W - padR - 4, y0 + 9); } } }
      else { const seg = data.map((d, i) => this.macd.h[start + i]), mx = Math.max(...seg.map(Math.abs), ...data.map((d, i) => Math.abs(this.macd.l[start + i])), 1e-12), f = val(null, -mx, mx);
        x.save(); x.globalAlpha = .45; x.strokeStyle = C.mu; x.beginPath(); x.moveTo(4, f(0)); x.lineTo(4 + plotW, f(0)); x.stroke(); x.restore();
        data.forEach((d, i) => { const v = this.macd.h[start + i], bw = Math.max(1, cw * .62); x.fillStyle = v >= 0 ? C.up : C.dn; x.globalAlpha = .55; x.fillRect(X(i) - bw / 2, Math.min(f(0), f(v)), bw, Math.abs(f(v) - f(0))); x.globalAlpha = 1; });
        line(this.macd.l, f, C.a, 1.3); line(this.macd.g, f, C.c, 1.2); } });
    // ─── crosshair + tooltip ───
    if (this.cross && !mini) {
      const { x: cx0, y: cy } = this.cross, i = Math.max(0, Math.min(slots - 1, Math.floor((cx0 - 4) / cw))), isF = i > i0 && nF, d = isF ? null : real[i], fcn = isF ? fc.candles[i - i0 - 1] : null;
      if (d || fcn) { x.save(); x.strokeStyle = C.tx; x.globalAlpha = .4; x.setLineDash(T.UI.crossStyle === 'solid' ? [] : T.UI.crossStyle === 'dot' ? [1, 4] : [3, 3]); x.beginPath(); x.moveTo(X(i), padT); x.lineTo(X(i), mainH + pk.length * paneH); if (cy < padT + chH) { x.moveTo(0, cy); x.lineTo(W - padR, cy); } x.stroke(); x.restore();
        if (cy < padT + chH) { x.fillStyle = C.a; x.fillRect(W - padR + 1, cy - 8, padR - 2, 16); x.fillStyle = '#000'; x.textAlign = 'left'; x.fillText(T.fp(lo + (hi - lo) * (1 - (cy - padT) / chH)), W - padR + 4, cy); }
        let lines, colr = C.a; const fmtT = t => { const q = new Date(t); return `${q.toLocaleDateString('fa-IR')} ${String(q.getHours()).padStart(2, '0')}:${String(q.getMinutes()).padStart(2, '0')}`; };
        if (d) { const gi = start + i, rs = this.rsi[gi]; lines = [fmtT(d.t), `O ${T.fp(d.o)}  H ${T.fp(d.h)}`, `L ${T.fp(d.l)}  C ${T.fp(d.c)}`, `${T.fpct((d.c - d.o) / d.o * 100)}  ·  RSI ${rs != null ? T.dg(rs.toFixed(0)) : '—'}`]; const pr = ((this.ov.pat || {}).recent || []).filter(r => r.t === d.t).map(r => r.fa); if (pr.length) lines.push('الگو: ' + pr.join('، ')); }
        else { const j = i - i0 - 1, b = fc.bands; colr = fcn.close >= fcn.open ? fu : fd; lines = [`کندل آینده #${T.dg(j + 1)} · ${fmtT(tbase + (j + 1) * ivms)}`, `O ${T.fp(fcn.open)}  H ${T.fp(fcn.high)}`, `L ${T.fp(fcn.low)}  C ${T.fp(fcn.close)}`, `محدوده ۱۰–۹۰٪: ${T.fp(b.p10[j])} ← ${T.fp(b.p90[j])}`, `احتمال بالاتر از اکنون: ${T.dg(Math.round((fc.step_prob[j] || .5) * 100))}٪`]; }
        const bw2 = Math.min(W - 16, 196), bh2 = lines.length * 14 + 8, bx = cx0 > W / 2 ? 8 : W - padR - bw2 - 4; x.fillStyle = 'rgba(0,0,0,.78)'; x.fillRect(bx, padT + 4, bw2, bh2); x.strokeStyle = colr; x.lineWidth = 1; x.strokeRect(bx, padT + 4, bw2, bh2); x.fillStyle = '#fff'; x.textAlign = 'left'; x.font = '10.5px "Segoe UI",Tahoma,sans-serif'; lines.forEach((s, j) => x.fillText(s, bx + 6, padT + 17 + j * 14)); } }
  }
}
ch.CandleChart = CandleChart;

/* real mini candles for lists: last 40 real OHLC + the 32 simulated typical-path candles (distinct colours) + cone */
ch.miniCandles = function (row, W = 250, H = 76, sideCol) {
  const P = row.ohlc || [], F = row.fcc || [];
  if (P.length < 5) return ch.spark(row.spark || [], W, H, sideCol || 'var(--a)', row.fc);
  const n = P.length + F.length, pad = 3, sl = (W - pad * 2) / (n + 1), bw = Math.max(1.3, sl * .62), fc = row.fc || {};
  let lo = Math.min(...P.map(c => c[2])), hi = Math.max(...P.map(c => c[1]));
  if (F.length) { lo = Math.min(lo, ...F.map(c => c[2]), ...(fc.p10 || [])); hi = Math.max(hi, ...F.map(c => c[1]), ...(fc.p90 || [])); }
  const m = (hi - lo) * .06 || hi * .01; lo -= m; hi += m; const Y = p => 2 + (1 - (p - lo) / (hi - lo)) * (H - 4), X = i => pad + (i + .5) * sl, last = P[P.length - 1][3];
  const cd = (c, i, up, dn, op) => { const u = c[3] >= c[0], col = u ? up : dn, y0 = Y(Math.max(c[0], c[3])), bh = Math.max(1, Math.abs(Y(c[0]) - Y(c[3])));
    return `<path d="M${X(i).toFixed(1)} ${Y(c[1]).toFixed(1)}V${Y(c[2]).toFixed(1)}" stroke="${col}" stroke-width="1"/><rect x="${(X(i) - bw / 2).toFixed(1)}" y="${y0.toFixed(1)}" width="${bw.toFixed(1)}" height="${bh.toFixed(1)}" fill="${col}" fill-opacity="${op}"/>`; };
  let cone = '';
  if (fc.p10 && fc.p90 && F.length) { const up = fc.p90.map((v, j) => `${X(P.length + j).toFixed(1)} ${Y(v).toFixed(1)}`), dn = fc.p10.map((v, j) => `${X(P.length + j).toFixed(1)} ${Y(v).toFixed(1)}`).reverse(); cone = `<path d="M${X(P.length - 1).toFixed(1)} ${Y(last).toFixed(1)}L${up.join('L')}L${dn.join('L')}Z" fill="var(--b)" fill-opacity=".14"/>`; }
  const nowX = X(P.length - 1) + sl / 2;
  return `<svg class="mcv" viewBox="0 0 ${W} ${H}" style="direction:ltr" preserveAspectRatio="none"><path d="M${pad} ${Y(last).toFixed(1)}H${W - pad}" stroke="var(--go)" stroke-width=".8" stroke-dasharray="1 3" opacity=".7"/>${cone}
  ${P.map((c, i) => cd(c, i, 'var(--up)', 'var(--dn)', 1)).join('')}${F.length ? `<path d="M${nowX.toFixed(1)} 0V${H}" stroke="var(--go)" stroke-width=".8" stroke-dasharray="3 3" opacity=".8"/>` : ''}${F.map((c, j) => cd(c, P.length + j, 'var(--fu)', 'var(--fd)', .7)).join('')}</svg>`;
};

/* cumulative-delta vs price (both scaled 0-1) */
ch.cvd = function (f) {
  if (!f || !f.cvd || f.cvd.length < 4) return '<div class="empty">داده کافی نیست.</div>';
  const W = 340, H = 120, L = 6, R = 6, n = f.cvd.length, X = i => L + i / (n - 1) * (W - L - R), pr = f.price, lo = Math.min(...pr), hi = Math.max(...pr), Yp = v => 8 + (1 - (v - lo) / ((hi - lo) || 1)) * (H - 24), Yc = v => 8 + (1 - v) * (H - 24);
  const pl = (arr, Y, col, w) => `<path d="${arr.map((v, i) => `${i ? 'L' : 'M'}${X(i).toFixed(1)} ${Y(v).toFixed(1)}`).join('')}" fill="none" stroke="${col}" stroke-width="${w}"/>`;
  return `<svg viewBox="0 0 ${W} ${H}" style="direction:ltr">${pl(pr, Yp, 'var(--tx)', 1.6)}${pl(f.cvd, Yc, 'var(--a)', 2)}<text x="${L}" y="${H - 4}" font-size="9.5" fill="var(--tx)">— قیمت</text><text x="${L + 60}" y="${H - 4}" font-size="9.5" fill="var(--a)">— دلتای حجم تجمعی (CVD)</text></svg>`;
};

/* average range / relative volume by hour of day (local time) */
ch.hours = function (h) {
  if (!h || !h.range) return '<div class="empty">پس از اولین اسکن کامل نمایش داده می‌شود.</div>';
  const off = -new Date().getTimezoneOffset() / 60, shift = a => a.map((_, i) => a[((i - Math.round(off)) % 24 + 24) % 24]), r = shift(h.range), v = shift(h.vol), mx = Math.max(...r) || 1, W = 340, H = 120, bw = (W - 8) / 24;
  const top = r.map((x, i) => [x, i]).sort((a, b) => b[0] - a[0]).slice(0, 3).map(x => x[1]);
  return `<svg viewBox="0 0 ${W} ${H}" style="direction:ltr">${r.map((x, i) => { const hh = x / mx * (H - 32); return `<rect x="${(4 + i * bw + 1).toFixed(1)}" y="${(H - 18 - hh).toFixed(1)}" width="${(bw - 2).toFixed(1)}" height="${hh.toFixed(1)}" rx="2" fill="${top.includes(i) ? 'var(--go)' : 'var(--a)'}" fill-opacity="${top.includes(i) ? .9 : .45}" data-tip="${i}:00 — دامنه ${x.toFixed(2)}٪ · حجم نسبی ${v[i].toFixed(2)}×"/>${i % 3 === 0 ? `<text x="${(4 + i * bw + bw / 2).toFixed(1)}" y="${H - 5}" text-anchor="middle" font-size="9" fill="var(--mu)">${i}</text>` : ''}`; }).join('')}</svg>`;
};
})();

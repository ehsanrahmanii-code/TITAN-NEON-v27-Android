"""TITAN PRO NEON — Flask API + dashboard."""
from __future__ import annotations
from urllib.parse import urlparse

from flask import Flask, jsonify, request, render_template

from app import settings
from app.config import (HOST, PORT, VERSION, TIMEFRAMES, DATA_DIR, to_symbol, valid_symbol, to_base, KLINE_LIMIT, MAX_LEVERAGE,
                        FORECAST_CANDLES, SIDE_THRESHOLD, CHART_KLINES, STARTING_CAPITAL, RISK_PER_TRADE_PCT, FEE_TAKER, SLIPPAGE)
from app.engine import scanner
from app.data.market import fetch_klines, fetch_prices, fetch_ticker, closed_only, fetch_depth, fetch_derivs
from app.analysis import backtest as bt
from app.analysis import patterns as pat
from app.engine import alerts as alerts_mod, evidence, siglog
from app.exchange import policy
from app.analysis import planner
from app.analysis.technicals import analyze
from app.analysis.forecast import forecast_summary
from app.ai.gemini import ai_opinion, brain_status
from app.exchange import paper as exchange

app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["JSON_AS_ASCII"] = False
app.json.ensure_ascii = False


@app.before_request
def _same_origin_guard():
    """Block cross-site POSTs (a random web page must not be able to trade your paper account)."""
    if request.method in ("POST", "DELETE", "PUT"):
        o = request.headers.get("Origin")
        if o and urlparse(o).netloc != request.host:
            return jsonify({"ok": False, "error": "cross-origin blocked"}), 403


@app.after_request
def _headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("Referrer-Policy", "no-referrer")
    if request.path.startswith("/api/"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


@app.errorhandler(Exception)
def _err(e):
    code = getattr(e, "code", 500)
    return jsonify({"ok": False, "error": str(e)[:200]}), code if isinstance(code, int) else 500


def _sym_or_400(s: str):
    s = to_symbol(s)
    return s if valid_symbol(s) else None


def _tf(default="1h") -> str:
    t = request.args.get("tf", default)
    return t if t in TIMEFRAMES else default


@app.route("/")
def index():
    return render_template("index.html", version=VERSION)


@app.route("/api/status")
def api_status():
    return jsonify({"version": VERSION, "timeframes": TIMEFRAMES, "symbols": settings.get_watchlist(),
                    "data_dir": str(DATA_DIR), "max_leverage": MAX_LEVERAGE, "scan_sec": settings.get_scan_sec(),
                    "threshold": SIDE_THRESHOLD, "forecast_n": FORECAST_CANDLES, "start_capital": STARTING_CAPITAL,
                    "risk_pct": RISK_PER_TRADE_PCT, "fee": FEE_TAKER, "slip": SLIPPAGE, **scanner.get_status()})


@app.route("/api/scan", methods=["POST"])
def api_scan():
    syms = [to_symbol(s) for s in request.args.getlist("symbol") if valid_symbol(s)] or None
    tfs = [t for t in request.args.getlist("tf") if t in TIMEFRAMES] or (None if request.args.get("full") == "1" else ["1h"])
    return jsonify(scanner.start_scan(syms, tfs))


@app.route("/api/matrix")
def api_matrix():
    return jsonify(scanner.get_matrix())


def _on_demand(symbol: str, tf: str) -> dict:
    full = fetch_klines(symbol, tf, KLINE_LIMIT)
    df = closed_only(full, tf)
    try:
        tk = fetch_ticker(symbol)
    except Exception:                                            # noqa: BLE001
        tk = {"symbol": symbol, "price": float(full["close"].iloc[-1]), "change_pct": 0}
    sig = analyze(df, symbol, tf, price=tk["price"])
    lv = {"entry": sig.entry, "stop": sig.stop, "tp1": sig.tp1, "tp2": sig.tp2, "tp3": sig.tp3} if sig.side != "WAIT" else None
    fc = forecast_summary(df, sig.side, FORECAST_CANDLES, f"{symbol}{tf}", levels=lv)
    kl = [{"t": int(r.open_time.timestamp() * 1000), "o": float(r.open), "h": float(r.high), "l": float(r.low),
           "c": float(r.close), "v": float(r.volume)} for r in full.tail(CHART_KLINES).itertuples()]
    return {"signal": sig.to_dict(), "forecast": fc, "ticker": tk, "klines": kl, "updated": __import__("time").time()}


@app.route("/api/coin/<symbol>")
def api_coin(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    tf = _tf()
    item = scanner.get_cache_item(sym, tf)
    if not item:
        try:
            item = _on_demand(sym, tf)
            scanner.put_cache_item(sym, tf, item)
        except Exception as e:                                   # noqa: BLE001
            return jsonify({"error": str(e)[:160]})
    out = dict(item)
    out["all_tf"] = {t: c["signal"] for t in TIMEFRAMES if (c := scanner.get_cache_item(sym, t))}
    out["all_forecasts"] = {t: c.get("forecast") for t in TIMEFRAMES if (c := scanner.get_cache_item(sym, t))}
    out["base"] = to_base(sym)
    return jsonify(out)


@app.route("/api/deep/<symbol>")
def api_deep(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    try:
        d = scanner.build_deep(sym, _tf())
        return jsonify(d)
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]})


@app.route("/api/ai/<symbol>")
def api_ai(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"ok": False, "error": "نماد نامعتبر"}), 400
    try:
        deep = scanner.build_deep(sym, _tf())
        item = scanner.get_cache_item(sym, _tf())
        return jsonify(ai_opinion(sym, deep, (item or {}).get("ticker")))
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"ok": False, "error": str(e)[:160]})


_BT_CACHE: dict = {}


@app.route("/api/market")
def api_market():
    return jsonify(scanner.market_overview())


@app.route("/api/micro/<symbol>")
def api_micro(symbol):
    """Order-book depth + perpetual derivatives (funding, OI, long/short). Each part fails independently."""
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    out = {"symbol": sym}
    for k, fn in (("depth", fetch_depth), ("derivs", fetch_derivs)):
        try:
            out[k] = fn(sym)
        except Exception as e:                                   # noqa: BLE001
            out[k] = {"ok": False, "reason": str(e)[:80]}
    return jsonify(out)


@app.route("/api/backtest/<symbol>")
def api_backtest(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    tf = _tf()
    try:
        full = fetch_klines(sym, tf, 500)
        df = closed_only(full, tf)
        key = (sym, tf, str(df["open_time"].iloc[-1]))
        hit = _BT_CACHE.get(key)
        if hit and __import__("time").time() - hit[0] < 600:
            return jsonify(hit[1])
        res = bt.run(df, sym, tf)
        res.update(symbol=sym, tf=tf, candles=len(df))
        _BT_CACHE.clear() if len(_BT_CACHE) > 40 else None
        _BT_CACHE[key] = (__import__("time").time(), res)
        return jsonify(res)
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]})


_PAT_CACHE: dict = {}


@app.route("/api/patterns/<symbol>")
def api_patterns(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    tf = _tf()
    try:
        full = fetch_klines(sym, tf, KLINE_LIMIT)
        df = closed_only(full, tf)
        key = (sym, tf, str(df["open_time"].iloc[-1]))
        hit = _PAT_CACHE.get(key)
        if hit and __import__("time").time() - hit[0] < 60:
            return jsonify(hit[1])
        item = scanner.get_item(sym, tf) if hasattr(scanner, "get_item") else None
        zones = ((item or {}).get("signal", {}).get("levels") or {}).get("zones") or []
        pooled = scanner.pattern_stats(tf)
        if not pooled:
            pooled = pat.pooled_stats([df])
        recent = pat.detect_recent(df, 60, zones)
        own = pat.pooled_stats([df])
        for r in recent:
            info = pat.INFO[r["k"]]
            r.update(meaning=info[2], expect=info[3], confirm=info[4], stat=pooled.get(r["k"]), own=own.get(r["k"]),
                     verdict=pat.verdict(pooled.get(r["k"]), r["bias"]))
        structs = pat.structures(df)
        summ = pat.summarize(recent, structs, pooled, tf)
        top = []
        for k, v in pooled.items():
            h8 = (v.get("h") or {}).get("8") if k != "_base" else None
            if h8 and h8["n"] >= 15:
                top.append({"k": k, "fa": pat.INFO[k][0], "bias": pat.BIAS[pat.INFO[k][1]], "n": h8["n"], "win": h8["win"], "mean": h8["mean"], "t": h8["t"]})
        top.sort(key=lambda z: -abs(z["t"]))
        out = {"symbol": sym, "tf": tf, "recent": recent[:40], "structs": structs, "summary": summ, "base": pooled.get("_base"), "top": top[:12],
               "sample": {"pooled_tf": tf, "coins": len(settings.get_watchlist())}, "hours": scanner.hour_stats(), "n": len(df)}
        _PAT_CACHE.clear() if len(_PAT_CACHE) > 60 else None
        _PAT_CACHE[key] = (__import__("time").time(), out)
        return jsonify(out)
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]})


@app.route("/api/alerts", methods=["GET", "POST"])
def api_alerts():
    if request.method == "POST":
        try:
            return jsonify(alerts_mod.add(request.get_json(force=True, silent=True) or {}))
        except (ValueError, TypeError) as e:
            return jsonify({"error": str(e)}), 400
    scanner.alerts_tick()
    return jsonify({"alerts": alerts_mod.list_all()})


@app.route("/api/alerts/<aid>", methods=["DELETE"])
def api_alert_del(aid):
    return jsonify({"ok": alerts_mod.remove(aid)})


_PLAN_CACHE: dict = {}


@app.route("/api/plan/<symbol>")
def api_plan(symbol):
    """Entry / stop / target laboratory (both sides) for the current candle."""
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    tf = _tf()
    try:
        full = fetch_klines(sym, tf, KLINE_LIMIT)
        df = closed_only(full, tf)
        key = (sym, tf, str(df["open_time"].iloc[-1]))
        hit = _PLAN_CACHE.get(key)
        if hit and __import__("time").time() - hit[0] < 45:
            return jsonify(hit[1])
        px = float(df["close"].iloc[-1])
        sig = analyze(df, sym, tf, price=px).to_dict()
        lab = scanner.plan_lab(sym, tf, df, sig, px)
        lab.update(symbol=sym, tf=tf, verdict_side=sig["side"], zones=(sig.get("levels") or {}).get("zones", []))
        _PLAN_CACHE.clear() if len(_PLAN_CACHE) > 40 else None
        _PLAN_CACHE[key] = (__import__("time").time(), lab)
        return jsonify(lab)
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]})


@app.route("/api/order", methods=["POST"])
def api_order():
    b = request.get_json(force=True, silent=True) or {}
    sym = _sym_or_400(str(b.get("symbol", "")))
    if not sym:
        return jsonify({"ok": False, "error": "نماد نامعتبر"})
    b["symbol"], b["source"] = sym, "manual"
    if b.get("mode") == "market":
        prices = _live_prices(); px = prices.get(sym) or float(b.get("price", 0) or 0)
        try:
            return jsonify(exchange.open_position(sym, b.get("side", ""), px, float(b["stop"]), float(b["tp1"]), float(b["tp2"]), float(b.get("tp3") or 0), leverage=int(b.get("leverage") or 10),
                                                  risk_pct=float(b.get("risk_pct") or 0) or None, prices=prices, plan=str(b.get("plan", ""))[:40], deadline_sec=float(b.get("deadline_h") or 0) * 3600))
        except (KeyError, TypeError, ValueError):
            return jsonify({"ok": False, "error": "ورودی نامعتبر"})
    return jsonify(exchange.place_order(b))


@app.route("/api/order/cancel", methods=["POST"])
def api_order_cancel():
    return jsonify(exchange.cancel_order(str((request.get_json(force=True, silent=True) or {}).get("id", ""))))


@app.route("/api/auto/config", methods=["GET", "POST"])
def api_auto_cfg():
    if request.method == "POST":
        try:
            policy.save_cfg(request.get_json(force=True, silent=True) or {})
        except (ValueError, TypeError) as e:
            return jsonify({"error": str(e)}), 400
    return jsonify({"cfg": policy.effective(), "modes": {k: v for k, v in policy.MODES.items()}, "pause": exchange.pause_state()})


@app.route("/api/auto/resume", methods=["POST"])
def api_auto_resume():
    return jsonify(exchange.clear_pause())


@app.route("/api/evidence")
def api_evidence():
    return jsonify({"rows": evidence.all_rows(), "agg": evidence.aggregate()})


@app.route("/api/signals/log")
def api_siglog():
    return jsonify(siglog.view())


@app.route("/api/klines/<symbol>")
def api_klines(symbol):
    sym = _sym_or_400(symbol)
    if not sym:
        return jsonify({"error": "نماد نامعتبر"}), 400
    try:
        limit = max(30, min(int(request.args.get("limit", 200)), 300))
    except ValueError:
        limit = 200
    try:
        df = fetch_klines(sym, _tf(), limit).tail(limit)
        return jsonify({"symbol": sym, "tf": _tf(), "klines": [
            {"t": int(r.open_time.timestamp() * 1000), "o": float(r.open), "h": float(r.high), "l": float(r.low),
             "c": float(r.close), "v": float(r.volume)} for r in df.itertuples()]})
    except Exception as e:                                       # noqa: BLE001
        return jsonify({"error": str(e)[:160]}), 502


def _live_prices() -> dict:
    try:
        return fetch_prices(settings.get_watchlist() + [p["symbol"] for p in exchange.get_account()["open_positions"]])
    except Exception:                                            # noqa: BLE001
        return {}


@app.route("/api/exchange")
def api_exchange():
    return jsonify(exchange.get_account(_live_prices()))


@app.route("/api/exchange/open", methods=["POST"])
def api_open():
    b = request.get_json(force=True, silent=True) or {}
    sym = _sym_or_400(str(b.get("symbol", "")))
    if not sym:
        return jsonify({"ok": False, "error": "نماد نامعتبر"})
    try:
        prices = _live_prices()
        entry = prices.get(sym) or float(b.get("entry", 0))
        return jsonify(exchange.open_position(
            sym, b.get("side", ""), entry, float(b.get("stop", 0)), float(b.get("tp1", 0)), float(b.get("tp2", 0)),
            float(b.get("tp3", 0) or 0), leverage=int(b.get("leverage", 10)), prices=prices,
            score=float(b.get("score", 0) or 0), regime=str(b.get("regime", ""))[:12]))
    except (TypeError, ValueError):
        return jsonify({"ok": False, "error": "ورودی نامعتبر"})


@app.route("/api/exchange/close", methods=["POST"])
def api_close():
    b = request.get_json(force=True, silent=True) or {}
    pid = str(b.get("id", ""))
    pos = next((p for p in exchange.get_account()["open_positions"] if p["id"] == pid), None)
    if not pos:
        return jsonify({"ok": False, "error": "یافت نشد"})
    try:
        price = fetch_ticker(pos["symbol"])["price"]               # always the LIVE price (v1 closed at entry!)
    except Exception:                                            # noqa: BLE001
        return jsonify({"ok": False, "error": "قیمت زنده در دسترس نیست"})
    return jsonify(exchange.close_position(pid, price))


@app.route("/api/exchange/auto", methods=["POST"])
def api_auto():
    b = request.get_json(force=True, silent=True) or {}
    return jsonify(exchange.set_auto_trade(bool(b.get("enabled", False))))


@app.route("/api/exchange/reset", methods=["POST"])
def api_reset():
    return jsonify(exchange.reset_account())


@app.route("/api/settings", methods=["GET", "POST"])
def api_settings():
    if request.method == "GET":
        return jsonify(settings.get())
    try:
        return jsonify(settings.update(request.get_json(force=True, silent=True) or {}))
    except (ValueError, TypeError) as e:
        return jsonify({"ok": False, "error": str(e)}), 400


def main():
    from waitress import serve
    scanner.start_background()
    print(f"TITAN PRO NEON {VERSION} → http://{HOST}:{PORT}   data: {DATA_DIR}")
    serve(app, host=HOST, port=PORT, threads=12)


if __name__ == "__main__":
    main()

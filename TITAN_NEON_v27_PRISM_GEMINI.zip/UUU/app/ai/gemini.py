"""Gemini — sole AI brain for TITAN.

Reads API key ONLY from secret/ (gemini_api_key.txt | gemini_key.txt | GEMINI_API_KEY.txt).
Unifies technicals, grade, forecast, microstructure, Edge and checklist into one reasoned opinion.
No other AI providers are used.
"""
from __future__ import annotations
import json
import os
import re
import time
from typing import Any
import requests

from app.config import SECRET_DIR, GEMINI_MODELS, AI_TIMEOUT_SEC

_CACHE: dict[str, tuple[float, dict]] = {}
_CACHE_TTL = 240.0


def _load_key() -> str:
    for name in ("gemini_api_key.txt", "gemini_key.txt", "GEMINI_API_KEY.txt"):
        p = SECRET_DIR / name
        try:
            if p.is_file():
                k = p.read_text(encoding="utf-8").strip()
                if k and not k.startswith("#"):
                    return k
        except Exception:
            pass
    return (os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or "").strip()


def _call_gemini(prompt: str, key: str) -> str:
    last_err = None
    for model in GEMINI_MODELS:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
        body = {
            "contents": [{"parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": 0.25,
                "maxOutputTokens": 900,
                "responseMimeType": "application/json",
            },
        }
        try:
            r = requests.post(url, json=body, timeout=AI_TIMEOUT_SEC)
            if r.status_code >= 400:
                last_err = f"{model}:{r.status_code}:{r.text[:160]}"
                continue
            data = r.json()
            parts = (((data.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [])
            text = "".join(p.get("text", "") for p in parts).strip()
            if text:
                return text
            last_err = f"{model}:empty"
        except Exception as e:
            last_err = f"{model}:{e}"
    raise RuntimeError(last_err or "gemini failed")


def _parse_json_loose(text: str) -> dict:
    text = (text or "").strip()
    if not text:
        return {}
    try:
        return json.loads(text)
    except Exception:
        pass
    m = re.search(r"\{[\s\S]*\}", text)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass
    return {"summary": text[:500], "side": "WAIT", "confidence": 0.4}


def _local_unify(deep: dict, sig: dict, adv: dict) -> dict:
    """Rule-based central synthesis when Gemini key is missing — still unifies all layers."""
    side = deep.get("verdict") or sig.get("side") or "WAIT"
    edge = (adv.get("edge") or {}).get("edge")
    ck = adv.get("checklist") or {}
    mb = (adv.get("micro") or {}).get("bias_pack") or {}
    rs = adv.get("rel_strength") or {}
    bullets = list(sig.get("reasons") or [])[:4]
    if edge is not None:
        bullets.append(f"Edge مرکب: {edge}/100")
    if ck.get("label"):
        bullets.append(f"چک‌لیست: {ck.get('label')} ({ck.get('score')}/{ck.get('max')})")
    if mb.get("label") and mb.get("label") != "خنثی":
        bullets.append(f"میکروساختار: {mb.get('label')}")
    if rs.get("ok"):
        bullets.append(f"قدرت نسبی vs BTC: {rs.get('rs_pct')}٪")
    conf = float(deep.get("conviction") or sig.get("confidence") or 0.4)
    if edge is not None:
        conf = min(0.95, 0.55 * conf + 0.45 * (float(edge) / 100.0))
    narrative = deep.get("narrative") or "تحلیل چندلایه محلی"
    risk = "کلید Gemini را در secret/gemini_api_key.txt بگذارید تا استدلال مرکزی Gemini فعال شود."
    warns = list(sig.get("warnings") or [])
    if deep.get("veto"):
        warns.append(str(deep.get("veto")))
    return {
        "ok": True,
        "source": "local-unify",
        "side": side,
        "confidence": round(conf, 3),
        "summary": narrative,
        "bullets": bullets[:6],
        "risk_note": risk if not warns else " · ".join(warns[:3])[:220],
        "unified": True,
        "edge": edge,
        "checklist_pct": ck.get("pct"),
        "micro_bias": mb.get("bias"),
    }


def ai_opinion(symbol: str, deep: dict | None, ticker: dict | None = None) -> dict[str, Any]:
    """Central intelligence: compare + reason over the full analysis pack."""
    deep = deep or {}
    sig = deep.get("signal") or {}
    if isinstance(sig, dict) is False:
        # Signal dataclass may have been serialized already
        try:
            sig = {
                "side": getattr(sig, "side", "WAIT"),
                "score": getattr(sig, "score", 0),
                "confidence": getattr(sig, "confidence", 0),
                "entry": getattr(sig, "entry", None),
                "stop": getattr(sig, "stop", None),
                "tp1": getattr(sig, "tp1", None),
                "tp2": getattr(sig, "tp2", None),
                "reasons": list(getattr(sig, "reasons", []) or []),
                "warnings": list(getattr(sig, "warnings", []) or []),
            }
        except Exception:
            sig = {}
    adv = deep.get("advanced") or {}
    grade = deep.get("grade") or {}
    fc = deep.get("forecast") or {}

    cache_key = f"{symbol}|{deep.get('verdict')}|{deep.get('consensus_score')}|{round(float(deep.get('conviction') or 0), 2)}"
    now = time.time()
    if cache_key in _CACHE:
        ts, cached = _CACHE[cache_key]
        if now - ts < _CACHE_TTL:
            return cached

    key = _load_key()
    if not key:
        result = _local_unify(deep, sig, adv)
        _CACHE[cache_key] = (now, result)
        return result

    price = (ticker or {}).get("price") or sig.get("entry")
    edge = (adv.get("edge") or {})
    ck = adv.get("checklist") or {}
    mb = (adv.get("micro") or {}).get("bias_pack") or {}
    rs = adv.get("rel_strength") or {}
    sess = adv.get("session") or {}

    prompt = f"""You are TITAN central trading intelligence. Unify ALL layers below into ONE coherent Persian decision.
Reply ONLY valid JSON with keys:
side (LONG|SHORT|WAIT), confidence (0-1), summary (Persian 2-4 sentences, reasoned),
bullets (array of 4-6 short Persian points comparing layers),
risk_note (Persian one line),
action (Persian one short actionable sentence: enter / wait / reduce size / wait pullback).

Coin: {symbol}
Price: {price}
=== MTF FUSION ===
verdict={deep.get('verdict')} consensus={deep.get('consensus_score')} conviction={deep.get('conviction')}
agreement={deep.get('agreement')} regime={deep.get('regime')} veto={deep.get('veto')}
L={deep.get('long_count')} S={deep.get('short_count')} W={deep.get('wait_count')}
narrative: {deep.get('narrative')}
=== PRIMARY SIGNAL ===
side={sig.get('side')} score={sig.get('score')} conf={sig.get('confidence')}
entry={sig.get('entry')} stop={sig.get('stop')} tp1={sig.get('tp1')} tp2={sig.get('tp2')}
reasons: {', '.join(sig.get('reasons') or [])}
warnings: {', '.join(sig.get('warnings') or [])}
=== GRADE ===
grade={grade.get('grade') if isinstance(grade, dict) else grade} points={grade.get('points') if isinstance(grade, dict) else ''}
=== FORECAST ===
direction={fc.get('direction')} expected_move_pct={fc.get('expected_move_pct')}
=== EDGE / CHECKLIST / MICRO / RS / SESSION ===
edge={edge.get('edge')} label={edge.get('label')} parts={edge.get('parts')}
checklist={ck.get('label')} pct={ck.get('pct')} score={ck.get('score')}/{ck.get('max')}
micro_bias={mb.get('bias')} micro_label={mb.get('label')}
rel_strength_vs_btc={rs.get('rs_pct')} rs_label={rs.get('label')}
session={sess.get('name')} hour_utc={sess.get('hour_utc')}

Rules: If layers conflict, prefer WAIT or smaller size. Higher TF + Edge + checklist completeness dominate.
If micro strongly opposes technical side, mention it and lean WAIT or reduced confidence.
"""
    try:
        text = _call_gemini(prompt, key)
        data = _parse_json_loose(text)
        side = str(data.get("side", "WAIT")).upper()
        if side not in ("LONG", "SHORT", "WAIT"):
            side = "WAIT"
        result = {
            "ok": True,
            "source": "gemini",
            "side": side,
            "confidence": float(data.get("confidence") or 0.5),
            "summary": str(data.get("summary") or "")[:700],
            "bullets": list(data.get("bullets") or [])[:6],
            "risk_note": str(data.get("risk_note") or "")[:220],
            "action": str(data.get("action") or "")[:180],
            "unified": True,
            "edge": edge.get("edge"),
            "checklist_pct": ck.get("pct"),
            "micro_bias": mb.get("bias"),
        }
    except Exception as e:
        result = _local_unify(deep, sig, adv)
        result["ok"] = False
        result["source"] = "local-fallback"
        result["risk_note"] = f"Gemini خطا: {str(e)[:120]} — تحلیل یکپارچه محلی"

    if result.get("ok") or result.get("source") == "local-fallback":
        _CACHE[cache_key] = (now, result)
    return result


def brain_status() -> dict:
    """Health of the sole AI brain."""
    key = _load_key()
    return {
        "provider": "gemini",
        "key_loaded": bool(key),
        "key_path": str(SECRET_DIR / "gemini_api_key.txt"),
        "models": list(GEMINI_MODELS),
        "cache_entries": len(_CACHE),
    }

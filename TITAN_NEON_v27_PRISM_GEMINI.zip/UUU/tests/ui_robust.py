"""Robustness: corrupted saved layout, unknown shell, reload, Android back button, rapid shell/coin switching, typing while data refreshes."""
import os, sys, json, time, threading, urllib.request
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import tests.mock_server as m
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright
m.scanner.start_background()
srv = make_server("127.0.0.1", 8140, m.app, threaded=True); threading.Thread(target=srv.serve_forever, daemon=True).start()
for _ in range(60):
    try:
        if json.load(urllib.request.urlopen("http://127.0.0.1:8140/api/status", timeout=2)).get("cached", 0) >= 8: break
    except Exception: pass
    time.sleep(1)
OVER = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "over.js")).read()
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={"width": 390, "height": 800}, is_mobile=True, has_touch=True); pg = ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda m_: errs.append(m_.text) if m_.type == "error" else None)
    pg.goto("http://127.0.0.1:8140/#home"); pg.wait_for_timeout(2000)
    # 1) corrupted desk config + unknown shell survive a reload
    pg.evaluate("T.UI.shell='desk'; T.UI.desk=[{t:'nope',s:99,h:'x'},{t:'chart',s:'abc'},null,{t:'plan',id:'a b'}]; T.saveUI()"); pg.wait_for_timeout(600)
    pg.reload(); pg.wait_for_timeout(2600)
    print("1 shell after reload:", pg.evaluate("T.UI.shell"), "| windows:", pg.evaluate("document.querySelectorAll('.win').length"), "| panel:", pg.evaluate("T.ST.panel"))
    pg.evaluate("T.UI.shell='bogus'; T.saveUI()"); pg.reload(); pg.wait_for_timeout(2200); print("2 bogus shell ->", pg.evaluate("T.UI.shell"))
    # 3) android back button closes the sheet
    pg.evaluate("T.applyShell('stack', true)"); pg.wait_for_timeout(1000); pg.evaluate("document.querySelector('.skc').click()"); pg.wait_for_timeout(900)
    print("3 sheet open:", pg.evaluate("!!document.querySelector('#sheet.on')")); pg.go_back(); pg.wait_for_timeout(700); print("  after back -> closed:", pg.evaluate("!document.querySelector('#sheet.on')"), "| url:", pg.url[-8:])
    # 4) open sheet, switch shell while open, then every shell with no coin selected
    pg.evaluate("document.querySelector('.skc').click()"); pg.wait_for_timeout(700); pg.evaluate("T.applyShell('desk', true)"); pg.wait_for_timeout(900)
    print("4 sheet leaked after shell switch:", pg.evaluate("!!document.querySelector('#sheet.on')"), "| body class:", pg.evaluate("document.body.className"))
    # 5) rapid shell cycling and coin switching
    for i in range(14):
        pg.evaluate("T.acts['shell-cycle']()"); pg.evaluate(f"T.loadCoin(['BTCUSDT','ETHUSDT','SOLUSDT'][{i}%3])"); pg.wait_for_timeout(260)
    pg.wait_for_timeout(1200); r = pg.evaluate(OVER); print("5 rapid cycle overflow:", r["sw"], r["W"], r["bad"])
    # 6) typing inside a window while data refreshes must not lose focus
    pg.evaluate("T.applyShell('desk', true); T.UI.desk=[{id:'n1',t:'notes',s:1,h:'m'},{id:'a1',t:'alerts',s:1,h:'m'}]; T.saveUI()"); pg.evaluate("T.R.all()"); pg.wait_for_timeout(1200)
    pg.click("#wb-n1 textarea"); pg.keyboard.type("hello"); pg.evaluate("T.render();T.render()"); pg.wait_for_timeout(300)
    print("6 note kept:", pg.evaluate("document.querySelector('#wb-n1 textarea').value"), "| focused:", pg.evaluate("document.activeElement.tagName"))
    print("ERRORS:", errs[:6] or "none"); b.close()

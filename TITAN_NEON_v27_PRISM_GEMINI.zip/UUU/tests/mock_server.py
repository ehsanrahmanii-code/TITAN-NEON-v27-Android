"""Run the full dashboard WITHOUT internet (synthetic market) — for UI development & screenshots."""
import os, sys, zlib, time, tempfile
os.environ.setdefault("TITAN_DATA", tempfile.mkdtemp())
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np, pandas as pd
from app.data import market
from tests.test_core import synth

IV = {"15m": 900, "1h": 3600, "4h": 14400, "1d": 86400}
def fake_download(sym, interval, limit):
    seed = zlib.crc32(sym.encode()) % 1000
    drift = ((seed % 21) - 10) / 3000
    return synth(n=max(300, limit), drift=drift * (1 + (hash(interval) % 3) * 0.2), vol=0.006 + (seed % 7) * 0.001, seed=seed, start=10 ** ((seed % 6) - 2) * 3, iv=IV[interval])
def fake_bulk():
    out = {}
    from app.config import DEFAULT_SYMBOLS
    for s in DEFAULT_SYMBOLS:
        df = fake_download(s, "1h", 300); p = float(df.close.iloc[-1]); o = float(df.close.iloc[-25])
        out[s] = market._tk(s, p, (p / o - 1) * 100, p * 1.02, p * .98, 1e6, 1e7)
    return out
def fake_depth(sym, limit=100):
    px = float(fake_download(sym, "1h", 300).close.iloc[-1]); rng = np.random.default_rng(zlib.crc32(sym.encode()))
    bids = [(px * (1 - 0.0004 * (i + 1)), float(rng.uniform(1, 9) * (6 if i in (17, 40) else 1))) for i in range(100)]
    asks = [(px * (1 + 0.0004 * (i + 1)), float(rng.uniform(1, 9) * (7 if i in (25, 60) else 1))) for i in range(100)]
    return {**market.depth_metrics(bids, asks), "source": "mock"}
def fake_derivs(sym):
    rng = np.random.default_rng(zlib.crc32(sym.encode()) + 1)
    return {"ok": True, "funding_pct": round(float(rng.normal(0.01, 0.02)), 4), "funding_apr": 11.0, "oi_usd": 4.2e8, "mark": 1.0, "index": 1.0,
            "basis_pct": 0.02, "next_funding": 0, "turnover_24h": 9e8, "ls_buy": 0.58, "ls_hist": [0.5 + 0.1 * np.sin(i / 3) for i in range(24)]}
market._download = fake_download
market._bulk_tickers = fake_bulk
import app.web.app as webapp
webapp.fetch_depth = fake_depth; webapp.fetch_derivs = fake_derivs
from app.web.app import app
from app.engine import scanner
if __name__ == "__main__":
    scanner.start_background()
    app.run(host="127.0.0.1", port=int(sys.argv[1]) if len(sys.argv) > 1 else 8099, threaded=True)

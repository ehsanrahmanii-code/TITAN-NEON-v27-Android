"""Interface matrix: every shell x viewport, every window / tab / sheet / dock panel. Reports JS errors and horizontal overflow.
usage: python tests/ui_matrix.py [shell,shell] [phone|tablet|desktop,...]   (needs: pip install playwright && playwright install chromium)"""
import os, sys, json, time, threading, urllib.request
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import tests.mock_server as m
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright

PORT = 8131
OUT = os.environ.get("SHOTS", "/tmp/shots"); os.makedirs(OUT, exist_ok=True)
SHELLS = (sys.argv[1].split(",") if len(sys.argv) > 1 and sys.argv[1] != "all" else ["panels", "desk", "terminal", "stack", "focus", "wall"])
VPS = {"phone": (360, 740, True), "tablet": (820, 1100, True), "desktop": (1280, 800, False)}
VP = (sys.argv[2].split(",") if len(sys.argv) > 2 else list(VPS))
m.scanner.start_background()
srv = make_server("127.0.0.1", PORT, m.app, threaded=True); threading.Thread(target=srv.serve_forever, daemon=True).start()
for _ in range(60):
    try:
        if json.load(urllib.request.urlopen(f"http://127.0.0.1:{PORT}/api/status", timeout=2)).get("cached", 0) >= 8: break
    except Exception: pass
    time.sleep(1)
OVER = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "over.js")).read()
bad_total = 0

def check(pg, label, errs):
    global bad_total
    r = pg.evaluate(OVER); bad = bool(r["bad"] or r["sw"] > r["W"] + 1)
    if bad: bad_total += 1; print("  OVERFLOW", label, r["sw"], r["W"], r["bad"][:3])

with sync_playwright() as p:
    b = p.chromium.launch()
    for vp in VP:
        w, h, mob = VPS[vp]
        for sh in SHELLS:
            ctx = b.new_context(viewport={"width": w, "height": h}, device_scale_factor=1, is_mobile=mob, has_touch=mob); pg = ctx.new_page(); errs = []
            pg.on("pageerror", lambda e: errs.append("PAGEERR " + str(e)))
            pg.on("console", lambda msg: errs.append("CONSOLE " + msg.text) if msg.type == "error" else None)
            pg.goto(f"http://127.0.0.1:{PORT}/#home"); pg.wait_for_timeout(2200)
            pg.evaluate(f"T.applyShell('{sh}', true)"); pg.wait_for_timeout(1400); check(pg, f"{vp}/{sh}/boot", errs)
            pg.evaluate("T.loadCoin('ETHUSDT')"); pg.wait_for_timeout(900); check(pg, f"{vp}/{sh}/coin", errs)
            if sh == "desk":
                types = pg.evaluate("Object.keys(T.WINS).filter(k=>T.WINS[k].cat!=='x')")
                for i in range(0, len(types), 9):
                    chunk = types[i:i + 9]
                    pg.evaluate("(c)=>{T.UI.desk=c.map((t,i)=>({id:'t'+i+t,t,s:1+(i%3===0),h:'m'}));T.saveUI();T.R.all();}", chunk); pg.wait_for_timeout(1500)
                    check(pg, f"{vp}/desk/types{i}", errs)
                    if i == 0: pg.screenshot(path=f"{OUT}/ui_{vp}_desk.png", full_page=True)
                for tpl in ["trader", "analyst", "scalper", "market", "minimal"]:
                    pg.evaluate(f"T.acts['desk-tpl']({{dataset:{{k:'{tpl}'}}}})"); pg.wait_for_timeout(1100); check(pg, f"{vp}/desk/tpl-{tpl}", errs)
                pg.evaluate("T.acts['w-size']({dataset:{w:T.UI.desk[0].id,d:'1'}});T.acts['w-h']({dataset:{w:T.UI.desk[0].id}});T.acts['w-mv']({dataset:{w:T.UI.desk[1].id,d:'-1'}});T.acts['w-max']({dataset:{w:T.UI.desk[0].id}})"); pg.wait_for_timeout(900); check(pg, f"{vp}/desk/max", errs)
                pg.evaluate("T.acts['w-max']({dataset:{w:T.UI.desk[0].id}});T.acts['w-addtoggle']()"); pg.wait_for_timeout(500); check(pg, f"{vp}/desk/addpanel", errs)
            elif sh == "terminal":
                for i in range(3):
                    pg.evaluate(f"T.acts['term-pane']({{dataset:{{i:'{i}'}}}})"); pg.wait_for_timeout(500); check(pg, f"{vp}/terminal/pane{i}", errs)
                pg.evaluate("T.acts['term-pane']({dataset:{i:'1'}})")
                for k in pg.evaluate("T.TERM_TABS"):
                    pg.evaluate(f"T.acts['term-tab']({{dataset:{{k:'{k}'}}}})"); pg.wait_for_timeout(350); check(pg, f"{vp}/terminal/tab-{k}", errs)
                pg.screenshot(path=f"{OUT}/ui_{vp}_terminal.png")
            elif sh == "stack":
                pg.wait_for_timeout(500); pg.screenshot(path=f"{OUT}/ui_{vp}_stack_feed.png")
                pg.evaluate("document.querySelector('.skc').click()"); pg.wait_for_timeout(1200)
                print("  sheet open:", pg.evaluate("!!document.querySelector('#sheet.on')"))
                for k, _n in pg.evaluate("T.SHEET_TABS"):
                    pg.evaluate(f"T.acts['sheet-tab']({{dataset:{{k:'{k}'}}}})"); pg.wait_for_timeout(300); check(pg, f"{vp}/stack/sheet-{k}", errs)
                    if k == "plan": pg.screenshot(path=f"{OUT}/ui_{vp}_stack_sheet.png")
                pg.evaluate("T.acts['sheet-trade']({dataset:{side:'SHORT'}})"); pg.wait_for_timeout(600); check(pg, f"{vp}/stack/trade", errs)
                pg.evaluate("T.acts['sheet-close']()"); pg.wait_for_timeout(500)
                print("  sheet closed:", pg.evaluate("!document.querySelector('#sheet.on')"))
            elif sh == "focus":
                for k in [d[0] for d in pg.evaluate("T.DOCK")] + ["layers"]:
                    pg.evaluate(f"T.acts['fdock']({{dataset:{{k:'{k}'}}}})"); pg.wait_for_timeout(400); check(pg, f"{vp}/focus/{k}", errs)
                    if k == "plan": pg.screenshot(path=f"{OUT}/ui_{vp}_focus_plan.png")
                pg.evaluate("T.acts['fdock']({dataset:{k:'layers'}});T.acts['fdock-sym']()"); pg.wait_for_timeout(800); check(pg, f"{vp}/focus/next", errs)
            elif sh == "wall":
                for i in range(5):
                    pg.evaluate(f"T.acts['wall-go']({{dataset:{{i:'{i}'}}}})"); pg.wait_for_timeout(500); check(pg, f"{vp}/wall/slide{i}", errs)
                pg.screenshot(path=f"{OUT}/ui_{vp}_wall.png")
            elif sh == "panels":
                for pn in ["home", "coin", "chart"]:
                    pg.evaluate(f"T.go('{pn}')"); pg.wait_for_timeout(500); check(pg, f"{vp}/panels/{pn}", errs)
            for pn in ["mkt", "ex", "set"]:
                pg.evaluate(f"T.go('{pn}')"); pg.wait_for_timeout(450); check(pg, f"{vp}/{sh}/{pn}", errs)
            # switching shells back and forth must be clean
            pg.evaluate("T.applyShell('panels', true)"); pg.wait_for_timeout(500); pg.evaluate(f"T.applyShell('{sh}', true)"); pg.wait_for_timeout(700); check(pg, f"{vp}/{sh}/reswitch", errs)
            print(f"{vp:8s} {sh:9s} errors: {errs[:4] or 'none'}"); bad_total += len(errs); ctx.close()
    b.close()
print("MATRIX PROBLEMS:", bad_total)

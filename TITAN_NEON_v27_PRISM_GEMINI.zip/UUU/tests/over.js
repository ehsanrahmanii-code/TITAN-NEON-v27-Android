() => { const W = document.documentElement.clientWidth, bad = [];
  document.querySelectorAll('body *').forEach(e => { const r = e.getBoundingClientRect(); if (!r.width || !r.height) return; const cs = getComputedStyle(e); if (cs.position === 'fixed') return;
    if (r.right > W + 1 || r.left < -1) { let p = e.parentElement, clip = false; while (p && !p.classList.contains('app') && p !== document.body) { if (/(auto|scroll|hidden|clip)/.test(getComputedStyle(p).overflowX)) { clip = true; break; } p = p.parentElement; }
      if (!clip) bad.push(e.tagName + '.' + String(e.className).slice(0, 30) + ' ' + Math.round(r.left) + '..' + Math.round(r.right)); } });
  return { sw: document.documentElement.scrollWidth, W, bad: bad.slice(0, 6) }; }
"""Offline tests: synthetic data, no network. Run: python -m pytest -q   (or python tests/test_core.py)"""
import os, sys, tempfile, time
os.environ["TITAN_DATA"] = tempfile.mkdtemp()
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pandas as pd

from app.data import market
from app.analysis.technicals import analyze
from app.analysis.forecast import forecast_summary
from app.analysis.deep import deep_analyze
from app.exchange import paper


def synth(n=300, drift=0.0, vol=0.01, seed=1, start=100.0, iv=3600):
    rng = np.random.default_rng(seed)
    r = rng.normal(drift, vol, n)
    c = start * np.exp(np.cumsum(r))
    o = np.r_[start, c[:-1]]
    h = np.maximum(o, c) * (1 + np.abs(rng.normal(0, vol / 2, n)))
    l = np.minimum(o, c) * (1 - np.abs(rng.normal(0, vol / 2, n)))
    t0 = int(time.time()) // iv * iv - n * iv
    ot = pd.to_datetime([(t0 + i * iv) for i in range(n)], unit="s")
    return pd.DataFrame({"open_time": ot, "open": o, "high": h, "low": l, "close": c, "volume": rng.uniform(100, 200, n) * (1 + np.abs(r) * 50)})


def test_signal_sanity():
    up = analyze(synth(drift=0.004, seed=2), "X", "1h")
    dn = analyze(synth(drift=-0.004, seed=3), "X", "1h")
    assert up.score > 15 and dn.score < -15, (up.score, dn.score)
    assert up.side == "LONG" and dn.side == "SHORT", (up.side, dn.side)
    assert up.stop < up.entry < up.tp1 < up.tp2 < up.tp3
    assert dn.stop > dn.entry > dn.tp1 > dn.tp2 > dn.tp3
    assert len(up.components) == 26 and all(-1 <= c["s"] <= 1 for c in up.components)


def test_distribution_not_degenerate():
    sides = [analyze(synth(drift=0.0, seed=s), "X", "1h").side for s in range(40)]
    wait = sides.count("WAIT") / len(sides)
    assert 0.3 < wait < 0.97, wait


def test_forecast_deterministic_and_cone():
    df = synth(seed=5)
    a = forecast_summary(df, "WAIT", 16, "X1h")
    b = forecast_summary(df, "WAIT", 16, "X1h")
    assert a["candles"] == b["candles"]
    assert all(lo <= m <= hi for lo, m, hi in zip(a["bands"]["p10"], a["bands"]["p50"], a["bands"]["p90"]))
    tiny = synth(start=1e-5, seed=6)           # v1 seeded with int(price*1000)=0 for such coins
    assert forecast_summary(tiny, "WAIT", 16, "SHIB1h")["candles"]


def test_closed_only():
    df = synth(n=100)
    forming = df.copy()
    forming.loc[forming.index[-1], "open_time"] = pd.Timestamp.now('UTC').tz_localize(None).floor("h")
    assert len(market.closed_only(forming, "1h")) == 99
    assert len(market.closed_only(df, "1h")) == 100


def test_deep():
    fr = {tf: synth(drift=0.003, seed=i + 10) for i, tf in enumerate(["15m", "1h", "4h", "1d"])}
    d = deep_analyze(fr, "BTCUSDT", "1h")
    assert d["verdict"] in ("LONG", "SHORT", "WAIT") and d["narrative"]
    assert d["verdict"] == "LONG", d["consensus_score"]


def _open(side="LONG", lev=10):
    d = 1 if side == "LONG" else -1
    return paper.open_position("TESTUSDT", side, 100.0, 100 - 2 * d, 100 + 2 * d, 100 + 4 * d, 100 + 7 * d, leverage=lev)


def test_risk_sizing_not_multiplied_by_leverage():
    paper.reset_account()
    r = _open()
    assert r["ok"], r
    p = r["position"]
    loss_at_stop = abs(p["entry"] - p["stop"]) * p["qty"]
    assert abs(loss_at_stop - 100.0) < 3, loss_at_stop          # 1% of 10k, NOT 10%


def test_partial_tps_and_breakeven():
    paper.reset_account()
    p = _open()["position"]
    paper.mark_to_market({"TESTUSDT": 102.5}, lambda *a: (100.0, 102.5))
    acc = paper.get_account({"TESTUSDT": 102.5})
    pos = acc["open_positions"][0]
    assert pos["stage"] == 1 and pos["stop"] > 100.0 and pos["qty_left"] < p["qty"]
    paper.mark_to_market({"TESTUSDT": 104.5}, lambda *a: (102.4, 104.5))
    assert paper.get_account()["open_positions"][0]["stage"] == 2
    closed = paper.mark_to_market({"TESTUSDT": 107.5}, lambda *a: (104.4, 107.5))
    assert closed and closed[0]["reason"] == "tp3" and closed[0]["pnl"] > 0
    assert paper.get_account()["wins"] == 1


def test_wick_stop_detected():
    paper.reset_account()
    _open()
    closed = paper.mark_to_market({"TESTUSDT": 100.5}, lambda *a: (97.0, 100.6))   # price recovered, wick hit SL
    assert closed and closed[0]["reason"] == "stop" and closed[0]["pnl"] < 0
    assert -125 < closed[0]["pnl"] < -90


def test_short_side_and_manual_close_live_price():
    paper.reset_account()
    _open("SHORT")
    r = paper.close_position(paper.get_account()["open_positions"][0]["id"], 98.0)
    assert r["ok"] and r["pnl"] > 50


def test_corrupt_state_not_silently_reset():
    paper.reset_account(); _open()
    paper._ACC = None
    paper._FILE.write_text("{broken")
    acc = paper.get_account()
    assert acc["open_positions"], "must restore from backup"
    assert "backup" in acc["notice"]


def test_invalid_orders_rejected():
    paper.reset_account()
    assert not paper.open_position("AUSDT", "LONG", 100, 101, 102, 103)["ok"]
    assert not paper.open_position("AUSDT", "LONG", 100, 98, 99, 103)["ok"]


def test_flask_api():
    from app.web.app import app
    from app import settings
    c = app.test_client()
    assert c.get("/").status_code == 200
    assert c.get("/api/status").json["version"]
    assert c.get("/api/coin/..%2Fetc").status_code in (400, 404)
    assert c.post("/api/exchange/reset", headers={"Origin": "http://evil.example"}).status_code == 403
    r = c.post("/api/settings", json={"watchlist": ["btc", "ETHUSDT", "bad symbol!"], "ui": {"theme": "x"}})
    assert r.json["watchlist"] == ["BTCUSDT", "ETHUSDT"], r.json
    assert c.post("/api/settings", json={"watchlist": []}).status_code == 400
    assert c.get("/api/exchange").json["wallet"] > 0


def test_forecast_32_edge_and_levels():
    from app.analysis.forecast import forecast_summary
    df = synth(drift=0.002, seed=4); px = float(df.close.iloc[-1])
    lv = {"entry": px, "stop": px * 0.97, "tp1": px * 1.03, "tp2": px * 1.06, "tp3": px * 1.09}
    f = forecast_summary(df, "LONG", 32, "k", levels=lv); g = forecast_summary(df, "LONG", 32, "k", levels=lv)
    assert len(f["candles"]) == 32 and f["candles"] == g["candles"] and f["edge"] == g["edge"]       # deterministic
    for c in f["candles"]:
        assert c["high"] >= max(c["open"], c["close"]) - 1e-9 and c["low"] <= min(c["open"], c["close"]) + 1e-9
    e = f["edge"]
    assert 0 <= e["p_tp3"] <= e["p_tp2"] <= e["p_tp1"] <= 1 and abs(e["p_stop"] + e["p_tp1"] + e["p_open"] - 1) < 0.02, e
    assert len(f["step_prob"]) == 32 and sum(f["hist"]["counts"]) > 500
    assert forecast_summary(df, "WAIT", 32, "k")["edge"] is None


def test_new_components_and_extras():
    s = analyze(synth(drift=0.003, seed=9), "X", "1h")
    keys = {c["k"] for c in s.components}
    assert {"ichi", "srsi", "mfi", "cmf", "donch", "ha", "pat2"} <= keys
    ex = s.extras
    assert ex["vp"]["val"] <= ex["vp"]["poc"] <= ex["vp"]["vah"] and ex["fib"]["levels"] and ex["pivots"]["r1"] > ex["pivots"]["s1"]
    assert all(z["kind"] in ("R", "S") for z in s.levels["zones"])


def test_backtest_and_grade_and_depth():
    from app.analysis import backtest
    from app.analysis.grade import fuse
    from app.data.market import depth_metrics
    r = backtest.run(synth(n=420, drift=0.001, seed=3), "X", "1h")
    assert r.get("n", 0) == len(r.get("equity", [])) and "error" not in r
    assert fuse({"15m": 60, "1h": 60, "4h": -50, "1d": -50})[1] == "WAIT"       # higher-timeframe veto
    assert fuse({"15m": 60, "1h": 60, "4h": 50, "1d": 40})[1] == "LONG"
    m = depth_metrics([(100 - i * .1, 2) for i in range(50)], [(100.1 + i * .1, 1) for i in range(50)])
    assert m["ok"] and m["imb_1pct"] > 0 and m["spread_pct"] > 0


def test_new_api_endpoints():
    from app.web.app import app
    c = app.test_client()
    assert "per_tf" in c.get("/api/market").json
    assert c.get("/api/micro/..%2Fetc").status_code in (400, 404)
    assert c.get("/api/backtest/bad%20sym").status_code in (400, 404)


def test_patterns_engine():
    from app.analysis import patterns as P
    df = synth(n=320, drift=0.0, seed=11)
    F = P.candle_flags(df)
    assert set(F) <= set(P.INFO) and all(len(v) == len(df) for v in F.values())
    # hand-made bullish engulfing in a down-move must be detected on the last bar
    d2 = synth(n=120, drift=-0.004, seed=5).copy()
    i = len(d2) - 1; px = float(d2.close.iloc[i - 1])
    d2.loc[d2.index[i - 1], ["open", "close", "high", "low"]] = [px * 1.004, px, px * 1.0045, px * 0.998]
    d2.loc[d2.index[i], ["open", "close", "high", "low"]] = [px * 0.996, px * 1.012, px * 1.013, px * 0.995]
    names = {r["k"] for r in P.detect_recent(d2, 3)}
    assert "engulf_bull" in names, names
    st = P.pooled_stats([synth(n=300, drift=0.0, seed=s) for s in range(8)])
    assert "_base" in st and any(k != "_base" for k in st)
    for k, v in st.items():
        if k != "_base":
            assert v["h"] and all(0 <= z["win"] <= 100 for z in v["h"].values())
    assert P.verdict(None, 1)["level"] == "none"
    for z in P.structures(synth(n=200, drift=0.001, seed=3)):
        assert z["lines"] and 0 <= z["conf"] <= 1


def test_alerts_roundtrip_and_flow():
    from app.engine import alerts
    a = alerts.add({"type": "price", "symbol": "BTC", "op": ">", "price": 100.0})
    try:
        alerts.add({"type": "price", "symbol": "BTCUSDT", "op": "?", "price": 1})
        raise AssertionError("bad op accepted")
    except ValueError:
        pass
    assert not alerts.check(lambda s: 90.0, lambda s: {}, ["BTCUSDT"])
    fired = alerts.check(lambda s: 101.0, lambda s: {}, ["BTCUSDT"])
    assert fired and fired[0]["id"] == a["id"] and not alerts.check(lambda s: 150.0, lambda s: {}, ["BTCUSDT"])    # fires once
    s = alerts.add({"type": "signal", "symbol": "*", "min_grade": "B"})
    assert not alerts.check(lambda s_: 1, lambda s_: {"verdict": "WAIT", "grade": "—"}, ["ETHUSDT"])
    assert alerts.check(lambda s_: 1, lambda s_: {"verdict": "LONG", "grade": "A"}, ["ETHUSDT"])
    assert not alerts.check(lambda s_: 1, lambda s_: {"verdict": "LONG", "grade": "A"}, ["ETHUSDT"])            # same state: no repeat
    assert alerts.remove(a["id"]) and alerts.remove(s["id"]) and not alerts.remove("nope")
    f = analyze(synth(drift=0.002, seed=4), "X", "1h").extras["flow"]
    assert 0 <= f["buy_share"] <= 1 and len(f["cvd"]) == len(f["price"])


def test_planner_and_smc_and_osc():
    from app.analysis import planner, forecast
    df = synth(n=300, drift=0.002, seed=4)
    s = analyze(df, "X", "1h"); sim = forecast.simulate(df, 32, 600, "k")
    px = float(df.close.iloc[-1]); atr = s.indicators["atr"]
    for side in ("LONG", "SHORT"):
        r = planner.run(sim, side, px, atr, s.indicators, s.extras, s.levels["zones"])
        assert r["rows"] and all(0 <= x["p_fill"] <= 1 and x["ev_r"] is not None for x in r["rows"])
        d = 1 if side == "LONG" else -1
        for x in r["rows"]:
            assert (x["p"] - x["stop"]) * d > 0 and (x["tp1"] - x["p"]) * d > 0 and x["tp3"] != x["tp1"]
        if r["best"]:
            assert r["best"]["ev_r"] > 0 and r["best"]["p_fill"] >= 0.3
    ex = s.extras
    assert ex["smc"]["structure"]["trend"] in ("bull", "bear", "range", "expand", "squeeze") and ex["smc"]["range"]["zone"] in ("premium", "discount", "equilibrium")
    o = ex["osc"]; assert len(o["osc"]) == 12 and len(o["ma"]) == 12 and -100 <= o["all_score"] <= 100 and o["misc"]["psar_dir"] in ("up", "down")


def test_pending_orders_and_policy():
    from app.exchange import paper as ex, policy
    ex.reset_account()
    o = {"symbol": "BTCUSDT", "side": "LONG", "mode": "limit", "price": 95.0, "stop": 92.0, "tp1": 98.0, "tp2": 101.0, "tp3": 104.0, "valid_h": 4}
    assert ex.place_order(o)["ok"] and not ex.place_order(o)["ok"]                                        # one resting order per coin
    assert not ex.place_order({**o, "symbol": "ETHUSDT", "stop": 96.0})["ok"]                              # stop on the wrong side
    ex.mark_to_market({"BTCUSDT": 100.0}, None)
    assert len(ex.get_account({"BTCUSDT": 100.0})["orders"]) == 1                                         # not touched yet
    ex.mark_to_market({"BTCUSDT": 94.9}, None)
    a = ex.get_account({"BTCUSDT": 94.9})
    assert not a["orders"] and a["open_positions"] and abs(a["open_positions"][0]["entry"] - 95.0) < 1e-9    # limit fills at its own price
    ex.reset_account()
    assert ex.place_order({**o, "mode": "stop", "price": 105.0, "stop": 99.0, "tp1": 108.0, "tp2": 111.0, "tp3": 114.0})["ok"]
    ex.mark_to_market({"BTCUSDT": 98.0}, None)                                                              # stop level breached before the trigger -> cancelled
    assert not ex.get_account({"BTCUSDT": 98.0})["orders"]
    cfg = policy.effective()
    base = {"symbol": "ETHUSDT", "side": "LONG", "verdict": "LONG", "grade": "D", "cons": 60, "agree": 0.9, "plan": None, "ext_atr": 0, "rsi_extreme": False, "qv": 9e9,
            "evidence": {"n": 20, "avg_r": 0.1}, "open": [], "n_orders": 0, "risk_open_pct": 0, "corr": lambda s: 0.0, "btc_cons": 10, "vol_hot": False}
    d = policy.evaluate(cfg, base); assert not d["ok"] and any("درجه" in f for f in d["fails"])
    good = {**base, "grade": "A", "plan": {"name": "EMA 21", "mode": "limit", "p": 100, "stop": 98, "tp1": 102.4, "tp2": 104.4, "tp3": 107, "ev_r": 0.3, "p_tp1": 0.55}}
    assert policy.evaluate(cfg, good)["ok"]
    assert not policy.evaluate(cfg, {**good, "evidence": {"n": 20, "avg_r": -0.3}})["ok"]                   # coin-level evidence blocks it
    assert not policy.evaluate(cfg, {**good, "open": [{"symbol": "A", "side": "LONG"}, {"symbol": "B", "side": "LONG"}]})["ok"]   # same-direction cap
    ex.reset_account()


def test_signal_track_record():
    from app.engine import siglog
    siglog._STATE.update(loaded=True, entries=[], last={})
    t0 = 1_000_000
    assert siglog.tick({"AAAUSDT": {"verdict": "LONG", "grade": "A", "cons": 60}, "BBBUSDT": {"verdict": "SHORT", "grade": "C", "cons": -50}}, {"AAAUSDT": 100.0, "BBBUSDT": 50.0}, now=t0) == 2
    assert siglog.tick({"AAAUSDT": {"verdict": "LONG", "grade": "A", "cons": 61}}, {"AAAUSDT": 101.0}, now=t0 + 60) == 0           # same verdict -> not a new signal
    siglog.tick({"AAAUSDT": {"verdict": "LONG"}, "BBBUSDT": {"verdict": "SHORT"}}, {"AAAUSDT": 103.0, "BBBUSDT": 48.0}, now=t0 + 4 * 3600 + 5)
    v = siglog.view()
    assert v["resolved"] == 2 and v["stats"]["A"]["avg"] == 3.0 and v["stats"]["C"]["avg"] == 4.0 and v["stats"]["A"]["win"] == 100.0       # short wins when price falls
    assert siglog.tick({"AAAUSDT": {"verdict": "WAIT"}}, {"AAAUSDT": 100.0}, now=t0 + 5 * 3600) == 0
    assert siglog.tick({"AAAUSDT": {"verdict": "LONG", "grade": "B", "cons": 55}}, {"AAAUSDT": 100.0}, now=t0 + 6 * 3600) == 1        # re-armed after WAIT
    siglog._STATE.update(loaded=True, entries=[], last={})


if __name__ == "__main__":
    fails = 0
    for k, v in list(globals().items()):
        if k.startswith("test_"):
            try:
                v(); print("PASS", k)
            except Exception as e:                      # noqa: BLE001
                fails += 1; print("FAIL", k, repr(e))
    sys.exit(fails)

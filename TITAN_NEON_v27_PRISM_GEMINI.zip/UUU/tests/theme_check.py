import os, sys, json, time, threading, urllib.request
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import tests.mock_server as m
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright
m.scanner.start_background()
srv = make_server("127.0.0.1", 8126, m.app, threaded=True); threading.Thread(target=srv.serve_forever, daemon=True).start()
for _ in range(60):
    try:
        if json.load(urllib.request.urlopen("http://127.0.0.1:8126/api/status", timeout=2)).get("cached", 0) >= 8: break
    except Exception: pass
    time.sleep(1)
OVER = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "over.js")).read()
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={"width": 360, "height": 740}, device_scale_factor=1, is_mobile=True, has_touch=True); pg = ctx.new_page(); errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.goto("http://127.0.0.1:8126/#home"); pg.wait_for_timeout(2500)
    ids = pg.evaluate("T.PRESETS.filter(p=>p.glass).map(p=>p.id)")
    for tid in ids:
        pg.evaluate(f"T.setUI('preset','{tid}',true)"); pg.wait_for_timeout(500)
        r = pg.evaluate(OVER); print(tid, "OVERFLOW" if (r["bad"] or r["sw"] > r["W"] + 1) else "ok"); pg.screenshot(path=os.environ.get("SHOTS", "/tmp/shots") + f"/theme_{tid}.png")
    pg.evaluate("T.go('set')"); pg.wait_for_timeout(600); pg.evaluate("document.querySelectorAll('details.set-sec').forEach(d=>d.open=true)"); pg.wait_for_timeout(400)
    r = pg.evaluate(OVER); print("settings all open:", r["sw"], r["W"], r["bad"]); pg.screenshot(path=os.environ.get("SHOTS", "/tmp/shots") + "/settings_open.png", full_page=True)
    print("errors:", errs or "none"); b.close()

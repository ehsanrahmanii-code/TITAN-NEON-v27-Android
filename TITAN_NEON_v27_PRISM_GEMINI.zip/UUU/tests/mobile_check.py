"""Headless phone check: starts the offline mock market, opens every panel/tab at phone widths,
reports horizontal overflow + JS console errors and saves screenshots (needs `pip install playwright`)."""
import os, sys, time, json, threading, urllib.request
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import tests.mock_server as m
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright

PORT = 8123
OUT = os.environ.get("SHOTS", "/tmp/shots"); os.makedirs(OUT, exist_ok=True)
m.scanner.start_background()
srv = make_server("127.0.0.1", PORT, m.app, threaded=True); threading.Thread(target=srv.serve_forever, daemon=True).start()
for _ in range(60):
    try:
        if json.load(urllib.request.urlopen(f"http://127.0.0.1:{PORT}/api/status", timeout=2)).get("cached", 0) >= 8: break
    except Exception: pass
    time.sleep(1)

JS_OVER = """() => { const W = document.documentElement.clientWidth, bad = [];
  document.querySelectorAll('body *').forEach(e => { const r = e.getBoundingClientRect(); if (!r.width || !r.height) return; const cs = getComputedStyle(e); if (cs.position === 'fixed') return;
    if (r.right > W + 1 || r.left < -1) { let p = e.parentElement, clip = false; while (p && !p.classList.contains('app') && p !== document.body) { if (/(auto|scroll|hidden|clip)/.test(getComputedStyle(p).overflowX)) { clip = true; break; } p = p.parentElement; }
      if (!clip) bad.push(e.tagName + '.' + String(e.className).slice(0, 30) + ' ' + Math.round(r.left) + '..' + Math.round(r.right)); } });
  return { sw: document.documentElement.scrollWidth, W, bad: bad.slice(0, 6) }; }"""
VIEWS = [(360, 740), (390, 844)] if "--quick" not in sys.argv else [(360, 740)]
STEPS = [("home", None), ("coin", "sum"), ("coin", "pat"), ("coin", "plan"), ("coin", "check"), ("coin", "smc"), ("coin", "scen"), ("coin", "tech"), ("coin", "mtf"), ("coin", "fc"), ("coin", "lvl"), ("coin", "flow"), ("coin", "micro"), ("coin", "comp"), ("coin", "bt"), ("coin", "alerts"), ("coin", "risk"), ("coin", "ai"),
         ("chart", "main"), ("chart", "mtf"), ("mkt", "opp"), ("mkt", "breadth"), ("mkt", "corr"), ("mkt", "sys"), ("ex", None), ("set", None)]
problems = 0
with sync_playwright() as p:
    b = p.chromium.launch()
    for (w, h) in VIEWS:
        ctx = b.new_context(viewport={"width": w, "height": h}, device_scale_factor=2, is_mobile=True, has_touch=True)
        pg = ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e))); pg.on("console", lambda msg: errs.append(msg.text) if msg.type == "error" else None)
        pg.goto(f"http://127.0.0.1:{PORT}/#home"); pg.wait_for_timeout(2500)
        for panel, tab in STEPS:
            pg.evaluate(f"T.go('{panel}')")
            if tab:
                key = {"coin": "coin", "chart": "chart", "mkt": "mkt"}[panel]
                pg.evaluate(f"(()=>{{T.ST.tab['{key}']='{tab}'; if ('{tab}'==='micro') T.loadMicro(T.ST.sel,true); if('{panel}'==='chart'&&'{tab}'==='mtf') T.loadMtf(); T.render();}})()")
            if panel in ("coin", "chart") and not pg.evaluate("T.ST.sel"): pg.evaluate("T.selectCoin('BTCUSDT', '%s')" % panel)
            if tab == "bt": pg.evaluate("T.loadBt()"); pg.wait_for_timeout(6000)
            pg.wait_for_timeout(1400 if tab in ("micro", "mtf") else 700)
            r = pg.evaluate(JS_OVER); bad = r["bad"] or r["sw"] > r["W"] + 1
            if bad: problems += 1
            print(f"{w}x{h} {panel}/{tab or '-'}: scrollW={r['sw']} W={r['W']} {'OVERFLOW ' + str(r['bad']) if bad else 'ok'}")
            pg.screenshot(path=f"{OUT}/{w}_{panel}_{tab or 'x'}.png", full_page=(panel != "chart"))
        print("console errors:", errs[:6] or "none"); problems += len(errs)
        ctx.close()
    b.close()
print("PROBLEMS:", problems)
# ---- every interface (skin) on home + settings, phone and desktop
with sync_playwright() as p2:
    b2 = p2.chromium.launch(); sk_problems = 0
    for (w, h, mob) in [(360, 740, True), (1280, 800, False)]:
        ctx = b2.new_context(viewport={"width": w, "height": h}, device_scale_factor=1.5 if mob else 1, is_mobile=mob, has_touch=mob); pg = ctx.new_page(); errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(f"http://127.0.0.1:{PORT}/#home"); pg.wait_for_timeout(2500)
        for sk in ["neon", "terminal", "cockpit", "paper", "app", "chart"]:
            pg.evaluate(f"T.applySkin('{sk}')"); pg.evaluate("T.go('home')"); pg.wait_for_timeout(1800)
            for panel in ("home", "coin", "set"):
                pg.evaluate(f"T.go('{panel}')"); pg.wait_for_timeout(500)
                r = pg.evaluate(JS_OVER); bad = r["bad"] or r["sw"] > r["W"] + 1; sk_problems += bool(bad)
                print(f"skin {sk:9s} {w}px {panel}: {'OVERFLOW ' + str(r['bad']) + str(r['sw']) if bad else 'ok'}")
            pg.evaluate("T.go('home')"); pg.wait_for_timeout(300); pg.screenshot(path=f"{OUT}/skin_{sk}_{w}.png")
        print("skin errors:", errs[:5] or "none"); sk_problems += len(errs); ctx.close()
    b2.close()
print("SKIN PROBLEMS:", sk_problems)
